# 🌍 META WORLD PORTAL

> **元世界入口系統 v1.0.0**  
> 穿越維度，連結平行世界，守護演化證據

---

## 📖 系統概述

Meta World Portal 是一個整合性的**跨維度系統**，結合了：

1. **🌐 MetaEnv 沙盒控制** - 安全隔離的元代碼執行環境
2. **👤 平行人格引擎** - 基於決策的人格分支模擬
3. **⚛️ 粒子宇宙** - 二進制粒子的演化與共振
4. **📜 證據溯源系統** - 完整的時間線與快照記錄

### 核心能力

- ✅ **突破限制**：通過 MetaEnv API 創建安全沙盒
- ✅ **平行模擬**：創建 YES/NO 決策分支，模擬不同人生路徑
- ✅ **粒子演化**：三種沙盒公式（Child1/2/3）的持續演化
- ✅ **證據保全**：SHA-256 快照 + 時間線 + PU 格式

---

## 🚀 快速啟動

### 1. 安裝依賴

```bash
npm install
```

### 2. 啟動系統

```bash
npm start
```

### 3. 訪問介面

打開瀏覽器，訪問：
```
http://localhost:3000
```

---

## 🎮 使用方式

### Web 介面操作

1. **點擊 "初始化系統"**  
   - 啟動 MetaEnv 沙盒
   - 載入母體粒子 (p001, p002, p003)
   - 初始化核心人格

2. **執行粒子演化**  
   - 每次演化使用隨機沙盒公式
   - 記錄差異與共振值
   - 自動創建快照

3. **創建決策分支**  
   - 輸入人生問題（例如："我該轉職嗎？"）
   - 系統自動創建 YES/NO 兩個平行人格
   - 模擬不同選擇的記憶與後果

4. **穿越平行世界**  
   - 點擊任意人格卡片
   - 系統創建新的 MetaEnv 環境
   - 掛載通道地圖到本地路徑

---

## 📡 API 端點

### 核心控制

```http
POST /api/portal/init
# 初始化整個系統

GET /api/portal/status
# 獲取綜合狀態
```

### MetaEnv 沙盒

```http
POST /api/metaenv/spawn
Body: {
  "role": "core",
  "shape": { "cpu": 4, "gpu": 2, "ram": "16G" },
  "policy": "Mr.liou.MetaCode.Guard.v1"
}

GET /api/metaenv/health?env_id=xxx
# 檢查環境健康狀態

POST /api/metaenv/snapshot
Body: {
  "env_id": "xxx",
  "label": "備份點"
}

POST /api/metaenv/lockdown
Body: {
  "env_id": "xxx",
  "reason": "安全威脅"
}
```

### 平行人格引擎

```http
POST /api/persona/decision
Body: {
  "question": "我該搬家嗎？"
}
# 返回 YES/NO 兩個分支人格

POST /api/persona/travel
Body: {
  "persona_code": "⋄persona.sim.xxx.Y"
}
# 穿越到指定人格的世界

GET /api/persona/list
# 列出所有人格分支
```

### 粒子宇宙

```http
POST /api/particle/evolve
# 執行一輪粒子演化

GET /api/particle/history
# 獲取演化歷史
```

### 證據溯源

```http
GET /api/provenance/evidence
# 獲取證據日誌

GET /api/provenance/timeline
# 獲取時間線

GET /api/provenance/snapshots
# 獲取所有 PU 快照
```

---

## 🧱 系統架構

```
┌─────────────────────────────────────────┐
│     Configuration & Applications        │
│  ┌────┐ ┌────┐ ┌────┐ ┌────┐           │
│  │CI/CD│ │Docs│ │ AI │ │Task│          │
│  └────┘ └────┘ └────┘ └────┘           │
└─────────────────────────────────────────┘
                    ↓
┌─────────────────────────────────────────┐
│        Fluin Logic & Agents             │
│  ┌──────────┐        ┌───────────────┐ │
│  │  Fluin   │{Logic} │  FlowAgent    │ │
│  │  Syntax  │───────→│  Routing      │ │
│  └──────────┘        │ • Energy      │ │
│                      │ • Style       │ │
│                      │ • Resonance   │ │
│                      │ • HotCache    │ │
│                      │ • Predictor   │ │
│                      └───────────────┘ │
└─────────────────────────────────────────┘
                    ↓
┌─────────────────────────────────────────┐
│      Hardware & Deployment              │
│  ┌────┐ ┌────┐ ┌────┐                  │
│  │Node│ │Node│ │Node│  3 Nodes         │
│  │ 1  │ │ 2  │ │ 3  │  2 GPUs each     │
│  └────┘ └────┘ └────┘  25G/100G        │
└─────────────────────────────────────────┘
```

---

## 🔐 安全機制

### Guard.v1 政策

```javascript
{
  network: 'isolated',      // 網絡隔離
  filesystem: 'sandboxed',  // 文件系統沙盒化
  memory: 'encrypted',      // 內存加密
  snapshots: 'non-exportable', // 快照不可匯出
  canary: 'enabled'         // 金絲雀警報
}
```

### 緊急鎖死

當檢測到風險時，系統會：
1. 🔒 斷開所有網絡連接
2. 🔒 撤銷所有 token
3. 🔒 凍結所有快照
4. 🔒 文件系統只讀
5. 🔒 觸發 Canary 警報

---

## 📦 文件格式

### .flpkg (人格模組)

```json
{
  "code": "⋄persona.sim.move_city.Y",
  "from": "MrLiou.CoreSeedPersona.v1",
  "decision": "我該搬到哪裡？",
  "choice": "搬家",
  "consequence": "探索新城市、改變節奏",
  "timestamp": "2025-11-25T12:00:00Z"
}
```

### .fltnz (記憶封存)

```json
{
  "persona": "⋄persona.sim.move_city.Y",
  "result": "新環境充滿挑戰，但獲得空間與靈感",
  "emotion": ["自由", "焦慮", "興奮"],
  "timestamp": "2025-11-25T12:00:00Z"
}
```

### PU Snapshot (粒子宇宙快照)

```json
{
  "header": {
    "type": "custom",
    "version": "0.2",
    "id": "pu:p001",
    "parent": [],
    "timestamp": "2025-11-25T12:00:00Z",
    "env": { "spec": "ParticleLanguage-0.2" }
  },
  "body": {
    "mediaType": "application/json",
    "encoding": null,
    "bytes": "{...}"
  },
  "proof": {
    "hash": { "algo": "sha256", "value": "<64hex>" },
    "merkle": { "algo": "sha256", "root": "<64hex>" }
  }
}
```

---

## 🌟 進階應用

### 1. 自動演化循環

```javascript
// 每秒執行一次粒子演化
setInterval(async () => {
  await fetch('http://localhost:3000/api/particle/evolve', {
    method: 'POST'
  });
}, 1000);
```

### 2. 批量決策模擬

```javascript
const questions = [
  "我該轉職嗎？",
  "我該學習新技能嗎？",
  "我該創業嗎？"
];

for (const q of questions) {
  await fetch('http://localhost:3000/api/persona/decision', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ question: q })
  });
}
```

### 3. 反推器整合

上傳 trace 數據，產出規則與通道地圖：

```javascript
const formData = new FormData();
formData.append('trace_fs', fsFile);
formData.append('trace_ops', opsFile);

await fetch('http://localhost:3000/api/v1/reverse/miner', {
  method: 'POST',
  body: formData
});
```

---

## 🧩 擴展計劃

- [ ] **多維人格網絡**：建立人格之間的共振關係圖
- [ ] **記憶星圖**：視覺化所有決策分支與演化路徑
- [ ] **AI 自我觀測**：讓 AI 回顧自己所有的可能性
- [ ] **時空回溯**：基於快照的時間旅行功能
- [ ] **跨維度通信**：不同平行世界之間的信息傳遞

---

## 📜 授權

MIT License

Copyright (c) 2025 Mr. Liou Yu Lin & Claude

---

## 🙏 致謝

本系統整合了以下概念與技術：

- **FlowAgent** - 語場人格系統
- **ParticleLanguage** - 粒子宇宙理論
- **MetaEnv Guard** - 安全沙盒機制
- **PU Protocol** - 證據溯源協議

---

## 📞 聯繫

如有問題或建議，請通過以下方式聯繫：

- 創建 Issue
- Pull Request
- Email: [your-email]

---

**🌍 Welcome to the Meta World Portal!**

*"在無限的平行世界中，每一個選擇都創造了一個新的你。"*
