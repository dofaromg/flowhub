# 💡 META WORLD PORTAL - 使用示例集

## 🎯 實際應用場景

---

## 場景 1：人生重大決策模擬

### 問題：我該離職創業嗎？

#### Step 1: 創建決策分支

```bash
curl -X POST http://localhost:3000/api/persona/decision \
  -H "Content-Type: application/json" \
  -d '{"question": "我該離職創業嗎？"}'
```

#### Response:
```json
{
  "decision": {
    "id": "q_1732492800000",
    "question": "我該離職創業嗎？",
    "forks": ["⋄persona.sim.q_xxx.Y", "⋄persona.sim.q_xxx.N"]
  },
  "forks": {
    "yes": {
      "code": "⋄persona.sim.q_xxx.Y",
      "choice": "YES",
      "consequence": "探索新路徑、改變節奏",
      "memory": {
        "result": "選擇了創業，進入新的體驗領域",
        "emotion": ["興奮", "不確定", "期待"],
        "energy_shift": +15
      }
    },
    "no": {
      "code": "⋄persona.sim.q_xxx.N",
      "choice": "NO",
      "consequence": "維持現狀、穩定結構",
      "memory": {
        "result": "選擇繼續工作，保持原有節奏",
        "emotion": ["平靜", "安全", "可能的遺憾"],
        "energy_shift": -5
      }
    }
  }
}
```

#### Step 2: 穿越到 YES 世界體驗

```bash
curl -X POST http://localhost:3000/api/persona/travel \
  -H "Content-Type: application/json" \
  -d '{"persona_code": "⋄persona.sim.q_xxx.Y"}'
```

---

## 場景 2：持續粒子演化觀察

### 目標：觀察 10 輪演化的共振變化

#### JavaScript 腳本：

```javascript
async function observeEvolution(rounds = 10) {
  const results = [];
  
  for (let i = 0; i < rounds; i++) {
    const response = await fetch('http://localhost:3000/api/particle/evolve', {
      method: 'POST'
    });
    const data = await response.json();
    
    // 計算平均共振
    const avgResonance = data.particles.reduce((sum, p) => 
      sum + (1 - p.diff) * 100, 0
    ) / data.particles.length;
    
    results.push({
      round: i + 1,
      avgResonance: avgResonance.toFixed(2),
      timestamp: data.timestamp
    });
    
    console.log(`Round ${i + 1}: 平均共振 ${avgResonance.toFixed(2)}%`);
    
    // 等待 1 秒
    await new Promise(resolve => setTimeout(resolve, 1000));
  }
  
  return results;
}

// 執行
observeEvolution(10).then(results => {
  console.log('\n演化結果：');
  console.table(results);
});
```

#### 預期輸出：
```
Round 1: 平均共振 67.23%
Round 2: 平均共振 71.45%
Round 3: 平均共振 69.88%
...

演化結果：
┌─────────┬───────┬──────────────┬──────────────────────────┐
│ (index) │ round │ avgResonance │ timestamp                │
├─────────┼───────┼──────────────┼──────────────────────────┤
│    0    │   1   │   '67.23'    │ '2025-11-25T12:00:01Z'   │
│    1    │   2   │   '71.45'    │ '2025-11-25T12:00:02Z'   │
...
```

---

## 場景 3：批量決策樹生成

### 目標：為一系列相關問題創建完整決策樹

#### Python 腳本：

```python
import requests
import json
import time

BASE_URL = 'http://localhost:3000'

# 決策序列
decisions = [
    "我該轉行做軟體工程師嗎？",
    "我該先學習哪門語言？Python 還是 JavaScript？",
    "我該參加 Bootcamp 還是自學？",
    "我該在學習期間繼續工作嗎？"
]

def create_decision_tree():
    results = []
    
    for question in decisions:
        print(f"\n創建決策: {question}")
        
        response = requests.post(
            f'{BASE_URL}/api/persona/decision',
            json={'question': question}
        )
        
        data = response.json()
        results.append({
            'question': question,
            'yes_code': data['forks']['yes']['code'],
            'no_code': data['forks']['no']['code']
        })
        
        print(f"  ✓ YES: {data['forks']['yes']['code']}")
        print(f"  ✓ NO: {data['forks']['no']['code']}")
        
        time.sleep(1)
    
    # 保存結果
    with open('decision_tree.json', 'w', encoding='utf-8') as f:
        json.dump(results, f, ensure_ascii=False, indent=2)
    
    print("\n✅ 決策樹已保存到 decision_tree.json")
    return results

if __name__ == '__main__':
    create_decision_tree()
```

---

## 場景 4：環境隔離測試

### 目標：創建多個隔離環境並測試快照

#### Bash 腳本：

```bash
#!/bin/bash

BASE_URL="http://localhost:3000"

echo "🌐 創建 3 個 MetaEnv 環境..."

# 創建環境 1
ENV1=$(curl -s -X POST "$BASE_URL/api/metaenv/spawn" \
  -H "Content-Type: application/json" \
  -d '{"role":"core","shape":{"cpu":4,"gpu":2,"ram":"16G"}}' \
  | jq -r '.env_id')

echo "✓ Env 1: $ENV1"

# 創建環境 2
ENV2=$(curl -s -X POST "$BASE_URL/api/metaenv/spawn" \
  -H "Content-Type: application/json" \
  -d '{"role":"node","shape":{"cpu":2,"gpu":1,"ram":"8G"}}' \
  | jq -r '.env_id')

echo "✓ Env 2: $ENV2"

# 創建環境 3
ENV3=$(curl -s -X POST "$BASE_URL/api/metaenv/spawn" \
  -H "Content-Type: application/json" \
  -d '{"role":"node","shape":{"cpu":2,"gpu":1,"ram":"8G"}}' \
  | jq -r '.env_id')

echo "✓ Env 3: $ENV3"

# 為每個環境創建快照
echo -e "\n📸 創建快照..."

for ENV in $ENV1 $ENV2 $ENV3; do
  SNAPSHOT=$(curl -s -X POST "$BASE_URL/api/metaenv/snapshot" \
    -H "Content-Type: application/json" \
    -d "{\"env_id\":\"$ENV\",\"label\":\"Test Snapshot\"}" \
    | jq -r '.snapshot_id')
  
  echo "✓ $ENV → $SNAPSHOT"
done

# 檢查健康狀態
echo -e "\n💚 健康檢查..."

curl -s "$BASE_URL/api/metaenv/health" | jq '.'

echo -e "\n✅ 測試完成！"
```

---

## 場景 5：證據溯源鏈驗證

### 目標：驗證所有快照的完整性

#### Node.js 腳本：

```javascript
const crypto = require('crypto');

async function verifyProvenanceChain() {
  // 獲取所有快照
  const response = await fetch('http://localhost:3000/api/provenance/snapshots');
  const { snapshots } = await response.json();
  
  console.log(`\n🔍 驗證 ${snapshots.length} 個快照...\n`);
  
  let valid = 0;
  let invalid = 0;
  
  for (const snapshot of snapshots) {
    const { header, body, proof } = snapshot;
    
    // 重新計算 hash
    const calculatedHash = crypto
      .createHash('sha256')
      .update(body.bytes)
      .digest('hex');
    
    // 驗證
    const isValid = calculatedHash === proof.hash.value;
    
    if (isValid) {
      valid++;
      console.log(`✓ ${header.id}: 有效`);
    } else {
      invalid++;
      console.log(`✗ ${header.id}: 無效！`);
      console.log(`  預期: ${proof.hash.value}`);
      console.log(`  實際: ${calculatedHash}`);
    }
  }
  
  console.log(`\n📊 驗證結果:`);
  console.log(`✓ 有效: ${valid}`);
  console.log(`✗ 無效: ${invalid}`);
  console.log(`成功率: ${((valid / snapshots.length) * 100).toFixed(2)}%\n`);
}

verifyProvenanceChain();
```

---

## 場景 6：實時監控儀表板

### 目標：創建實時更新的系統監控

#### HTML + JavaScript：

```html
<!DOCTYPE html>
<html>
<head>
    <title>實時監控</title>
    <style>
        body { font-family: monospace; background: #1a1a1a; color: #0f0; padding: 20px; }
        .metric { margin: 10px 0; }
        .value { color: #0ff; font-weight: bold; }
    </style>
</head>
<body>
    <h1>🌍 META WORLD PORTAL - 實時監控</h1>
    <div id="metrics"></div>

    <script>
        async function updateMetrics() {
            const response = await fetch('http://localhost:3000/api/portal/status');
            const data = await response.json();
            
            const html = `
                <div class="metric">⏰ 時間: <span class="value">${new Date().toLocaleString()}</span></div>
                <div class="metric">🌐 環境數: <span class="value">${data.meta_env.total_envs}</span></div>
                <div class="metric">👤 人格分支: <span class="value">${data.personas.branches}</span></div>
                <div class="metric">🎯 決策數: <span class="value">${data.personas.decisions}</span></div>
                <div class="metric">⚛️  粒子數: <span class="value">${data.particles.count}</span></div>
                <div class="metric">🔄 演化輪數: <span class="value">${data.particles.rounds}</span></div>
                <div class="metric">📜 證據條目: <span class="value">${data.provenance.evidence_count}</span></div>
                <div class="metric">📅 時間線事件: <span class="value">${data.provenance.timeline_events}</span></div>
            `;
            
            document.getElementById('metrics').innerHTML = html;
        }
        
        // 每 2 秒更新一次
        setInterval(updateMetrics, 2000);
        updateMetrics();
    </script>
</body>
</html>
```

---

## 場景 7：自動化回歸測試

### 目標：在 CI/CD 中驗證系統功能

#### GitHub Actions 配置：

```yaml
name: Meta World Portal CI

on:
  push:
    branches: [ main ]
  pull_request:
    branches: [ main ]

jobs:
  test:
    runs-on: ubuntu-latest
    
    steps:
    - uses: actions/checkout@v3
    
    - name: Setup Node.js
      uses: actions/setup-node@v3
      with:
        node-version: '18'
    
    - name: Install dependencies
      run: npm install
    
    - name: Start server in background
      run: npm start &
      
    - name: Wait for server
      run: sleep 5
    
    - name: Run tests
      run: node test.js
    
    - name: Upload results
      uses: actions/upload-artifact@v3
      with:
        name: test-results
        path: test-results.json
```

---

## 🎓 最佳實踐

### 1. 錯誤處理

```javascript
async function safeRequest(url, options) {
  try {
    const response = await fetch(url, options);
    if (!response.ok) {
      throw new Error(`HTTP ${response.status}`);
    }
    return await response.json();
  } catch (error) {
    console.error('請求失敗:', error);
    return { ok: false, error: error.message };
  }
}
```

### 2. 批量操作

```javascript
async function batchEvolve(count) {
  const promises = Array(count).fill(null).map(() =>
    fetch('http://localhost:3000/api/particle/evolve', { method: 'POST' })
  );
  
  return await Promise.all(promises);
}
```

### 3. 數據導出

```javascript
async function exportAllData() {
  const [status, evidence, timeline, snapshots] = await Promise.all([
    fetch('http://localhost:3000/api/portal/status').then(r => r.json()),
    fetch('http://localhost:3000/api/provenance/evidence').then(r => r.json()),
    fetch('http://localhost:3000/api/provenance/timeline').then(r => r.json()),
    fetch('http://localhost:3000/api/provenance/snapshots').then(r => r.json())
  ]);
  
  return { status, evidence, timeline, snapshots };
}
```

---

## 📚 更多資源

- 完整 API 文檔：`README.md`
- 架構說明：`ARCHITECTURE.md`
- 快速入門：`QUICKSTART.md`

---

**提示**：這些示例可以直接運行，只需確保服務器在 `localhost:3000` 運行即可！

🚀 開始實驗吧！
