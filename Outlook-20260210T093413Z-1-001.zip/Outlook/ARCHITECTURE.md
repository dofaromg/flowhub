# 🏗️ META WORLD PORTAL - 系統架構詳解

## 📐 整體架構圖

```
┌─────────────────────────────────────────────────────────────┐
│                     WEB INTERFACE                           │
│                   (index.html)                              │
│  ┌─────────┐  ┌─────────┐  ┌─────────┐  ┌─────────┐      │
│  │Dashboard│  │Controls │  │Personas │  │Timeline │       │
│  └─────────┘  └─────────┘  └─────────┘  └─────────┘      │
└────────────────────────┬────────────────────────────────────┘
                         │ HTTP/REST API
┌────────────────────────┴────────────────────────────────────┐
│                 META WORLD PORTAL CORE                      │
│                  (meta_world_portal.js)                     │
│                                                             │
│  ┌────────────────┐  ┌────────────────┐  ┌──────────────┐ │
│  │  MetaEnv       │  │  Persona       │  │  Particle    │ │
│  │  Controller    │  │  Engine        │  │  Universe    │ │
│  │                │  │                │  │              │ │
│  │ • spawn()      │  │ • loadCore()   │  │ • fetch()    │ │
│  │ • snapshot()   │  │ • createFork() │  │ • evolve()   │ │
│  │ • lockdown()   │  │ • travel()     │  │ • resonance()│ │
│  └────────────────┘  └────────────────┘  └──────────────┘ │
│                                                             │
│  ┌────────────────────────────────────────────────────────┐ │
│  │           Provenance System                            │ │
│  │  • Evidence Log  • Timeline  • PU Snapshots           │ │
│  └────────────────────────────────────────────────────────┘ │
└──────────────────────┬──────────────────────────────────────┘
                       │
┌──────────────────────┴──────────────────────────────────────┐
│                    DATA LAYER                               │
│                                                             │
│  ┌──────────────┐    ┌──────────────┐    ┌──────────────┐ │
│  │   Upstash    │    │  File System │    │   Memory     │ │
│  │   Redis      │    │  (CSV/JSON)  │    │   (State)    │ │
│  │              │    │              │    │              │ │
│  │ • p001       │    │ • EVIDENCE   │    │ • Personas   │ │
│  │ • p002       │    │ • TIMELINE   │    │ • Particles  │ │
│  │ • p003       │    │ • SNAPSHOT   │    │ • History    │ │
│  └──────────────┘    └──────────────┘    └──────────────┘ │
└─────────────────────────────────────────────────────────────┘
```

---

## 🧩 核心模組詳解

### 1. MetaEnvController - 元環境控制器

**職責**：管理安全隔離的執行環境

**關鍵功能**：
- `spawnEnv()` - 創建新的沙盒環境
- `applyPolicy()` - 套用安全政策（Guard.v1）
- `createSnapshot()` - 創建加密快照
- `applyChannelMap()` - 掛載通道地圖
- `lockdown()` - 緊急鎖死機制

**數據結構**：
```javascript
environment = {
  id: "env_xxx",
  role: "core" | "node",
  shape: { cpu, gpu, ram },
  policy: "Mr.liou.MetaCode.Guard.v1",
  status: "running" | "locked" | "terminated",
  attestation: "sha256_hash"
}
```

**流程圖**：
```
User Request
     ↓
spawnEnv()
     ↓
Generate Env ID
     ↓
Apply Policy
     ↓
Create Attestation
     ↓
Return Env Handle
```

---

### 2. ParallelPersonaEngine - 平行人格引擎

**職責**：模擬決策分支與平行人格

**關鍵功能**：
- `loadCorePersona()` - 載入核心人格
- `createDecisionFork()` - 創建 YES/NO 分支
- `simulateMemory()` - 模擬記憶與後果
- `exportPersona()` - 導出 .flpkg 格式
- `exportMemory()` - 導出 .fltnz 格式

**人格分支邏輯**：
```
        核心人格
            │
    ┌───────┴───────┐
    │               │
  YES 分支        NO 分支
    │               │
探索新路徑      維持現狀
    │               │
記憶模擬        記憶模擬
```

**數據結構**：
```javascript
persona = {
  code: "⋄persona.sim.xxx.Y",
  from: "CorePersona",
  decision: "問題",
  choice: "YES" | "NO",
  consequence: "後果描述",
  memory: {
    result: "結果",
    emotion: ["情緒1", "情緒2"],
    energy_shift: +15 | -5
  }
}
```

---

### 3. ParticleUniverse - 粒子宇宙

**職責**：管理粒子演化與共振

**三大沙盒公式**：
```javascript
Child1: 反轉 (reverse)
  "01101" → "10110"

Child2: 01 互換 (swap)
  "01101" → "10010"

Child3: 翻轉 (flip)
  "01101" → "10010"
```

**演化循環**：
```
粒子 → 選擇沙盒 → 演化 → 放大 → 縮小 → 計算差異 → 記錄歷史
  ↑                                                      │
  └──────────────────────────────────────────────────────┘
```

**共振計算**：
```javascript
resonance = (1 - diff) * 100
// diff 越小，共振越強
// diff = 0 → resonance = 100%
// diff = 1 → resonance = 0%
```

---

### 4. ProvenanceSystem - 證據溯源系統

**職責**：記錄所有事件與快照

**三大核心文件**：

#### EVIDENCE_LOG.csv
```csv
date,title,type,url_or_path,sha256,notes
2025-11-25,Snapshot p001,file,SNAPSHOT-p001.json,abc123...,自動生成
```

#### TIMELINE.md
```markdown
# TIMELINE
- 2025-11-25 • Meta World Portal 初始化完成
- 2025-11-25 • 決策創建: 我該學習新技能嗎？
- 2025-11-25 • 穿越至平行世界: ⋄persona.sim.xxx.Y
```

#### PU Snapshot (JSON)
```json
{
  "header": {
    "id": "pu:p001",
    "timestamp": "2025-11-25T12:00:00Z",
    "env": { "spec": "ParticleLanguage-0.2" }
  },
  "body": { ... },
  "proof": {
    "hash": { "algo": "sha256", "value": "..." }
  }
}
```

---

## 🔄 數據流動圖

### 完整請求流程

```
1. 用戶操作 Web 介面
         ↓
2. HTTP Request → Express Server
         ↓
3. Portal 核心路由
         ↓
4. 調用對應模組
    ├─ MetaEnv
    ├─ Persona
    ├─ Particle
    └─ Provenance
         ↓
5. 執行業務邏輯
         ↓
6. 更新內部狀態
         ↓
7. 記錄證據/日誌
         ↓
8. 返回 JSON Response
         ↓
9. 前端更新 UI
```

---

## 🔐 安全機制

### Guard.v1 政策

```javascript
{
  network: 'isolated',      // 無外網
  filesystem: 'sandboxed',  // 沙盒文件系統
  memory: 'encrypted',      // 加密內存
  snapshots: 'non-exportable', // 快照不可匯出
  canary: 'enabled'         // 金絲雀觸發
}
```

### 鎖死流程

```
檢測威脅
    ↓
lockdown()
    ├─ 斷開網絡
    ├─ 撤銷 Token
    ├─ 凍結快照
    ├─ 只讀文件系統
    └─ 觸發 Canary
    ↓
記錄事件
    ↓
通知管理員
```

---

## 🎯 關鍵設計決策

### 1. 為什麼使用 Express？
- 輕量級、成熟穩定
- 豐富的中間件生態
- RESTful API 支持良好

### 2. 為什麼使用 Upstash Redis？
- 無服務器架構
- 全球低延遲
- 自動持久化

### 3. 為什麼使用 Map 而非數據庫？
- 原型階段優先速度
- 內存操作更快
- 未來可輕鬆遷移到 DB

### 4. 為什麼三個沙盒公式？
- 模擬不同演化路徑
- 產生多樣性
- 驗證共振理論

---

## 📊 性能考量

### 內存使用
- 每個粒子 ~1KB
- 每個人格 ~2KB
- 每個快照 ~5KB
- 總計約 10-50MB（取決於演化輪數）

### 並發處理
- 支持多個 MetaEnv 同時運行
- 異步 Redis 操作
- 無阻塞文件 I/O

### 擴展性
- 水平擴展：多實例 + Redis Cluster
- 垂直擴展：增加內存與 CPU
- 微服務化：拆分各模組為獨立服務

---

## 🔮 未來擴展方向

### 短期（1-3個月）
- [ ] WebSocket 實時通信
- [ ] 持久化到 MongoDB/PostgreSQL
- [ ] 用戶認證與權限管理
- [ ] Docker 容器化部署

### 中期（3-6個月）
- [ ] 多維人格關係圖
- [ ] 視覺化粒子演化動畫
- [ ] AI 輔助決策分析
- [ ] 移動端 App

### 長期（6-12個月）
- [ ] 區塊鏈證據鏈
- [ ] 去中心化存儲
- [ ] 跨維度通信協議
- [ ] 量子態疊加模擬

---

## 📖 相關資源

- **FlowAgent 文檔**：語場人格系統理論基礎
- **ParticleLanguage Spec**：粒子宇宙協議規範
- **MetaEnv API**：沙盒控制 OpenAPI 文檔
- **PU Protocol**：證據溯源格式標準

---

## 🤝 貢獻指南

歡迎貢獻！請遵循：

1. Fork 本項目
2. 創建功能分支
3. 提交清晰的 commit
4. 運行測試確保通過
5. 提交 Pull Request

---

**構建者**：Mr. Liou Yu Lin & Claude  
**版本**：v1.0.0  
**最後更新**：2025-11-25

---

> "理解架構，就是理解思想的結構。"
