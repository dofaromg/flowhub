# 🚀 實戰部署指南

## 部署策略總覽

```
本地開發 → Docker容器 → Kubernetes集群 → 生產環境
    ↓           ↓              ↓              ↓
  快速測試   隔離運行      自動擴展      高可用性
```

---

## 📦 方案一：本地快速啟動

### 前置需求

```bash
Node.js >= 18.0.0
npm >= 9.0.0
Redis (可選，用於分散式快取)
```

### 安裝依賴

```bash
cd MRLiou_TotalCore_Unity_v1
npm install
```

### 快速啟動

```bash
# 1. 運行完整系統演示
node super_integrated_master.js

# 2. 運行頻率場系統
node frequency_field_system.js

# 3. 運行維度升降系統
node dimensional_escalation.js

# 4. 運行整合進化引擎
node integrated_evolution_engine.js

# 5. 運行起源崩塌演示
node demo_complete_return.js
```

### 預期輸出

```
╔══════════════════════════════════════════════════════════════╗
║   🌌 SUPER INTEGRATED MASTER SYSTEM v2.0                     ║
╚══════════════════════════════════════════════════════════════╝

🔧 初始化四層架構...
✅ 四層架構初始化完成

📊 最終統計:
   處理週期: 2
   進化週期: 2
   運行時間: 0.41s
```

---

## 🐳 方案二：Docker 容器部署

### Dockerfile

```dockerfile
FROM node:18-alpine

WORKDIR /app

# 複製文件
COPY package*.json ./
COPY *.js ./
COPY *.md ./

# 安裝依賴
RUN npm install --production

# 環境變數
ENV NODE_ENV=production
ENV PORT=3000

# 健康檢查
HEALTHCHECK --interval=30s --timeout=3s \
  CMD node -e "console.log('healthy')" || exit 1

# 啟動命令
CMD ["node", "super_integrated_master.js"]
```

### 構建映像

```bash
# 構建
docker build -t mrliou-totalcore:v2.0 .

# 運行
docker run -d \
  --name totalcore \
  -p 3000:3000 \
  --restart unless-stopped \
  mrliou-totalcore:v2.0

# 查看日誌
docker logs -f totalcore

# 進入容器
docker exec -it totalcore sh
```

### Docker Compose

```yaml
version: '3.8'

services:
  totalcore:
    build: .
    container_name: mrliou-totalcore
    ports:
      - "3000:3000"
    environment:
      - NODE_ENV=production
      - REDIS_URL=redis://redis:6379
    depends_on:
      - redis
    restart: unless-stopped
    networks:
      - totalcore-network

  redis:
    image: redis:7-alpine
    container_name: totalcore-redis
    ports:
      - "6379:6379"
    volumes:
      - redis-data:/data
    restart: unless-stopped
    networks:
      - totalcore-network

volumes:
  redis-data:

networks:
  totalcore-network:
    driver: bridge
```

### 啟動 Compose

```bash
docker-compose up -d
docker-compose ps
docker-compose logs -f
```

---

## ☸️ 方案三：Kubernetes 集群部署

### 命名空間

```yaml
# namespace.yaml
apiVersion: v1
kind: Namespace
metadata:
  name: totalcore
  labels:
    name: totalcore
```

### ConfigMap

```yaml
# configmap.yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: totalcore-config
  namespace: totalcore
data:
  NODE_ENV: "production"
  LOG_LEVEL: "info"
  CACHE_TTL: "120000"
  MAX_CACHE_SIZE: "1000"
```

### Deployment

```yaml
# deployment.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: totalcore
  namespace: totalcore
  labels:
    app: totalcore
    version: v2.0
spec:
  replicas: 3
  selector:
    matchLabels:
      app: totalcore
  template:
    metadata:
      labels:
        app: totalcore
        version: v2.0
    spec:
      containers:
      - name: totalcore
        image: mrliou-totalcore:v2.0
        ports:
        - containerPort: 3000
          name: http
        envFrom:
        - configMapRef:
            name: totalcore-config
        resources:
          requests:
            memory: "256Mi"
            cpu: "250m"
          limits:
            memory: "512Mi"
            cpu: "500m"
        livenessProbe:
          httpGet:
            path: /health
            port: 3000
          initialDelaySeconds: 30
          periodSeconds: 10
        readinessProbe:
          httpGet:
            path: /ready
            port: 3000
          initialDelaySeconds: 5
          periodSeconds: 5
```

### Service

```yaml
# service.yaml
apiVersion: v1
kind: Service
metadata:
  name: totalcore-service
  namespace: totalcore
spec:
  type: LoadBalancer
  selector:
    app: totalcore
  ports:
  - protocol: TCP
    port: 80
    targetPort: 3000
```

### HPA (水平自動擴展)

```yaml
# hpa.yaml
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: totalcore-hpa
  namespace: totalcore
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: totalcore
  minReplicas: 3
  maxReplicas: 10
  metrics:
  - type: Resource
    resource:
      name: cpu
      target:
        type: Utilization
        averageUtilization: 70
  - type: Resource
    resource:
      name: memory
      target:
        type: Utilization
        averageUtilization: 80
```

### 部署命令

```bash
# 應用所有配置
kubectl apply -f namespace.yaml
kubectl apply -f configmap.yaml
kubectl apply -f deployment.yaml
kubectl apply -f service.yaml
kubectl apply -f hpa.yaml

# 查看狀態
kubectl get all -n totalcore

# 查看日誌
kubectl logs -f -n totalcore deployment/totalcore

# 擴展實例
kubectl scale deployment totalcore -n totalcore --replicas=5

# 滾動更新
kubectl set image deployment/totalcore \
  totalcore=mrliou-totalcore:v2.1 -n totalcore

# 回滾
kubectl rollout undo deployment/totalcore -n totalcore
```

---

## 🌐 方案四：雲端部署

### AWS ECS

```json
{
  "family": "mrliou-totalcore",
  "networkMode": "awsvpc",
  "requiresCompatibilities": ["FARGATE"],
  "cpu": "512",
  "memory": "1024",
  "containerDefinitions": [
    {
      "name": "totalcore",
      "image": "mrliou-totalcore:v2.0",
      "portMappings": [
        {
          "containerPort": 3000,
          "protocol": "tcp"
        }
      ],
      "environment": [
        {
          "name": "NODE_ENV",
          "value": "production"
        }
      ],
      "logConfiguration": {
        "logDriver": "awslogs",
        "options": {
          "awslogs-group": "/ecs/totalcore",
          "awslogs-region": "us-east-1",
          "awslogs-stream-prefix": "ecs"
        }
      }
    }
  ]
}
```

### Google Cloud Run

```bash
# 構建並推送到 GCR
gcloud builds submit --tag gcr.io/PROJECT_ID/totalcore:v2.0

# 部署到 Cloud Run
gcloud run deploy totalcore \
  --image gcr.io/PROJECT_ID/totalcore:v2.0 \
  --platform managed \
  --region us-central1 \
  --allow-unauthenticated \
  --memory 1Gi \
  --cpu 2 \
  --min-instances 1 \
  --max-instances 10
```

### Azure Container Instances

```bash
# 創建容器組
az container create \
  --resource-group totalcore-rg \
  --name totalcore \
  --image mrliou-totalcore:v2.0 \
  --cpu 2 \
  --memory 2 \
  --ports 3000 \
  --dns-name-label totalcore \
  --restart-policy Always
```

---

## 📊 監控與日誌

### Prometheus + Grafana

```yaml
# prometheus.yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: prometheus-config
  namespace: totalcore
data:
  prometheus.yml: |
    global:
      scrape_interval: 15s
    scrape_configs:
      - job_name: 'totalcore'
        kubernetes_sd_configs:
          - role: pod
            namespaces:
              names:
                - totalcore
        relabel_configs:
          - source_labels: [__meta_kubernetes_pod_label_app]
            action: keep
            regex: totalcore
```

### ELK Stack 日誌

```yaml
# filebeat.yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: filebeat-config
  namespace: totalcore
data:
  filebeat.yml: |
    filebeat.inputs:
    - type: container
      paths:
        - /var/log/containers/totalcore-*.log
    output.elasticsearch:
      hosts: ['elasticsearch:9200']
    setup.kibana:
      host: "kibana:5601"
```

---

## 🔒 安全配置

### Secrets 管理

```yaml
# secrets.yaml
apiVersion: v1
kind: Secret
metadata:
  name: totalcore-secrets
  namespace: totalcore
type: Opaque
data:
  REDIS_PASSWORD: <base64-encoded>
  API_KEY: <base64-encoded>
```

### Network Policies

```yaml
# network-policy.yaml
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: totalcore-netpol
  namespace: totalcore
spec:
  podSelector:
    matchLabels:
      app: totalcore
  policyTypes:
  - Ingress
  - Egress
  ingress:
  - from:
    - podSelector:
        matchLabels:
          role: frontend
    ports:
    - protocol: TCP
      port: 3000
  egress:
  - to:
    - podSelector:
        matchLabels:
          role: redis
    ports:
    - protocol: TCP
      port: 6379
```

---

## 🧪 測試與驗證

### 健康檢查端點

```javascript
// health.js
export function healthCheck() {
  return {
    status: 'healthy',
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
    memory: process.memoryUsage(),
    layers: {
      L0: 'active',
      L1: 'active',
      L2: 'active',
      L3: 'active'
    }
  };
}
```

### 壓力測試

```bash
# 使用 Apache Bench
ab -n 1000 -c 10 http://localhost:3000/api/process

# 使用 k6
k6 run --vus 10 --duration 30s load-test.js
```

### 集成測試

```bash
npm test
npm run test:integration
npm run test:e2e
```

---

## 📈 擴展配置

### Redis 集群

```yaml
# redis-cluster.yaml
apiVersion: apps/v1
kind: StatefulSet
metadata:
  name: redis-cluster
  namespace: totalcore
spec:
  serviceName: redis-cluster
  replicas: 6
  selector:
    matchLabels:
      app: redis-cluster
  template:
    metadata:
      labels:
        app: redis-cluster
    spec:
      containers:
      - name: redis
        image: redis:7-alpine
        command: ["redis-server"]
        args: ["--cluster-enabled", "yes"]
        ports:
        - containerPort: 6379
```

### 分散式追蹤 (Jaeger)

```yaml
# jaeger.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: jaeger
  namespace: totalcore
spec:
  replicas: 1
  selector:
    matchLabels:
      app: jaeger
  template:
    metadata:
      labels:
        app: jaeger
    spec:
      containers:
      - name: jaeger
        image: jaegertracing/all-in-one:latest
        ports:
        - containerPort: 16686
        - containerPort: 14268
```

---

## 🔧 運維工具

### 備份腳本

```bash
#!/bin/bash
# backup.sh

DATE=$(date +%Y%m%d_%H%M%S)
BACKUP_DIR="/backups/totalcore"

# 備份 Redis
redis-cli --rdb /tmp/dump.rdb
mv /tmp/dump.rdb $BACKUP_DIR/redis_$DATE.rdb

# 備份配置
kubectl get all -n totalcore -o yaml > $BACKUP_DIR/k8s_$DATE.yaml

# 壓縮
tar -czf $BACKUP_DIR/backup_$DATE.tar.gz $BACKUP_DIR/*_$DATE.*

# 清理舊備份（保留30天）
find $BACKUP_DIR -type f -mtime +30 -delete
```

### 自動恢復

```bash
#!/bin/bash
# restore.sh

BACKUP_FILE=$1

# 解壓
tar -xzf $BACKUP_FILE -C /tmp/restore

# 恢復 Redis
redis-cli --pipe < /tmp/restore/redis_*.rdb

# 恢復 K8s
kubectl apply -f /tmp/restore/k8s_*.yaml
```

---

## 📊 性能調優

### Node.js 優化

```bash
# 增加堆內存
node --max-old-space-size=4096 super_integrated_master.js

# 啟用 CPU profiling
node --prof super_integrated_master.js

# 分析 profile
node --prof-process isolate-*.log > processed.txt
```

### Kubernetes 資源限制

```yaml
resources:
  requests:
    memory: "512Mi"
    cpu: "500m"
  limits:
    memory: "2Gi"
    cpu: "2000m"
```

---

## 🚦 CI/CD 管道

### GitHub Actions

```yaml
# .github/workflows/deploy.yml
name: Deploy TotalCore

on:
  push:
    branches: [main]

jobs:
  build-and-deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      
      - name: Build Docker image
        run: docker build -t mrliou-totalcore:${{ github.sha }} .
      
      - name: Push to registry
        run: docker push mrliou-totalcore:${{ github.sha }}
      
      - name: Deploy to K8s
        run: |
          kubectl set image deployment/totalcore \
            totalcore=mrliou-totalcore:${{ github.sha }} \
            -n totalcore
```

---

## 📝 部署檢查清單

### 部署前

- [ ] 代碼審查完成
- [ ] 單元測試通過
- [ ] 集成測試通過
- [ ] 性能測試達標
- [ ] 安全掃描無高危
- [ ] 文檔更新完成

### 部署中

- [ ] 備份當前版本
- [ ] 執行滾動更新
- [ ] 監控錯誤日誌
- [ ] 驗證健康檢查
- [ ] 測試關鍵功能

### 部署後

- [ ] 驗證所有功能
- [ ] 檢查性能指標
- [ ] 確認監控正常
- [ ] 更新部署文檔
- [ ] 通知相關人員

---

## 🆘 故障排除

### 常見問題

**Q: 容器啟動失敗**
```bash
# 檢查日誌
docker logs totalcore

# 檢查資源
docker stats totalcore
```

**Q: 性能下降**
```bash
# 檢查 CPU/Memory
kubectl top pods -n totalcore

# 查看慢查詢
redis-cli SLOWLOG GET 10
```

**Q: 連接問題**
```bash
# 檢查網絡
kubectl exec -it pod-name -n totalcore -- ping redis

# 檢查 DNS
kubectl exec -it pod-name -n totalcore -- nslookup redis
```

---

## 🎯 下一步

選擇你的部署方案：

1. **快速原型** → 本地啟動
2. **開發環境** → Docker Compose
3. **生產環境** → Kubernetes
4. **無伺服器** → Cloud Run / Lambda

**推薦路徑**: 本地測試 → Docker容器 → K8s集群

---

**準備好部署了嗎？** 🚀
