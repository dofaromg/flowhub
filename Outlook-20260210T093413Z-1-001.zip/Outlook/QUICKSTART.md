# 🚀 META WORLD PORTAL - 快速入門指南

## 📥 下載後的步驟

### 1. 解壓文件
將所有文件解壓到你的工作目錄

### 2. 安裝 Node.js（如果還沒有）
訪問 https://nodejs.org/ 下載並安裝最新版本

### 3. 啟動系統

有兩種方式：

#### 方式 A：使用快速啟動腳本（推薦）
```bash
node start.js
```
這會自動安裝依賴並啟動服務器

#### 方式 B：手動啟動
```bash
# 安裝依賴
npm install

# 啟動服務器
npm start
```

### 4. 訪問 Web 介面
打開瀏覽器，訪問：
```
http://localhost:3000
```

### 5. 開始探索！

點擊 **"初始化系統"** 按鈕開始使用

---

## 🎯 快速測試

想驗證系統是否正常工作？在另一個終端窗口運行：

```bash
node test.js
```

這會執行完整的系統測試套件

---

## 📁 文件結構

```
meta-world-portal/
├── meta_world_portal.js    # 主服務器（後端）
├── public/
│   └── index.html          # Web 介面（前端）
├── package.json            # 依賴配置
├── start.js                # 快速啟動腳本
├── test.js                 # 測試套件
├── README.md              # 完整文檔
└── QUICKSTART.md          # 本文件
```

---

## 🔧 系統要求

- **Node.js**: v18.0.0 或更高
- **內存**: 至少 2GB 可用
- **瀏覽器**: Chrome, Firefox, Safari, Edge（現代版本）

---

## 🌟 第一次使用建議

1. **初始化系統** - 載入母體粒子和核心人格
2. **執行粒子演化** - 看看粒子如何演化
3. **創建決策分支** - 試試輸入 "我該學習新技能嗎？"
4. **穿越平行世界** - 點擊任意人格卡片

---

## ❓ 常見問題

### Q: 端口 3000 被佔用怎麼辦？
A: 設置環境變量 `PORT=另一個端口號`
```bash
PORT=8080 node meta_world_portal.js
```

### Q: Redis 連接失敗？
A: 檢查你的網絡連接，或更新 Redis URL

### Q: 網頁顯示 "Cannot GET /"？
A: 確保 `public/index.html` 文件存在

---

## 📚 進階使用

參見 `README.md` 獲取：
- 完整 API 文檔
- 系統架構說明
- 安全機制詳情
- 文件格式規範

---

## 🆘 需要幫助？

1. 查看 README.md 完整文檔
2. 運行 `node test.js` 診斷問題
3. 檢查服務器日誌輸出

---

## 🎉 開始你的元世界之旅！

記住：

> "在無限的平行世界中，每一個選擇都創造了一個新的你。"

祝探索愉快！🌍✨
