#!/bin/bash

# 3D AI Camera - 安裝腳本
# Author: MR.liou

set -e

echo "╔══════════════════════════════════════════════════════════════╗"
echo "║         3D AI Camera - Installation Script                   ║"
echo "║         Origin Signature: MrLiouWord                         ║"
echo "╚══════════════════════════════════════════════════════════════╝"
echo ""

# 檢查 Python
echo "📦 Checking Python..."
if command -v python3 &> /dev/null; then
    PYTHON_VERSION=$(python3 --version)
    echo "   ✅ Found: $PYTHON_VERSION"
else
    echo "   ❌ Python 3 not found. Please install Python 3.10+"
    exit 1
fi

# 檢查 Node.js
echo "📦 Checking Node.js..."
if command -v node &> /dev/null; then
    NODE_VERSION=$(node --version)
    echo "   ✅ Found: Node.js $NODE_VERSION"
else
    echo "   ⚠️  Node.js not found. Worker deployment will not work."
fi

# 設定 Python 環境
echo ""
echo "🐍 Setting up Python environment..."
cd pipeline

if [ ! -d ".venv" ]; then
    python3 -m venv .venv
    echo "   ✅ Virtual environment created"
else
    echo "   ℹ️  Virtual environment already exists"
fi

source .venv/bin/activate
pip install --upgrade pip -q
pip install -r requirements.txt -q
echo "   ✅ Dependencies installed"

cd ..

# 設定 Node.js 環境
if command -v node &> /dev/null; then
    echo ""
    echo "📦 Setting up Node.js environment..."
    cd worker
    npm install -q
    echo "   ✅ Node dependencies installed"
    cd ..
fi

# 創建資料目錄
echo ""
echo "📁 Creating data directories..."
mkdir -p pipeline/data/input/images
mkdir -p pipeline/data/outputs
echo "   ✅ Directories created"

# 完成
echo ""
echo "╔══════════════════════════════════════════════════════════════╗"
echo "║                    Installation Complete!                    ║"
echo "╠══════════════════════════════════════════════════════════════╣"
echo "║                                                              ║"
echo "║  Next Steps:                                                 ║"
echo "║                                                              ║"
echo "║  1. iOS Development:                                         ║"
echo "║     cd ios && open 3DAICamera.xcodeproj                     ║"
echo "║                                                              ║"
echo "║  2. Python Pipeline:                                         ║"
echo "║     cd pipeline                                              ║"
echo "║     source .venv/bin/activate                                ║"
echo "║     python -m src.main                                       ║"
echo "║                                                              ║"
echo "║  3. Cloudflare Worker:                                       ║"
echo "║     cd worker                                                ║"
echo "║     npm run dev                                              ║"
echo "║                                                              ║"
echo "║  Documentation: docs/QUICKSTART.md                           ║"
echo "║                                                              ║"
echo "╚══════════════════════════════════════════════════════════════╝"
