# 3D AI Camera - 快速開始

## 環境需求

### iOS 開發
- macOS 14+
- Xcode 15+
- iOS 17.0+ 設備（需 LiDAR：iPhone 12 Pro 或更新）

### Python 管線
- Python 3.10+
- pip / conda

### Cloudflare Worker
- Node.js 18+
- Cloudflare 帳號

---

## 1. iOS App 開發

### 1.1 開啟專案

```bash
cd ios
open 3DAICamera.xcodeproj
```

### 1.2 設定簽名

1. 選擇專案 → Signing & Capabilities
2. 選擇您的開發團隊
3. 確認 Bundle Identifier 唯一

### 1.3 執行

1. 連接 iPhone（需要 LiDAR）
2. 選擇設備
3. Cmd + R 執行

### 1.4 測試功能

- **掃描**：點擊相機圖示開始 LiDAR 掃描
- **品質**：注意右上角即時品質指示器
- **缺口**：掃描完成後查看熱圖分析

---

## 2. Python 管線

### 2.1 安裝

```bash
cd pipeline

# 建立虛擬環境
python -m venv .venv

# 啟用
source .venv/bin/activate  # macOS/Linux
# 或 .venv\Scripts\activate  # Windows

# 安裝依賴
pip install -r requirements.txt
```

### 2.2 準備測試資料

```bash
mkdir -p data/input/images
# 放入至少 20 張照片
```

### 2.3 執行

```bash
python -m src.main --config config/config.yaml
```

### 2.4 查看輸出

```
data/outputs/
├── heatmaps/          # 熱圖
├── overlays/          # 疊加圖
├── metrics.json       # 指標
├── links.json         # 視角關聯
├── suggestions.json   # 補拍建議
└── pipeline_report.json
```

---

## 3. Cloudflare Worker

### 3.1 安裝

```bash
cd worker
npm install
```

### 3.2 設定 KV

```bash
# 創建 KV 命名空間
wrangler kv:namespace create "ORIGIN_KV"

# 更新 wrangler.toml 中的 id
```

### 3.3 本地開發

```bash
npm run dev
# 訪問 http://localhost:8787
```

### 3.4 部署

```bash
npm run deploy
```

---

## 4. 測試 API

### 心跳

```bash
curl https://your-worker.workers.dev/world/heartbeat
```

### 崩塌

```bash
curl -X POST https://your-worker.workers.dev/collapse \
  -H "Content-Type: application/json" \
  -d '{
    "sessionId": "test-123",
    "frameCount": 100,
    "averageQuality": 0.85,
    "duration": 60
  }'
```

---

## 5. 整合測試

### iOS → Worker

1. 在 iOS App 設定中配置 API 端點
2. 啟動掃描
3. 完成後檢查 Worker 日誌

### Pipeline → Worker

1. 修改 config.yaml 中的 API 端點
2. 執行 pipeline
3. 檢查輸出

---

## 常見問題

### Q: LiDAR 掃描畫面黑屏？

A: 檢查 Info.plist 的相機權限：
```xml
<key>NSCameraUsageDescription</key>
<string>需要相機進行 3D 掃描</string>
```

### Q: Python 安裝 Open3D 失敗？

A: 嘗試：
```bash
pip install open3d --no-cache-dir
```

### Q: Worker 部署失敗？

A: 檢查 wrangler.toml 中的 KV 配置是否正確。

### Q: 品質分數一直很低？

A: 確保：
- 光線充足
- 移動速度適中
- 避免反光表面

---

## 下一步

- 閱讀 [架構文檔](ARCHITECTURE.md)
- 閱讀 [數學公式](MATH_FORMULAS.md)
- 閱讀 [90天計劃](90_DAY_PLAN.md)
