# 3D AI Camera - 數學公式完整文檔

## 概覽

本系統的數學基礎分為三個主要路徑：

1. **COLMAP/SfM 路徑**：相機投影、畸變校正、重投影誤差
2. **Mesh/OBJ 覆蓋路徑**：覆蓋率分析、缺口檢測
3. **共用模組**：注意力、聚合、閉環、升格

---

## 一、相機與投影（COLMAP/SfM 路徑）

### 1.1 座標轉換（世界 → 相機）

```
X_c = R · X_w + t = [x_c, y_c, z_c]ᵀ
```

其中：
- `X_w`：世界座標
- `R`：旋轉矩陣 (3×3)
- `t`：平移向量
- `X_c`：相機座標

### 1.2 針孔投影（未畸變）

```
x = x_c / z_c
y = y_c / z_c

[u]   [f_x  0   c_x] [x]
[v] = [0   f_y  c_y] [y]
                      [1]
```

### 1.3 畸變模型

#### SIMPLE_RADIAL (k₁)

```
r² = x² + y²
x' = x · (1 + k₁ · r²)
y' = y · (1 + k₁ · r²)
u = f_x · x' + c_x
v = f_y · y' + c_y
```

#### OPENCV (k₁, k₂, p₁, p₂, k₃)

```
r² = x² + y²
radial = 1 + k₁r² + k₂r⁴ + k₃r⁶

x' = x · radial + 2p₁xy + p₂(r² + 2x²)
y' = y · radial + p₁(r² + 2y²) + 2p₂xy

u = f_x · x' + c_x
v = f_y · y' + c_y
```

### 1.4 四元數 → 旋轉矩陣

COLMAP 約定：`q = (q_w, q_x, q_y, q_z)`

設 `s = ||q||⁻²`（或先單位化），旋轉矩陣：

```
R = [1-2s(q_y²+q_z²)    2s(q_xq_y-q_zq_w)   2s(q_xq_z+q_yq_w)]
    [2s(q_xq_y+q_zq_w)  1-2s(q_x²+q_z²)     2s(q_yq_z-q_xq_w)]
    [2s(q_xq_z-q_yq_w)  2s(q_yq_z+q_xq_w)   1-2s(q_x²+q_y²)  ]
```

### 1.5 重投影誤差

觀測點 `x_ij = (u_ij, v_ij)`，預測 `x̂_ij`：

```
e_ij = ||x_ij - x̂_ij||₂
```

### 1.6 魯棒損失（Huber）

```
ρ_δ(e) = {
  0.5 · e²           if |e| ≤ δ
  δ · (|e| - 0.5δ)   if |e| > δ
}

ẽ_ij = ρ_δ(e_ij)
```

---

## 二、注意力加權與熱圖聚合（共用）

### 2.1 注意力權重

#### Simple（中心性）

設影像中心 `(c_x, c_y)`：

```
A_i(u, v) = 1 - sqrt((u-c_x)²/(W/2)² + (v-c_y)²/(H/2)²)
```

並縮放到 `[0, 1]`。

#### ViT 近似（選配）

取最後特徵 `F` 與 CLS 特徵 `f_cls` 的 cosine 相似度：

```
A_i(u, v) = (max{0, ⟨F(u,v), f_cls⟩ / (||F(u,v)|| · ||f_cls||)} - min) / (max - min)
```

### 2.2 注意力加權誤差

```
ē_ij = A_i(u_ij, v_ij) · ẽ_ij
```

### 2.3 影像域熱圖聚合

對映到像素附近做聚合：

```
H_i(u, v) = Agg{j: x̂_ij ≈ (u, v)}(ē_ij)
```

常用聚合：`max`（凸顯最壞情形）或 `mean`。

### 2.4 全圖統計指標

- **p 分位**：`P_p(H_i) = quantile({H_i(u,v)}, p)`（常用 p=0.9）
- **覆蓋率**：`cov_i = (1/HW) · Σ 𝟙[H_i(u,v) > 0]`

---

## 三、反算（影像域 → 3D 域）

### 3.1 3D 點異常分數

把每個 3D 點的異常分數定義為可見視角的加權平均：

```
a_j = Σ(w_ij · H_i(⌊x_ij⌋)) / Σw_ij

w_ij = A_i(x_ij)
```

**直覺**：若某 3D 點在多視角都落在高熱區，它就是「結構上的問題點」。

### 3.2 覆蓋率（Mesh 路徑）

```
c_j = (1/|V(j)|) · Σ 𝟙[X_j 在畫幅內且通過深度測試]
```

低 `c_j` 為缺口。

---

## 四、閉環與一致性

### 4.1 一致性指標

```
Δ* = median_i(p90_i)
```

### 4.2 收斂條件

```
|Δ*_{k+1} - Δ*_k| < ε
```

否則進下一輪。

---

## 五、切塊與建議

### 5.1 影像切塊

切成 `r × c` 塊，第 `(i,j)` 塊的平均分數：

```
S_ij = (1/|Ω_ij|) · Σ M(u, v)
```

其中 `M = H`（誤差熱圖）或 `M = C`（覆蓋熱圖）。

- **誤差目標**：取 `S_ij` 最大的前 K（熱區 = 問題區）
- **覆蓋目標**：取 `S_ij` 最小的前 K（低覆蓋 = 缺口）

---

## 六、視角互補（負相關）

### 6.1 相關性計算

將熱圖攤平為向量 `h_a`, `h_b`：

```
corr(a, b) = (h_a - h̄_a)ᵀ(h_b - h̄_b) / (||h_a - h̄_a|| · ||h_b - h̄_b||)
```

若 `corr(a, b) < τ`（`τ < 0`），視為「互補」並建立連結。

---

## 七、升格規則

### 7.1 錯位判定

若有區域/點集持續高 `a_j`（或低 `c_j`）且兩輪內無改善：

分支升主線，為該區塊建立**專用任務粒子**。

### 7.2 六律對應

| 律 | 公式 | 實作 |
|----|------|------|
| 放大律 | `P_{k+1} = N_k · P_k · η_k` | 互補視角增益 |
| 折疊律 | `-1+1=0` | 每輪中性重置 |
| 母體結構 | `1+1=2` | 升格為獨立粒子 |
| 一致性律 | Replay | 閉環驗證 |
| 錯位判定 | 連續高異常 | elevate.py |
| 細節驅動 | tile + per-point | 熱圖聚合 |

---

## 八、品質評分

### 8.1 銳度（Laplacian Variance）

```
sharpness = var(Laplacian(image))
```

### 8.2 曝光（Histogram Analysis）

```
q5 = percentile(histogram, 5%)
q95 = percentile(histogram, 95%)
exposure_quality = max(0, 1 - (|q5 - 0.15| + |q95 - 0.95|) / 2)
```

### 8.3 熵（Shannon Entropy）

```
H = -Σ p(x) · log₂(p(x))
```

### 8.4 總體評分

```
score = 0.5 · tanh(sharpness/200) + 0.3 · exposure + 0.2 · tanh(entropy/6)
```

---

## 參考文獻

1. COLMAP: Structure-from-Motion Revisited
2. Attention Is All You Need (Transformer)
3. Huber Loss for Robust Estimation
4. OriginCollapse: MR.liou's Particle System Theory
