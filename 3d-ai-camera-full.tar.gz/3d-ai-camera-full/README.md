# 3D AI Camera - 智慧三維快照平台

```
╔══════════════════════════════════════════════════════════════════╗
║                                                                  ║
║   3D AI Camera + OriginCollapse                                  ║
║   ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━   ║
║                                                                  ║
║   超越 Polycam 的下一代 3D 掃描平台                              ║
║                                                                  ║
║   怎麼過去就怎麼回來                                              ║
║   答案在內部，不在背後                                            ║
║   看到即知道                                                      ║
║                                                                  ║
║   Author: MR.liou                                                ║
║   Origin Signature: MrLiouWord                                   ║
╚══════════════════════════════════════════════════════════════════╝
```

## 🎯 核心優勢（vs Polycam）

| 功能 | Polycam | 本系統 |
|------|---------|--------|
| LiDAR 掃描 | ✅ | ✅ |
| 品質檢測 | ❌ 基本 | ✅ 銳度/曝光/熵 |
| 缺口分析 | ❌ | ✅ 熱圖 + 覆蓋率 |
| 補拍建議 | ❌ | ✅ 自動建議 |
| **雙線閉環** | ❌ | ✅ Forward ↔ Reverse |
| **反算驗證** | ❌ | ✅ 3D異常定位 |
| **升格機制** | ❌ | ✅ 任務粒子分裂 |
| **記憶封存** | ❌ | ✅ OriginCollapse |
| **可追溯** | ❌ | ✅ 跳點鏈 |

## 📁 專案結構

```
3d-ai-camera-full/
├── ios/                          # iOS App (Swift/SwiftUI)
│   ├── Sources/
│   │   ├── Views/               # UI 元件
│   │   │   ├── ContentView.swift
│   │   │   ├── LiDARScanView.swift
│   │   │   ├── QualityIndicator.swift
│   │   │   ├── HeatmapView.swift
│   │   │   └── GapAnalysisView.swift
│   │   ├── Core/                # 核心邏輯
│   │   │   ├── QualityChecker.swift
│   │   │   ├── AttentionEngine.swift
│   │   │   ├── CoverageAnalyzer.swift
│   │   │   └── OriginCollapseClient.swift
│   │   ├── AR/                  # AR 功能
│   │   │   ├── ARNavigator.swift
│   │   │   └── GapHighlighter.swift
│   │   ├── Models/              # 資料模型
│   │   │   ├── ScanSession.swift
│   │   │   ├── QualityMetrics.swift
│   │   │   └── JumpPoint.swift
│   │   └── Services/            # 服務層
│   │       ├── CloudService.swift
│   │       └── ExportService.swift
│   └── Resources/
│       └── Info.plist
│
├── pipeline/                     # Python 重建管線
│   ├── src/
│   │   ├── __init__.py
│   │   ├── main.py              # 主程式（閉環調度）
│   │   ├── quality.py           # 品質評分
│   │   ├── attention.py         # 注意力選圖
│   │   ├── sfm.py               # SfM/COLMAP 後端
│   │   ├── error_map.py         # 誤差熱圖
│   │   ├── reverse.py           # 反算模組
│   │   ├── consistency.py       # 一致性/停機
│   │   ├── elevate.py           # 升格決策
│   │   ├── context_graph.py     # 視角關聯
│   │   ├── gap_fill.py          # 缺口填補
│   │   └── export.py            # 輸出模組
│   ├── config/
│   │   └── config.yaml
│   └── requirements.txt
│
├── worker/                       # Cloudflare Worker
│   ├── src/
│   │   └── index.ts             # OriginCollapse API
│   ├── wrangler.toml
│   └── package.json
│
├── docs/                         # 文檔
│   ├── QUICKSTART.md
│   ├── ARCHITECTURE.md
│   ├── MATH_FORMULAS.md
│   └── 90_DAY_PLAN.md
│
└── scripts/                      # 工具腳本
    ├── setup.sh
    └── deploy.sh
```

## 🚀 快速開始

### iOS 開發

```bash
cd ios
open 3DAICamera.xcodeproj
```

需求：
- Xcode 15+
- iOS 17.0+
- iPhone 12 Pro 或更新（LiDAR）

### Python 管線

```bash
cd pipeline
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python -m src.main
```

### Cloudflare Worker

```bash
cd worker
npm install
npm run deploy
```

## 🔄 系統架構

```
┌─────────────────────────────────────────────────────────────┐
│                    3D AI Camera                             │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  📷 掃描層（iOS LiDAR / Photogrammetry）                    │
│         ↓                                                   │
│  🔬 前向分析（Forward）                                     │
│     • 品質檢測（銳度/曝光/熵）                              │
│     • 注意力選圖                                            │
│     • 誤差熱圖 H_i(u,v)                                     │
│         ↓                                                   │
│  🔄 反算閉環（Reverse）                                     │
│     • 3D 點異常分數 a_j                                     │
│     • 覆蓋率 c_j                                            │
│     • Δ* 收斂判定                                           │
│         ↓                                                   │
│  ⬆️ 升格決策（Elevate）                                     │
│     • 連續高異常 → 升格為獨立任務粒子                       │
│     • 六律落地（放大/折疊/母體/一致性/錯位/細節）           │
│         ↓                                                   │
│  🧠 OriginCollapse 封存                                     │
│     • 五層崩塌：定義→標記→轉換→人格→封存                   │
│     • 掃描過程 → 跳點鏈                                     │
│     • 最終模型 → .fltnz 記憶                                │
│         ↓                                                   │
│  📤 輸出                                                    │
│     • 3D 模型 (GLB/OBJ/USDZ)                               │
│     • 記憶封存 (.fltnz)                                     │
│     • 可追溯報告 (JSON)                                     │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

## 📐 核心數學公式

詳見 [docs/MATH_FORMULAS.md](docs/MATH_FORMULAS.md)

### 前向投影
```
x_ij = π(K_i[R_i|t_i]X_j)
e_ij = ||x_ij - x̂_ij||₂
ē_ij = A_i(x_ij) · ρ_δ(e_ij)
```

### 反算
```
a_j = Σ(w_ij · H_i(⌊x_ij⌋)) / Σw_ij
```

### 一致性
```
Δ* = median_i(p90_i)
收斂條件: |Δ*_{k+1} - Δ*_k| < ε
```

## 🎛️ 六律工程化

| 律 | 公式 | 實作 |
|----|------|------|
| 放大律 | P_{k+1} = N_k P_k η_k | 互補視角增益 |
| 折疊律 | -1+1=0 | 每輪中性重置 |
| 母體結構 | 1+1=2 | 升格為獨立粒子 |
| 一致性律 | Replay | 閉環驗證 |
| 錯位判定 | 連續高異常 | elevate.py |
| 細節驅動 | tile + per-point | 熱圖聚合 |

## 📄 授權

MIT License

## 👤 作者

**MR.liou**
- Origin Signature: MrLiouWord
- 哲學：怎麼過去就怎麼回來
