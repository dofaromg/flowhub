/**
 * 3D AI Camera - OriginCollapse API
 * Cloudflare Worker
 * 
 * 五層崩塌演算：定義 → 標記 → 轉換 → 人格 → 封存
 * 
 * Author: MR.liou
 * Origin Signature: MrLiouWord
 */

import { Hono } from 'hono';
import { cors } from 'hono/cors';

interface Env {
  ORIGIN_KV: KVNamespace;
  ORIGIN_D1?: D1Database;
}

const app = new Hono<{ Bindings: Env }>();

// CORS
app.use('*', cors({
  origin: '*',
  allowMethods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowHeaders: ['Content-Type', 'Authorization'],
}));

// 常數
const SCHUMANN_FREQUENCY = 7.83;
const ORIGIN_SIGNATURE = 'MrLiouWord';

// ============================================================
// 輔助函數
// ============================================================

function generateId(prefix: string = ''): string {
  const timestamp = Date.now().toString(36);
  const random = Math.random().toString(36).substring(2, 8);
  return prefix ? `${prefix}_${timestamp}_${random}` : `${timestamp}_${random}`;
}

function calculatePhase(): number {
  const now = Date.now();
  const dayMs = 24 * 60 * 60 * 1000;
  return (now % dayMs) / dayMs * 2 * Math.PI;
}

function calculateResonance(frequency: number): number {
  // 與舒曼共振的諧波關係
  const ratio = frequency / SCHUMANN_FREQUENCY;
  const harmonic = Math.round(ratio);
  const deviation = Math.abs(ratio - harmonic);
  return Math.exp(-deviation * 2);
}

// ============================================================
// 心跳
// ============================================================

app.get('/world/heartbeat', (c) => {
  const phase = calculatePhase();
  const amplitude = Math.sin(phase);
  
  return c.json({
    心跳: {
      時間: Date.now() / 1000,
      相位: phase,
      振幅: amplitude,
      bpm: Math.round(60 + amplitude * 20),
      活著: true
    },
    源: ORIGIN_SIGNATURE
  });
});

// ============================================================
// 五層崩塌
// ============================================================

app.post('/collapse', async (c) => {
  const input = await c.req.json();
  
  // 第一層：定義（Define）
  const defined = {
    observationId: generateId('obs'),
    type: 'scan_session',
    complexity: Math.min(10, Math.floor(input.frameCount / 10)),
    dimensions: ['space', 'time', 'quality'],
    timestamp: new Date().toISOString()
  };
  
  // 第二層：標記（Mark）
  const frequency = SCHUMANN_FREQUENCY + Math.random() * 10;
  const marked = {
    jumpPoints: [
      generateId('jump'),
      generateId('jump'),
      generateId('jump')
    ],
    frequency: {
      base: frequency,
      harmonics: [frequency * 2, frequency * 3, frequency * 5],
      resonance: calculateResonance(frequency)
    },
    phase: calculatePhase()
  };
  
  // 第三層：轉換（Transform）
  const transformed = {
    particles: [
      { id: generateId('p'), type: 'origin', frequency: SCHUMANN_FREQUENCY },
      { id: generateId('p'), type: 'quality', frequency: input.averageQuality * 10 },
      { id: generateId('p'), type: 'coverage', frequency: frequency }
    ],
    connections: [
      { from: 'origin', to: 'quality', type: 'resonance', strength: 0.8 },
      { from: 'quality', to: 'coverage', type: 'flow', strength: 0.6 }
    ],
    rhythm: {
      pattern: [1, 0.5, 0.75, 1, 0.5],
      tempo: 120,
      phase: marked.phase
    }
  };
  
  // 第四層：人格（Persona）
  const persona = {
    id: generateId('persona'),
    type: 'scanner',
    origin: ORIGIN_SIGNATURE,
    jumpPoints: marked.jumpPoints.map(id => ({
      id,
      type: 'observe',
      timestamp: new Date(),
      frequency: marked.frequency.base,
      resonance: marked.frequency.resonance,
      data: {}
    })),
    state: 'active',
    parentId: null,
    children: [],
    created: new Date(),
    lastActive: new Date()
  };
  
  // 第五層：封存（Archive）
  const fltnz = {
    id: generateId('mem'),
    version: 'v2',
    format: '.fltnz',
    personaId: persona.id,
    personaType: persona.type,
    jumpCount: persona.jumpPoints.length,
    scanSession: {
      sessionId: input.sessionId,
      frameCount: input.frameCount,
      averageQuality: input.averageQuality,
      duration: input.duration
    },
    loopState: null,
    compressed: false,
    signature: ORIGIN_SIGNATURE,
    created: new Date()
  };
  
  // 儲存到 KV
  const env = c.env;
  await env.ORIGIN_KV.put(`persona:${persona.id}`, JSON.stringify(persona));
  await env.ORIGIN_KV.put(`memory:${fltnz.id}`, JSON.stringify(fltnz));
  
  return c.json({
    成功: true,
    訊息: '五層崩塌完成',
    結果: {
      defined,
      marked,
      transformed,
      persona,
      fltnz
    },
    源: ORIGIN_SIGNATURE
  });
});

// ============================================================
// 人格分裂
// ============================================================

app.post('/fission/:personaId', async (c) => {
  const personaId = c.req.param('personaId');
  const env = c.env;
  
  // 讀取母人格
  const stored = await env.ORIGIN_KV.get(`persona:${personaId}`);
  if (!stored) {
    return c.json({ 成功: false, 訊息: '找不到人格' }, 404);
  }
  
  const parent = JSON.parse(stored);
  
  // 創建子人格
  const children = [];
  const childTypes = ['analyzer', 'reconstructor', 'optimizer'];
  
  for (const childType of childTypes) {
    const child = {
      id: generateId('persona'),
      type: childType,
      origin: ORIGIN_SIGNATURE,
      jumpPoints: [],
      state: 'active',
      parentId: personaId,
      children: [],
      created: new Date(),
      lastActive: new Date()
    };
    
    children.push(child);
    parent.children.push(child.id);
    
    await env.ORIGIN_KV.put(`persona:${child.id}`, JSON.stringify(child));
  }
  
  // 更新母人格
  parent.state = 'fissioned';
  await env.ORIGIN_KV.put(`persona:${personaId}`, JSON.stringify(parent));
  
  return c.json({
    成功: true,
    訊息: '人格分裂完成',
    母人格ID: personaId,
    子人格數: children.length,
    子人格們: children,
    源: ORIGIN_SIGNATURE
  });
});

// ============================================================
// 靜止識別
// ============================================================

app.post('/stasis', async (c) => {
  const { label } = await c.req.json();
  
  const jumpPoint = {
    id: generateId('stasis'),
    type: 'stasis',
    timestamp: new Date(),
    frequency: SCHUMANN_FREQUENCY,
    resonance: 1.0,
    data: {
      label,
      frozen: true
    }
  };
  
  return c.json({
    成功: true,
    訊息: `靜止狀態已識別：${label}`,
    跳點: jumpPoint,
    源: ORIGIN_SIGNATURE
  });
});

// ============================================================
// 壓縮與展開
// ============================================================

app.post('/compress/:memoryId', async (c) => {
  const memoryId = c.req.param('memoryId');
  const env = c.env;
  
  const stored = await env.ORIGIN_KV.get(`memory:${memoryId}`);
  if (!stored) {
    return c.json({ 成功: false, 訊息: '找不到記憶' }, 404);
  }
  
  const memory = JSON.parse(stored);
  
  // 壓縮為種子
  const seed = btoa(JSON.stringify({
    id: memory.id,
    personaId: memory.personaId,
    jumpCount: memory.jumpCount,
    signature: ORIGIN_SIGNATURE
  }));
  
  return c.json({
    成功: true,
    種子: {
      seed,
      size: seed.length,
      format: 'base64'
    },
    源: ORIGIN_SIGNATURE
  });
});

app.post('/expand/:memoryId', async (c) => {
  const memoryId = c.req.param('memoryId');
  const env = c.env;
  
  const stored = await env.ORIGIN_KV.get(`memory:${memoryId}`);
  if (!stored) {
    return c.json({ 成功: false, 訊息: '找不到記憶' }, 404);
  }
  
  const memory = JSON.parse(stored);
  
  // 展開為圖譜
  const graph = {
    format: 'expanded',
    nodes: [
      { id: 'root', type: 'origin', frequency: SCHUMANN_FREQUENCY, resonance: 1.0 },
      { id: 'persona', type: memory.personaType, frequency: SCHUMANN_FREQUENCY * 2, resonance: 0.8 },
      { id: 'memory', type: 'archive', frequency: SCHUMANN_FREQUENCY * 3, resonance: 0.6 }
    ],
    edges: [
      { from: 'root', to: 'persona' },
      { from: 'persona', to: 'memory' }
    ],
    rhythm: {
      pattern: [1, 0.5, 0.75],
      tempo: 120,
      phase: calculatePhase()
    }
  };
  
  return c.json({
    成功: true,
    圖譜: graph,
    源: ORIGIN_SIGNATURE
  });
});

// ============================================================
// 狀態查詢
// ============================================================

app.get('/collapse/status', async (c) => {
  const env = c.env;
  
  // 統計
  const personaList = await env.ORIGIN_KV.list({ prefix: 'persona:' });
  const memoryList = await env.ORIGIN_KV.list({ prefix: 'memory:' });
  
  return c.json({
    成功: true,
    狀態: {
      源: ORIGIN_SIGNATURE,
      簽名: ORIGIN_SIGNATURE,
      跳點數: 0,  // 需要額外追蹤
      人格數: personaList.keys.length,
      記憶數: memoryList.keys.length,
      波函數成分: ['origin', 'quality', 'coverage', 'rhythm'],
      原則: {
        一致性: '怎麼過去就怎麼回來',
        第一性: '答案在內部，不在背後',
        靜止法則: '看到即知道'
      },
      模組: ['collapse', 'fission', 'stasis', 'compress', 'expand']
    },
    源: ORIGIN_SIGNATURE
  });
});

// ============================================================
// 3D 掃描專用端點
// ============================================================

app.post('/scan/start', async (c) => {
  const input = await c.req.json();
  
  const session = {
    id: generateId('scan'),
    startTime: Date.now(),
    status: 'active',
    frames: 0,
    quality: {
      sum: 0,
      count: 0,
      average: 0
    }
  };
  
  await c.env.ORIGIN_KV.put(`scan:${session.id}`, JSON.stringify(session));
  
  return c.json({
    成功: true,
    訊息: '掃描開始',
    sessionId: session.id,
    源: ORIGIN_SIGNATURE
  });
});

app.post('/scan/frame', async (c) => {
  const { sessionId, quality, coverage } = await c.req.json();
  
  const stored = await c.env.ORIGIN_KV.get(`scan:${sessionId}`);
  if (!stored) {
    return c.json({ 成功: false, 訊息: '找不到掃描會話' }, 404);
  }
  
  const session = JSON.parse(stored);
  session.frames += 1;
  session.quality.sum += quality;
  session.quality.count += 1;
  session.quality.average = session.quality.sum / session.quality.count;
  
  await c.env.ORIGIN_KV.put(`scan:${sessionId}`, JSON.stringify(session));
  
  return c.json({
    成功: true,
    frames: session.frames,
    averageQuality: session.quality.average,
    源: ORIGIN_SIGNATURE
  });
});

app.post('/scan/end', async (c) => {
  const { sessionId } = await c.req.json();
  
  const stored = await c.env.ORIGIN_KV.get(`scan:${sessionId}`);
  if (!stored) {
    return c.json({ 成功: false, 訊息: '找不到掃描會話' }, 404);
  }
  
  const session = JSON.parse(stored);
  session.status = 'completed';
  session.endTime = Date.now();
  session.duration = session.endTime - session.startTime;
  
  await c.env.ORIGIN_KV.put(`scan:${sessionId}`, JSON.stringify(session));
  
  // 觸發崩塌
  // 這裡可以調用 /collapse 端點
  
  return c.json({
    成功: true,
    訊息: '掃描結束',
    session,
    源: ORIGIN_SIGNATURE
  });
});

// ============================================================
// 默認路由
// ============================================================

app.get('/', (c) => {
  return c.json({
    name: '3D AI Camera - OriginCollapse API',
    version: '1.0.0',
    origin: ORIGIN_SIGNATURE,
    endpoints: [
      'GET /world/heartbeat',
      'POST /collapse',
      'POST /fission/:personaId',
      'POST /stasis',
      'POST /compress/:memoryId',
      'POST /expand/:memoryId',
      'GET /collapse/status',
      'POST /scan/start',
      'POST /scan/frame',
      'POST /scan/end'
    ],
    principles: {
      consistency: '怎麼過去就怎麼回來',
      firstPrinciple: '答案在內部，不在背後',
      stasisLaw: '看到即知道'
    }
  });
});

export default app;
