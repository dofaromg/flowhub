# -*- coding: utf-8 -*-
"""
3D AI Camera - Python Pipeline

雙線閉環重建系統

Author: MR.liou
Origin Signature: MrLiouWord
"""

from .quality import score, laplacian_variance, entropy, exposure_range
from .attention import AttentionBackend, attention_select, simple_attention_map
from .sfm import SfMBackend, Camera, Image
from .error_map import ErrorMapper
from .reverse import ReverseProjector
from .consistency import delta_star, is_converged, LoopController
from .elevate import select_elevation_targets, ElevationManager
from .context_graph import ContextGraph
from .gap_fill import GapFiller
from .export import Exporter
from .main import Pipeline

__version__ = '1.0.0'
__author__ = 'MR.liou'
__origin__ = 'MrLiouWord'

__all__ = [
    # 品質
    'score',
    'laplacian_variance',
    'entropy',
    'exposure_range',
    
    # 注意力
    'AttentionBackend',
    'attention_select',
    'simple_attention_map',
    
    # SfM
    'SfMBackend',
    'Camera',
    'Image',
    
    # 誤差
    'ErrorMapper',
    
    # 反算
    'ReverseProjector',
    
    # 一致性
    'delta_star',
    'is_converged',
    'LoopController',
    
    # 升格
    'select_elevation_targets',
    'ElevationManager',
    
    # 上下文
    'ContextGraph',
    'GapFiller',
    
    # 輸出
    'Exporter',
    
    # 主程式
    'Pipeline',
]
