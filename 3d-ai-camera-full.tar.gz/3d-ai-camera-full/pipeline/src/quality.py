# -*- coding: utf-8 -*-
"""
品質評分模組

公式：
- 銳度：Laplacian variance
- 曝光：histogram analysis (q5, q95)
- 熵：Shannon entropy

總分 = 0.5 * 銳度 + 0.3 * 曝光 + 0.2 * 熵
"""

import cv2
import numpy as np
from typing import Tuple, Dict


def laplacian_variance(gray: np.ndarray) -> float:
    """
    計算銳度（Laplacian variance）
    
    公式：variance(Laplacian(image))
    
    Args:
        gray: 灰度圖（HxW）
    
    Returns:
        銳度值（越高越清晰）
    """
    laplacian = cv2.Laplacian(gray, cv2.CV_64F)
    return float(laplacian.var())


def exposure_range(gray: np.ndarray) -> Tuple[float, float]:
    """
    計算曝光範圍
    
    分析直方圖的 5% 和 95% 分位點
    
    Args:
        gray: 灰度圖（HxW）
    
    Returns:
        (q5, q95) 正規化到 [0, 1]
    """
    hist = cv2.calcHist([gray], [0], None, [256], [0, 256]).ravel()
    cdf = np.cumsum(hist) / hist.sum()
    
    q5 = float((cdf > 0.05).argmax()) / 255.0
    q95 = float((cdf > 0.95).argmax()) / 255.0
    
    return q5, q95


def entropy(gray: np.ndarray) -> float:
    """
    計算 Shannon 熵
    
    公式：H = -Σ p(x) * log2(p(x))
    
    Args:
        gray: 灰度圖（HxW）
    
    Returns:
        熵值（理論最大 8 for 8-bit）
    """
    hist = cv2.calcHist([gray], [0], None, [256], [0, 256]).ravel()
    p = hist / (hist.sum() + 1e-9)
    p = p[p > 0]  # 移除零機率
    
    return float(-(p * np.log2(p)).sum())


def score(img_bgr: np.ndarray) -> Tuple[float, Dict[str, float]]:
    """
    計算總體品質評分
    
    Args:
        img_bgr: BGR 彩色圖
    
    Returns:
        (total_score, metrics_dict)
        total_score: [0, 1] 越高越好
        metrics_dict: 各項指標詳情
    """
    gray = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2GRAY)
    
    # 各項指標
    sharp = laplacian_variance(gray)
    q5, q95 = exposure_range(gray)
    ent = entropy(gray)
    
    # 正規化
    s = np.tanh(sharp / 200.0)  # 銳度：200 為參考值
    e = np.tanh(ent / 6.0)      # 熵：6 為參考值
    
    # 曝光品質：理想 q5 ≈ 0.15, q95 ≈ 0.95
    exp_error = abs(q5 - 0.15) + abs(q95 - 0.95)
    exp_ok = max(0, 1 - exp_error / 2)
    
    # 加權總分
    total = 0.5 * s + 0.3 * exp_ok + 0.2 * e
    total = float(np.clip(total, 0, 1))
    
    metrics = {
        'sharpness': float(sharp),
        'sharpness_normalized': float(s),
        'q5': float(q5),
        'q95': float(q95),
        'exposure_quality': float(exp_ok),
        'entropy': float(ent),
        'entropy_normalized': float(e),
        'total': total
    }
    
    return total, metrics


def batch_score(images: list) -> Tuple[list, list]:
    """
    批次評分
    
    Args:
        images: BGR 圖像列表
    
    Returns:
        (scores, metrics_list)
    """
    scores = []
    metrics_list = []
    
    for img in images:
        s, m = score(img)
        scores.append(s)
        metrics_list.append(m)
    
    return scores, metrics_list


def filter_by_quality(images: list, threshold: float = 0.35) -> Tuple[list, list]:
    """
    依品質過濾圖像
    
    Args:
        images: BGR 圖像列表
        threshold: 最低品質閾值
    
    Returns:
        (filtered_images, filtered_indices)
    """
    scores, _ = batch_score(images)
    
    filtered_images = []
    filtered_indices = []
    
    for i, (img, s) in enumerate(zip(images, scores)):
        if s >= threshold:
            filtered_images.append(img)
            filtered_indices.append(i)
    
    return filtered_images, filtered_indices


# 別名（相容性）
def quality_score(img_bgr):
    """score() 的別名"""
    return score(img_bgr)
