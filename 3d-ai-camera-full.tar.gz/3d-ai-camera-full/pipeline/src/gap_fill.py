# -*- coding: utf-8 -*-
"""
缺口填補模組（獨立）

提供更細緻的缺口分析與補拍建議
"""

from typing import Dict, List
import numpy as np


class GapFiller:
    """缺口填補器"""
    
    def __init__(self, cfg: Dict):
        self.cfg = cfg
        self.tile_rows = cfg.get('gap', {}).get('tile_rows', 4)
        self.tile_cols = cfg.get('gap', {}).get('tile_cols', 4)
        self.top_k = cfg.get('gap', {}).get('top_k', 3)
        self.objective = cfg.get('suggestion', {}).get('objective', 'error')
    
    def propose(self, 
                heatmaps: Dict[int, np.ndarray], 
                links: List[Dict]) -> List[Dict]:
        """生成補拍建議"""
        from .context_graph import GapFiller as ContextGapFiller
        
        # 使用 context_graph 中的實現
        filler = ContextGapFiller(self.cfg)
        return filler.propose(heatmaps, links)
