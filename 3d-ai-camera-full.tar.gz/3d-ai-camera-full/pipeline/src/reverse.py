# -*- coding: utf-8 -*-
"""
反算模組（Reverse Projection）

將影像域熱圖反算為 3D 點的異常分數

公式：
a_j = Σ(w_ij · H_i(⌊x_ij⌋)) / Σw_ij

其中：
- a_j: 3D 點 j 的異常分數
- w_ij: 注意力權重
- H_i: 影像 i 的熱圖
- x_ij: 點 j 在影像 i 上的投影座標
"""

import numpy as np
from typing import Dict, Tuple, Set


class ReverseProjector:
    """
    反算投影器
    
    將影像域熱圖反算為 3D 點的異常分數，
    或在 Mesh/Coverage 路徑下聚合每點的覆蓋率。
    """
    
    def __init__(self, cfg: Dict):
        self.cfg = cfg
    
    def image_to_points_error(self, 
                              tracks: Dict[int, list],
                              heatmaps: Dict[int, np.ndarray],
                              attn_maps: Dict[int, np.ndarray]) -> Dict[int, float]:
        """
        誤差路徑：將影像域熱圖反算為 3D 點異常分數
        
        公式：a_j = Σ(w_ij · H_i(x_ij)) / Σw_ij
        
        Args:
            tracks: {cam_id: [(u, v, pid, error), ...]} 觀測資料
            heatmaps: {cam_id: H_i} 熱圖
            attn_maps: {cam_id: A_i} 注意力圖
        
        Returns:
            point_scores: {pid: a_j} 點異常分數
        """
        num = {}  # pid → 加權計數
        acc = {}  # pid → 加權累積
        
        for cam_id, obs_list in tracks.items():
            H = heatmaps.get(cam_id)
            A = attn_maps.get(cam_id)
            
            if H is None or A is None:
                continue
            
            Hh, Hw = H.shape
            
            for obs in obs_list:
                u, v, pid, _e = obs[:4]
                ui, vi = int(round(u)), int(round(v))
                
                if 0 <= ui < Hw and 0 <= vi < Hh:
                    w = float(A[vi, ui])
                    val = float(H[vi, ui])
                    
                    acc[pid] = acc.get(pid, 0.0) + w * val
                    num[pid] = num.get(pid, 0.0) + max(w, 1e-6)
        
        # 計算平均
        point_scores = {
            int(pid): acc[pid] / num[pid]
            for pid in acc.keys()
        }
        
        return point_scores
    
    def image_to_points_coverage(self,
                                  tracks: Dict[int, list],
                                  H_shape_by_cam: Dict[int, Tuple[int, int]]) -> Dict[int, float]:
        """
        覆蓋路徑：計算每 3D 點的覆蓋率
        
        公式：c_j = (可見視角數) / (總視角數)
        
        Args:
            tracks: {cam_id: [(u, v, pid, val), ...]} 觀測資料
            H_shape_by_cam: {cam_id: (H, W)} 圖像尺寸
        
        Returns:
            coverage: {pid: c_j} 覆蓋率 [0, 1]
        """
        vis_cnt = {}   # pid → 可見次數
        cam_seen = {}  # pid → 可見的相機集合
        
        for cam_id, obs_list in tracks.items():
            shape = H_shape_by_cam.get(cam_id)
            if shape is None:
                continue
            
            Hh, Hw = shape
            
            for obs in obs_list:
                u, v, pid = obs[:3]
                ui, vi = int(round(u)), int(round(v))
                
                # 檢查是否在畫幅內
                if 0 <= ui < Hw and 0 <= vi < Hh:
                    vis_cnt[pid] = vis_cnt.get(pid, 0) + 1
                    
                    if pid not in cam_seen:
                        cam_seen[pid] = set()
                    cam_seen[pid].add(cam_id)
        
        # 計算覆蓋率
        # 保守估計：用看到該點的相機數作為分母
        coverage = {}
        for pid, cnt in vis_cnt.items():
            denom = max(len(cam_seen.get(pid, set())), 1)
            coverage[int(pid)] = float(cnt) / float(denom)
        
        return coverage
    
    def aggregate_3d(self,
                     point_scores: Dict[int, float],
                     points_3d: Dict[int, np.ndarray],
                     grid_size: float = 0.1) -> Dict[Tuple[int, int, int], float]:
        """
        將 3D 點聚合到體素網格
        
        Args:
            point_scores: {pid: score}
            points_3d: {pid: [x, y, z]}
            grid_size: 體素邊長
        
        Returns:
            voxel_scores: {(ix, iy, iz): mean_score}
        """
        voxel_acc = {}
        voxel_cnt = {}
        
        for pid, score in point_scores.items():
            if pid not in points_3d:
                continue
            
            xyz = points_3d[pid]
            ix = int(np.floor(xyz[0] / grid_size))
            iy = int(np.floor(xyz[1] / grid_size))
            iz = int(np.floor(xyz[2] / grid_size))
            
            key = (ix, iy, iz)
            voxel_acc[key] = voxel_acc.get(key, 0.0) + score
            voxel_cnt[key] = voxel_cnt.get(key, 0) + 1
        
        voxel_scores = {
            k: voxel_acc[k] / voxel_cnt[k]
            for k in voxel_acc.keys()
        }
        
        return voxel_scores
    
    def find_problem_regions(self,
                              voxel_scores: Dict[Tuple[int, int, int], float],
                              threshold: float = 0.7) -> list:
        """
        找出問題區域（高異常或低覆蓋）
        
        Args:
            voxel_scores: 體素分數
            threshold: 閾值（誤差時為上界，覆蓋時為下界）
        
        Returns:
            problem_voxels: [(ix, iy, iz, score), ...]
        """
        problems = []
        
        for key, score in voxel_scores.items():
            if score > threshold:  # 高異常
                problems.append((*key, score))
        
        # 按分數排序（最嚴重的在前）
        problems.sort(key=lambda x: -x[3])
        
        return problems
