# -*- coding: utf-8 -*-
"""
SfM 後端模組

支援：
- COLMAP 資料載入
- 模擬資料生成（測試用）
- 相機投影計算

公式：
- 座標轉換：X_c = R·X_w + t
- 針孔投影：[u,v] = K · [x_c/z_c, y_c/z_c, 1]
- 四元數→旋轉矩陣（COLMAP 約定）
"""

import os
import numpy as np
from typing import Dict, List, Tuple, Optional


class Camera:
    """相機模型"""
    
    def __init__(self, cam_id: int, model: str, width: int, height: int, params: List[float]):
        self.id = cam_id
        self.model = model
        self.width = width
        self.height = height
        self.params = params
        
        # 解析參數
        if model == 'SIMPLE_PINHOLE':
            self.fx = self.fy = params[0]
            self.cx, self.cy = params[1], params[2]
            self.k1 = 0
        elif model == 'SIMPLE_RADIAL':
            self.fx = self.fy = params[0]
            self.cx, self.cy = params[1], params[2]
            self.k1 = params[3]
        elif model == 'OPENCV':
            self.fx, self.fy = params[0], params[1]
            self.cx, self.cy = params[2], params[3]
            self.k1, self.k2, self.p1, self.p2, self.k3 = params[4:9] if len(params) >= 9 else (0, 0, 0, 0, 0)
        else:
            # 預設
            self.fx = self.fy = params[0] if params else 1000
            self.cx = width / 2
            self.cy = height / 2
            self.k1 = 0
    
    def project(self, X_c: np.ndarray) -> Tuple[float, float]:
        """
        投影相機座標到像素座標
        
        Args:
            X_c: 相機座標 [x, y, z]
        
        Returns:
            (u, v) 像素座標
        """
        x = X_c[0] / X_c[2]
        y = X_c[1] / X_c[2]
        
        # 畸變校正
        if hasattr(self, 'k1') and self.k1 != 0:
            r2 = x*x + y*y
            radial = 1 + self.k1 * r2
            x = x * radial
            y = y * radial
        
        # 針孔投影
        u = self.fx * x + self.cx
        v = self.fy * y + self.cy
        
        return u, v


class Image:
    """圖像/視角模型"""
    
    def __init__(self, img_id: int, qvec: np.ndarray, tvec: np.ndarray, 
                 cam_id: int, name: str):
        self.id = img_id
        self.qvec = qvec  # [qw, qx, qy, qz]
        self.tvec = tvec  # [tx, ty, tz]
        self.cam_id = cam_id
        self.name = name
        
        # 計算旋轉矩陣
        self.R = self.qvec_to_rotmat(qvec)
    
    @staticmethod
    def qvec_to_rotmat(qvec: np.ndarray) -> np.ndarray:
        """
        四元數轉旋轉矩陣（COLMAP 約定）
        
        q = [qw, qx, qy, qz]
        """
        qw, qx, qy, qz = qvec
        
        # 正規化
        n = np.sqrt(qw*qw + qx*qx + qy*qy + qz*qz)
        qw, qx, qy, qz = qw/n, qx/n, qy/n, qz/n
        
        R = np.array([
            [1 - 2*(qy*qy + qz*qz), 2*(qx*qy - qz*qw), 2*(qx*qz + qy*qw)],
            [2*(qx*qy + qz*qw), 1 - 2*(qx*qx + qz*qz), 2*(qy*qz - qx*qw)],
            [2*(qx*qz - qy*qw), 2*(qy*qz + qx*qw), 1 - 2*(qx*qx + qy*qy)]
        ])
        
        return R
    
    def world_to_camera(self, X_w: np.ndarray) -> np.ndarray:
        """
        世界座標轉相機座標
        
        X_c = R · X_w + t
        """
        return self.R @ X_w + self.tvec
    
    @property
    def camera_center(self) -> np.ndarray:
        """相機中心位置（世界座標）"""
        return -self.R.T @ self.tvec


class SfMBackend:
    """SfM 後端"""
    
    def __init__(self, cfg: Dict):
        self.cfg = cfg
        self.input_dir = cfg.get('input_dir', 'data/input')
        self.colmap_dir = os.path.join(self.input_dir, 'colmap')
    
    def load_or_simulate(self) -> Tuple[Dict, Dict, Dict, Dict]:
        """
        載入或模擬 SfM 資料
        
        Returns:
            (cameras, points, tracks, images)
        """
        # 嘗試載入 COLMAP
        if os.path.exists(self.colmap_dir):
            return self.load_colmap()
        
        # 模擬資料
        return self.simulate()
    
    def load_colmap(self) -> Tuple[Dict, Dict, Dict, Dict]:
        """載入 COLMAP 輸出"""
        cameras = self.read_cameras_txt()
        images = self.read_images_txt()
        points = self.read_points3d_txt()
        
        # 構建 tracks
        tracks = self.build_tracks(images, points, cameras)
        
        # 載入圖像
        imgs = self.load_images(images)
        
        return cameras, points, tracks, imgs
    
    def simulate(self, n_cams: int = 10, n_points: int = 1000) -> Tuple[Dict, Dict, Dict, Dict]:
        """
        模擬 SfM 資料（用於測試）
        """
        # 模擬相機
        cameras = {}
        for i in range(n_cams):
            angle = 2 * np.pi * i / n_cams
            
            # 環繞配置
            R = np.eye(3)  # 簡化
            t = np.array([np.cos(angle) * 2, 0, np.sin(angle) * 2])
            
            qvec = np.array([1, 0, 0, 0])  # 單位四元數
            
            cam = Camera(i, 'SIMPLE_PINHOLE', 640, 480, [500, 320, 240])
            img = Image(i, qvec, t, i, f'image_{i:04d}.jpg')
            
            cameras[i] = {
                'camera': cam,
                'image': img
            }
        
        # 模擬 3D 點
        points = {}
        for j in range(n_points):
            points[j] = np.random.randn(3) * 0.5  # 中心附近
        
        # 構建 tracks
        tracks = {}
        for i in range(n_cams):
            cam_data = cameras[i]
            cam = cam_data['camera']
            img = cam_data['image']
            
            obs = []
            for j, X_w in points.items():
                X_c = img.world_to_camera(X_w)
                
                if X_c[2] > 0.1:  # 在相機前方
                    u, v = cam.project(X_c)
                    
                    if 0 <= u < cam.width and 0 <= v < cam.height:
                        error = np.random.rand() * 2  # 模擬誤差
                        obs.append((u, v, j, error))
            
            tracks[i] = obs
        
        # 模擬圖像
        imgs = {}
        for i in range(n_cams):
            imgs[i] = np.random.randint(0, 256, (480, 640, 3), dtype=np.uint8)
        
        return cameras, points, tracks, imgs
    
    def read_cameras_txt(self) -> Dict:
        """讀取 cameras.txt"""
        cameras = {}
        path = os.path.join(self.colmap_dir, 'cameras.txt')
        
        if not os.path.exists(path):
            return cameras
        
        with open(path, 'r') as f:
            for line in f:
                if line.startswith('#') or not line.strip():
                    continue
                
                parts = line.strip().split()
                cam_id = int(parts[0])
                model = parts[1]
                width = int(parts[2])
                height = int(parts[3])
                params = [float(p) for p in parts[4:]]
                
                cameras[cam_id] = Camera(cam_id, model, width, height, params)
        
        return cameras
    
    def read_images_txt(self) -> Dict:
        """讀取 images.txt"""
        images = {}
        path = os.path.join(self.colmap_dir, 'images.txt')
        
        if not os.path.exists(path):
            return images
        
        with open(path, 'r') as f:
            lines = [l.strip() for l in f if not l.startswith('#') and l.strip()]
        
        for i in range(0, len(lines), 2):
            parts = lines[i].split()
            img_id = int(parts[0])
            qvec = np.array([float(parts[j]) for j in range(1, 5)])
            tvec = np.array([float(parts[j]) for j in range(5, 8)])
            cam_id = int(parts[8])
            name = parts[9]
            
            images[img_id] = Image(img_id, qvec, tvec, cam_id, name)
        
        return images
    
    def read_points3d_txt(self) -> Dict:
        """讀取 points3D.txt"""
        points = {}
        path = os.path.join(self.colmap_dir, 'points3D.txt')
        
        if not os.path.exists(path):
            return points
        
        with open(path, 'r') as f:
            for line in f:
                if line.startswith('#') or not line.strip():
                    continue
                
                parts = line.strip().split()
                pid = int(parts[0])
                xyz = np.array([float(parts[j]) for j in range(1, 4)])
                
                points[pid] = xyz
        
        return points
    
    def build_tracks(self, images: Dict, points: Dict, cameras: Dict) -> Dict:
        """構建 tracks"""
        # 簡化實現：使用模擬
        return {}
    
    def load_images(self, images_meta: Dict) -> Dict:
        """載入實際圖像"""
        import cv2
        
        imgs = {}
        img_dir = os.path.join(self.input_dir, 'images')
        
        for img_id, img_meta in images_meta.items():
            path = os.path.join(img_dir, img_meta.name)
            if os.path.exists(path):
                imgs[img_id] = cv2.imread(path)
        
        return imgs
