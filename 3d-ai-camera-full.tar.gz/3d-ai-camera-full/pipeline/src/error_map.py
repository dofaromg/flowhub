# -*- coding: utf-8 -*-
"""
誤差熱圖模組

公式：
- 重投影誤差：e_ij = ||x_ij - x̂_ij||₂
- 注意力加權：ē_ij = A_i(u,v) · ρ_δ(e_ij)
- 熱圖聚合：H_i(u,v) = Agg{j: x_ij ≈ (u,v)}(ē_ij)
"""

import numpy as np
from typing import Dict, Tuple, List
import cv2


class ErrorMapper:
    """誤差熱圖生成器"""
    
    def __init__(self, cfg: Dict):
        self.cfg = cfg
        self.agg_method = cfg.get('error_map', {}).get('aggregation', 'max')
        self.huber_delta = cfg.get('error_map', {}).get('huber_delta', 1.0)
    
    def make(self, 
             cams: Dict, 
             points: Dict, 
             tracks: Dict, 
             attn_maps: Dict) -> Tuple[Dict[int, np.ndarray], Dict]:
        """
        生成所有相機的誤差熱圖
        
        Args:
            cams: 相機資料
            points: 3D 點
            tracks: {cam_id: [(u, v, pid, error), ...]}
            attn_maps: {cam_id: attention_map}
        
        Returns:
            (heatmaps, metrics)
        """
        heatmaps = {}
        metrics = {
            'p90_by_cam': {},
            'max_by_cam': {},
            'coverage_by_cam': {}
        }
        
        for cam_id, obs_list in tracks.items():
            cam_data = cams.get(cam_id, {})
            
            # 獲取圖像尺寸
            if 'camera' in cam_data:
                width = cam_data['camera'].width
                height = cam_data['camera'].height
            else:
                width, height = 640, 480  # 預設
            
            attn = attn_maps.get(cam_id)
            if attn is None:
                attn = np.ones((height, width))
            
            # 生成熱圖
            heatmap = self.make_single(obs_list, attn, width, height)
            heatmaps[cam_id] = heatmap
            
            # 計算指標
            flat = heatmap[heatmap > 0]
            if len(flat) > 0:
                metrics['p90_by_cam'][cam_id] = float(np.percentile(flat, 90))
                metrics['max_by_cam'][cam_id] = float(flat.max())
                metrics['coverage_by_cam'][cam_id] = float(len(flat)) / (width * height)
            else:
                metrics['p90_by_cam'][cam_id] = 0.0
                metrics['max_by_cam'][cam_id] = 0.0
                metrics['coverage_by_cam'][cam_id] = 0.0
        
        return heatmaps, metrics
    
    def make_single(self, 
                    obs_list: List[Tuple], 
                    attn: np.ndarray,
                    width: int, 
                    height: int) -> np.ndarray:
        """
        生成單張熱圖
        
        Args:
            obs_list: [(u, v, pid, error), ...]
            attn: 注意力圖
            width, height: 圖像尺寸
        
        Returns:
            熱圖 (HxW)
        """
        if self.agg_method == 'max':
            heatmap = np.zeros((height, width), dtype=np.float32)
        else:
            heatmap = np.zeros((height, width), dtype=np.float32)
            count = np.zeros((height, width), dtype=np.float32)
        
        for obs in obs_list:
            u, v = obs[0], obs[1]
            error = obs[3] if len(obs) > 3 else 1.0
            
            ui, vi = int(round(u)), int(round(v))
            
            if 0 <= ui < width and 0 <= vi < height:
                # 注意力加權
                a = attn[vi, ui] if attn.shape == (height, width) else 1.0
                
                # Huber 損失
                weighted_error = a * self.huber_loss(error)
                
                if self.agg_method == 'max':
                    heatmap[vi, ui] = max(heatmap[vi, ui], weighted_error)
                else:
                    heatmap[vi, ui] += weighted_error
                    count[vi, ui] += 1
        
        if self.agg_method != 'max':
            mask = count > 0
            heatmap[mask] /= count[mask]
        
        return heatmap
    
    def huber_loss(self, e: float) -> float:
        """Huber 損失"""
        delta = self.huber_delta
        abs_e = abs(e)
        
        if abs_e <= delta:
            return 0.5 * e * e
        else:
            return delta * (abs_e - 0.5 * delta)
    
    def tile_analysis(self, 
                      heatmap: np.ndarray, 
                      rows: int = 4, 
                      cols: int = 4) -> np.ndarray:
        """
        切塊分析
        
        公式：S_ij = (1/|Ω_ij|) * Σ M(u,v)
        
        Args:
            heatmap: 熱圖
            rows, cols: 切塊數
        
        Returns:
            tile_scores (rows x cols)
        """
        h, w = heatmap.shape
        tile_h = h // rows
        tile_w = w // cols
        
        scores = np.zeros((rows, cols))
        
        for i in range(rows):
            for j in range(cols):
                y0, y1 = i * tile_h, (i + 1) * tile_h
                x0, x1 = j * tile_w, (j + 1) * tile_w
                
                tile = heatmap[y0:y1, x0:x1]
                scores[i, j] = tile.mean()
        
        return scores
    
    def find_hotspots(self, 
                      tile_scores: np.ndarray, 
                      top_k: int = 3) -> List[Tuple[int, int, float]]:
        """
        找出熱點區塊
        
        Args:
            tile_scores: 切塊分數
            top_k: 取前幾個
        
        Returns:
            [(row, col, score), ...]
        """
        flat_idx = np.argsort(tile_scores.ravel())[::-1][:top_k]
        
        hotspots = []
        for idx in flat_idx:
            row = idx // tile_scores.shape[1]
            col = idx % tile_scores.shape[1]
            score = tile_scores[row, col]
            hotspots.append((row, col, float(score)))
        
        return hotspots
    
    def visualize(self, 
                  heatmap: np.ndarray, 
                  output_path: str = None) -> np.ndarray:
        """
        視覺化熱圖
        
        Args:
            heatmap: 熱圖
            output_path: 輸出路徑（可選）
        
        Returns:
            彩色熱圖 (HxWx3)
        """
        # 正規化
        normalized = heatmap.copy()
        if normalized.max() > 0:
            normalized = normalized / normalized.max()
        
        # 轉換為 8-bit
        normalized = (normalized * 255).astype(np.uint8)
        
        # 應用 colormap
        colored = cv2.applyColorMap(normalized, cv2.COLORMAP_JET)
        
        if output_path:
            cv2.imwrite(output_path, colored)
        
        return colored
