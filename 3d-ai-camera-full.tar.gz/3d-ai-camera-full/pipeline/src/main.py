# -*- coding: utf-8 -*-
"""
3D AI Camera - Python Pipeline
主程式：雙線閉環調度

Author: MR.liou
Origin Signature: MrLiouWord

流程：
1. 前向分析（Forward）：投影 → 誤差 → 熱圖
2. 反算（Reverse）：影像域 → 3D 域異常分數
3. 一致性判定：Δ* 收斂檢測
4. 升格決策：連續高異常 → 獨立任務粒子
"""

import os
import json
import yaml
import logging
from datetime import datetime
from typing import Dict, Any, Tuple, List, Optional

from .sfm import SfMBackend
from .attention import AttentionBackend
from .error_map import ErrorMapper
from .reverse import ReverseProjector
from .consistency import delta_star, is_converged
from .elevate import select_elevation_targets
from .context_graph import ContextGraph
from .gap_fill import GapFiller
from .export import Exporter

logging.basicConfig(
    level=logging.INFO,
    format="[%(levelname)s] %(asctime)s - %(message)s",
    datefmt="%H:%M:%S"
)
logger = logging.getLogger(__name__)


class Pipeline:
    """3D AI Camera 重建管線"""
    
    def __init__(self, config_path: str = "config/config.yaml"):
        with open(config_path, 'r', encoding='utf-8') as f:
            self.cfg = yaml.safe_load(f)
        
        self.out_dir = self.cfg.get('out_dir', 'data/outputs')
        os.makedirs(self.out_dir, exist_ok=True)
        
        # 閉環參數
        self.max_rounds = self.cfg.get('loop', {}).get('max_rounds', 2)
        self.epsilon = self.cfg.get('loop', {}).get('eps', 1e-3)
        
        # 升格參數
        self.elevate_ratio = self.cfg.get('elevate', {}).get('top_ratio', 0.02)
        
        # 狀態
        self.carry = {
            'delta_hist': [],
            'elevated_pids': []
        }
    
    def run_forward(self, iteration: int) -> Tuple[Dict, Dict, Dict, Dict, Dict, Dict, Dict]:
        """
        前向分析
        回傳：(cams, heatmaps, metrics, attn_maps, points, tracks, imgs)
        """
        logger.info(f"=== Round {iteration} / Forward ===")
        
        # SfM 後端
        sfm = SfMBackend(self.cfg)
        cams, points, tracks, imgs = sfm.load_or_simulate()
        
        # 注意力計算
        attn = AttentionBackend(self.cfg)
        attn_maps = attn.compute(imgs)
        
        # 誤差熱圖
        mapper = ErrorMapper(self.cfg)
        heatmaps, metrics = mapper.make(cams, points, tracks, attn_maps)
        
        return cams, heatmaps, metrics, attn_maps, points, tracks, imgs
    
    def run_reverse(self, iteration: int, tracks: Dict, heatmaps: Dict, 
                    attn_maps: Dict, H_shapes: Dict) -> Dict[int, float]:
        """
        反算：影像域 → 3D 域
        回傳：point_scores (pid → a_j)
        """
        logger.info(f"=== Round {iteration} / Reverse ===")
        
        rev = ReverseProjector(self.cfg)
        mode = self.cfg.get('suggestion', {}).get('objective', 'error').lower()
        
        if mode == 'coverage':
            point_scores = rev.image_to_points_coverage(tracks, H_shapes)
        else:
            point_scores = rev.image_to_points_error(tracks, heatmaps, attn_maps)
        
        return point_scores
    
    def run_once(self, iteration: int) -> float:
        """
        執行一輪完整的前向+反算
        回傳：Δ* (一致性指標)
        """
        # 前向
        cams, heatmaps, metrics, attn_maps, points, tracks, imgs = self.run_forward(iteration)
        
        # 反算
        H_shapes = {k: v.shape for k, v in heatmaps.items()}
        point_scores = self.run_reverse(iteration, tracks, heatmaps, attn_maps, H_shapes)
        
        # 一致性量測
        p90_by_cam = metrics.get('p90_by_cam', {})
        dstar = delta_star(p90_by_cam)
        self.carry['delta_hist'].append(dstar)
        
        # 升格判定
        elevate_pids = select_elevation_targets(
            point_scores, 
            top_ratio=self.elevate_ratio
        )
        self.carry['elevated_pids'].extend(elevate_pids)
        
        # 上下文圖 & 缺口建議
        cg = ContextGraph(self.cfg)
        links = cg.build(cams, heatmaps)
        
        gf = GapFiller(self.cfg)
        suggestions = gf.propose(heatmaps, links)
        
        # 輸出
        exp = Exporter(self.cfg)
        exp.dump_all(cams, metrics, links, suggestions, heatmaps, imgs)
        
        # 反算結果
        reverse_path = os.path.join(self.out_dir, f'reverse_points_round{iteration}.json')
        with open(reverse_path, 'w', encoding='utf-8') as f:
            json.dump({
                'mode': self.cfg.get('suggestion', {}).get('objective', 'error'),
                'point_scores': point_scores,
                'count': len(point_scores)
            }, f, indent=2)
        
        # 升格候選
        elevate_path = os.path.join(self.out_dir, f'elevate_round{iteration}.json')
        with open(elevate_path, 'w', encoding='utf-8') as f:
            json.dump({
                'pids': elevate_pids,
                'count': len(elevate_pids)
            }, f, indent=2)
        
        logger.info(f"[Round {iteration}] Δ* = {dstar:.4f}, Elevated = {len(elevate_pids)}")
        
        return dstar
    
    def run(self) -> Dict[str, Any]:
        """
        執行完整的閉環流程
        """
        logger.info("=" * 60)
        logger.info("3D AI Camera Pipeline - Starting")
        logger.info(f"Max rounds: {self.max_rounds}, Epsilon: {self.epsilon}")
        logger.info("=" * 60)
        
        for it in range(1, self.max_rounds + 1):
            dstar = self.run_once(it)
            
            if is_converged(self.carry['delta_hist'], eps=self.epsilon, min_rounds=2):
                logger.info(f"Converged at round {it}. Stopping.")
                break
        
        # 最終報告
        result = {
            'rounds': len(self.carry['delta_hist']),
            'delta_history': self.carry['delta_hist'],
            'final_delta': self.carry['delta_hist'][-1] if self.carry['delta_hist'] else 0,
            'converged': is_converged(self.carry['delta_hist'], eps=self.epsilon),
            'elevated_points': len(set(self.carry['elevated_pids'])),
            'timestamp': datetime.now().isoformat()
        }
        
        # 保存報告
        report_path = os.path.join(self.out_dir, 'pipeline_report.json')
        with open(report_path, 'w', encoding='utf-8') as f:
            json.dump(result, f, indent=2, ensure_ascii=False)
        
        logger.info("=" * 60)
        logger.info("Pipeline Complete")
        logger.info(f"Final Δ* = {result['final_delta']:.4f}")
        logger.info(f"Converged: {result['converged']}")
        logger.info("=" * 60)
        
        return result


def main():
    """入口點"""
    import argparse
    
    parser = argparse.ArgumentParser(description='3D AI Camera Pipeline')
    parser.add_argument('--config', '-c', default='config/config.yaml',
                        help='Config file path')
    args = parser.parse_args()
    
    pipeline = Pipeline(args.config)
    result = pipeline.run()
    
    return result


if __name__ == "__main__":
    main()
