# -*- coding: utf-8 -*-
"""
注意力選圖模組

公式：
- Simple 注意力：A_i(u,v) = 1 - sqrt((u-cx)^2/(W/2)^2 + (v-cy)^2/(H/2)^2)
- 全域嵌入：histogram + resize histogram
- 注意力加權：ē_ij = A_i(u,v) · ρ_δ(e_ij)
"""

import cv2
import numpy as np
from typing import List, Tuple, Dict, Any
from .quality import score as quality_score


def global_embed(img: np.ndarray) -> np.ndarray:
    """
    建立全域圖像嵌入
    
    使用雙尺度直方圖作為特徵向量
    
    Args:
        img: BGR 圖像
    
    Returns:
        正規化特徵向量
    """
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    
    # 原尺度直方圖
    h1 = cv2.calcHist([gray], [0], None, [64], [0, 256]).ravel()
    
    # 縮小尺度直方圖
    gray_small = cv2.resize(gray, (128, 128))
    h2 = cv2.calcHist([gray_small], [0], None, [64], [0, 256]).ravel()
    
    # 合併並正規化
    v = np.concatenate([h1, h2])
    v = v / (np.linalg.norm(v) + 1e-8)
    
    return v


def simple_attention_map(height: int, width: int) -> np.ndarray:
    """
    建立簡單注意力圖（基於中心距離）
    
    公式：A_i(u,v) = 1 - sqrt((u-cx)^2/(W/2)^2 + (v-cy)^2/(H/2)^2)
    
    Args:
        height: 圖像高度
        width: 圖像寬度
    
    Returns:
        注意力圖 (HxW)，值在 [0, 1]
    """
    cx, cy = width / 2, height / 2
    half_w, half_h = width / 2, height / 2
    
    # 建立座標網格
    y, x = np.mgrid[0:height, 0:width].astype(np.float32)
    
    # 計算到中心的正規化距離
    dx = (x - cx) / half_w
    dy = (y - cy) / half_h
    dist = np.sqrt(dx**2 + dy**2)
    
    # 轉換為注意力（中心高，邊緣低）
    attn = 1.0 - dist
    attn = np.clip(attn, 0, 1)
    
    # 正規化到 [0, 1]
    attn = (attn - attn.min()) / (attn.max() - attn.min() + 1e-8)
    
    return attn


def attention_select(images_bgr: List[np.ndarray], 
                     max_images: int = 120,
                     neighbors: int = 8,
                     blur_thresh: float = 0.35) -> Tuple[List[int], List[Tuple], List[Dict]]:
    """
    注意力加權選圖
    
    流程：
    1. 品質評分，過濾低於閾值的圖像
    2. 建立嵌入，計算相似度矩陣
    3. 選取最佳圖像並找出鄰居關係
    
    Args:
        images_bgr: BGR 圖像列表
        max_images: 最大選取數量
        neighbors: 每張圖的鄰居數
        blur_thresh: 品質過濾閾值
    
    Returns:
        keep_idx: 保留的圖像索引
        neigh_pairs: (from_idx, to_idx, weight) 鄰居對
        metas: 各圖像的元數據
    """
    # 品質評分
    metas = []
    for idx, img in enumerate(images_bgr):
        s, aux = quality_score(img)
        metas.append({
            'idx': idx,
            'score': s,
            'aux': aux
        })
    
    # 過濾低品質
    keep = [m for m in metas if m['score'] >= blur_thresh]
    
    # 按分數排序，取前 max_images
    keep = sorted(keep, key=lambda x: -x['score'])[:max_images]
    keep_idx = [m['idx'] for m in keep]
    
    if len(keep_idx) == 0:
        return [], [], metas
    
    # 選取的圖像
    sel = [images_bgr[i] for i in keep_idx]
    
    # 建立嵌入
    embeds = np.stack([global_embed(im) for im in sel], axis=0)
    
    # 計算相似度矩陣
    sim = embeds @ embeds.T
    np.fill_diagonal(sim, -1)  # 排除自身
    
    # Softmax 注意力
    A = np.exp(sim) / np.exp(sim).sum(axis=1, keepdims=True)
    
    # 找鄰居
    neigh_pairs = []
    for i in range(A.shape[0]):
        js = np.argsort(-A[i])[:neighbors]
        for j in js:
            w = float(A[i, j])
            neigh_pairs.append((keep_idx[i], keep_idx[int(j)], w))
    
    return keep_idx, neigh_pairs, metas


class AttentionBackend:
    """注意力計算後端"""
    
    def __init__(self, cfg: Dict):
        self.cfg = cfg
        self.mode = cfg.get('attention', {}).get('mode', 'simple')
    
    def compute(self, imgs: Dict[int, np.ndarray]) -> Dict[int, np.ndarray]:
        """
        計算所有圖像的注意力圖
        
        Args:
            imgs: {cam_id: image} 字典
        
        Returns:
            {cam_id: attention_map} 字典
        """
        attn_maps = {}
        
        for cam_id, img in imgs.items():
            h, w = img.shape[:2]
            attn_maps[cam_id] = simple_attention_map(h, w)
        
        return attn_maps
    
    def weighted_error(self, error: float, attention: float, 
                       huber_delta: float = 1.0) -> float:
        """
        計算注意力加權誤差
        
        公式：ē = A(u,v) · ρ_δ(e)
        """
        robust_error = self.huber_loss(error, huber_delta)
        return attention * robust_error
    
    @staticmethod
    def huber_loss(e: float, delta: float) -> float:
        """
        Huber 損失函數
        
        ρ_δ(e) = 0.5 * e² (if |e| ≤ δ) else δ * (|e| - 0.5δ)
        """
        abs_e = abs(e)
        if abs_e <= delta:
            return 0.5 * e * e
        else:
            return delta * (abs_e - 0.5 * delta)
