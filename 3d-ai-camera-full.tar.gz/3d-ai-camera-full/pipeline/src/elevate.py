# -*- coding: utf-8 -*-
"""
升格決策模組（Elevation）

當 3D 點持續高異常且無改善時，升格為獨立任務粒子

六律對應：
- 母體結構 1+1=2：升格不合併，成為獨立任務
- 錯位判定：連續高異常 → 升格
"""

from typing import Dict, List, Set, Tuple
import numpy as np


def select_elevation_targets(point_scores: Dict[int, float],
                              top_ratio: float = 0.02,
                              min_k: int = 10) -> List[int]:
    """
    選取升格目標
    
    取分數最高的前 top_ratio 的 3D 點作為升格對象
    
    對於誤差路徑：point_scores = a_j（高 = 壞）
    對於覆蓋路徑：可先轉為 (1 - c_j) 再選（高 = 壞）
    
    Args:
        point_scores: {pid: score}
        top_ratio: 取前多少比例
        min_k: 最少選取數量
    
    Returns:
        升格候選的 pid 列表
    """
    if not point_scores:
        return []
    
    items = sorted(point_scores.items(), key=lambda kv: kv[1], reverse=True)
    k = max(int(len(items) * top_ratio), min_k)
    
    return [pid for pid, _ in items[:k]]


def detect_persistent_anomalies(history: List[Dict[int, float]],
                                  threshold: float = 0.7,
                                  min_occurrences: int = 2) -> Set[int]:
    """
    檢測持續異常的點
    
    如果一個點在多輪中持續高異常，則標記為需要升格
    
    Args:
        history: 各輪的 point_scores 列表
        threshold: 異常閾值
        min_occurrences: 最少出現次數
    
    Returns:
        持續異常的 pid 集合
    """
    occurrence_count = {}
    
    for round_scores in history:
        for pid, score in round_scores.items():
            if score > threshold:
                occurrence_count[pid] = occurrence_count.get(pid, 0) + 1
    
    persistent = {
        pid for pid, count in occurrence_count.items()
        if count >= min_occurrences
    }
    
    return persistent


def create_elevation_tasks(pids: List[int],
                            points_3d: Dict[int, np.ndarray] = None,
                            task_type: str = 'local_reconstruction') -> List[Dict]:
    """
    為升格點創建任務粒子
    
    母體結構 1+1=2：每個任務是獨立的粒子
    
    Args:
        pids: 需要升格的點 ID
        points_3d: 3D 點座標
        task_type: 任務類型
    
    Returns:
        任務粒子列表
    """
    tasks = []
    
    for pid in pids:
        task = {
            'id': f'elevation_task_{pid}',
            'type': task_type,
            'target_pid': pid,
            'status': 'pending',
            'priority': 1
        }
        
        if points_3d and pid in points_3d:
            task['position'] = points_3d[pid].tolist()
        
        tasks.append(task)
    
    return tasks


def cluster_elevation_points(pids: List[int],
                              points_3d: Dict[int, np.ndarray],
                              cluster_radius: float = 0.5) -> List[List[int]]:
    """
    將升格點聚類
    
    相近的點可以合併為同一個任務，減少處理開銷
    
    Args:
        pids: 點 ID 列表
        points_3d: 3D 點座標
        cluster_radius: 聚類半徑
    
    Returns:
        聚類結果 [[pid, pid, ...], ...]
    """
    if not pids or not points_3d:
        return [[pid] for pid in pids]
    
    # 收集有座標的點
    valid_pids = [pid for pid in pids if pid in points_3d]
    if not valid_pids:
        return [[pid] for pid in pids]
    
    coords = np.array([points_3d[pid] for pid in valid_pids])
    
    # 簡單聚類：貪婪合併
    clusters = []
    assigned = set()
    
    for i, pid in enumerate(valid_pids):
        if pid in assigned:
            continue
        
        cluster = [pid]
        assigned.add(pid)
        
        for j, other_pid in enumerate(valid_pids):
            if other_pid in assigned:
                continue
            
            dist = np.linalg.norm(coords[i] - coords[j])
            if dist < cluster_radius:
                cluster.append(other_pid)
                assigned.add(other_pid)
        
        clusters.append(cluster)
    
    # 處理沒有座標的點
    for pid in pids:
        if pid not in assigned:
            clusters.append([pid])
    
    return clusters


class ElevationManager:
    """升格管理器"""
    
    def __init__(self, cfg: Dict = None):
        self.cfg = cfg or {}
        self.top_ratio = self.cfg.get('elevate', {}).get('top_ratio', 0.02)
        self.threshold = self.cfg.get('elevate', {}).get('threshold', 0.7)
        self.history = []
    
    def update(self, point_scores: Dict[int, float]):
        """記錄一輪的分數"""
        self.history.append(point_scores.copy())
    
    def select(self) -> List[int]:
        """選取需要升格的點"""
        if not self.history:
            return []
        
        latest = self.history[-1]
        
        # 單輪選取
        immediate = select_elevation_targets(latest, self.top_ratio)
        
        # 持續異常
        persistent = detect_persistent_anomalies(self.history, self.threshold)
        
        # 合併（去重）
        all_pids = list(set(immediate) | persistent)
        
        return all_pids
    
    def create_tasks(self, points_3d: Dict[int, np.ndarray] = None) -> List[Dict]:
        """創建升格任務"""
        pids = self.select()
        
        if not pids:
            return []
        
        # 聚類
        if points_3d:
            clusters = cluster_elevation_points(pids, points_3d)
        else:
            clusters = [[pid] for pid in pids]
        
        # 為每個聚類創建任務
        tasks = []
        for i, cluster in enumerate(clusters):
            task = {
                'id': f'elevation_cluster_{i}',
                'type': 'local_reconstruction',
                'pids': cluster,
                'count': len(cluster),
                'status': 'pending',
                'priority': len(cluster)  # 越多點優先級越高
            }
            
            if points_3d:
                # 計算聚類中心
                coords = [points_3d[pid] for pid in cluster if pid in points_3d]
                if coords:
                    center = np.mean(coords, axis=0)
                    task['center'] = center.tolist()
            
            tasks.append(task)
        
        return tasks
    
    def reset(self):
        """重置歷史"""
        self.history = []
