# -*- coding: utf-8 -*-
"""
輸出模組

支援：
- 熱圖可視化
- JSON 報告
- CSV 摘要
"""

import os
import json
import csv
import numpy as np
import cv2
from typing import Dict, List, Any
from datetime import datetime


class Exporter:
    """輸出管理器"""
    
    def __init__(self, cfg: Dict):
        self.cfg = cfg
        self.out_dir = cfg.get('out_dir', 'data/outputs')
        os.makedirs(self.out_dir, exist_ok=True)
    
    def dump_all(self, 
                 cams: Dict,
                 metrics: Dict,
                 links: List[Dict],
                 suggestions: List[Dict],
                 heatmaps: Dict[int, np.ndarray],
                 imgs: Dict[int, np.ndarray] = None):
        """輸出所有結果"""
        
        # 1. 熱圖
        self.dump_heatmaps(heatmaps)
        
        # 2. 指標
        self.dump_metrics(metrics)
        
        # 3. 關聯
        self.dump_links(links)
        
        # 4. 建議
        self.dump_suggestions(suggestions)
        
        # 5. 疊加圖（如果有原圖）
        if imgs:
            self.dump_overlays(imgs, heatmaps)
    
    def dump_heatmaps(self, heatmaps: Dict[int, np.ndarray]):
        """輸出熱圖"""
        heatmap_dir = os.path.join(self.out_dir, 'heatmaps')
        os.makedirs(heatmap_dir, exist_ok=True)
        
        for cam_id, heatmap in heatmaps.items():
            # NPY 格式
            npy_path = os.path.join(heatmap_dir, f'heatmap_{cam_id:04d}.npy')
            np.save(npy_path, heatmap)
            
            # PNG 可視化
            png_path = os.path.join(heatmap_dir, f'heatmap_{cam_id:04d}.png')
            self.visualize_heatmap(heatmap, png_path)
    
    def visualize_heatmap(self, heatmap: np.ndarray, output_path: str):
        """可視化熱圖"""
        # 正規化
        normalized = heatmap.copy()
        if normalized.max() > 0:
            normalized = normalized / normalized.max()
        
        # 轉換為 8-bit
        normalized = (normalized * 255).astype(np.uint8)
        
        # 應用 colormap
        colored = cv2.applyColorMap(normalized, cv2.COLORMAP_JET)
        
        cv2.imwrite(output_path, colored)
    
    def dump_metrics(self, metrics: Dict):
        """輸出指標"""
        # JSON
        json_path = os.path.join(self.out_dir, 'metrics.json')
        
        # 確保可序列化
        serializable = {}
        for key, value in metrics.items():
            if isinstance(value, dict):
                serializable[key] = {str(k): float(v) for k, v in value.items()}
            else:
                serializable[key] = value
        
        with open(json_path, 'w', encoding='utf-8') as f:
            json.dump(serializable, f, indent=2, ensure_ascii=False)
        
        # CSV 摘要
        csv_path = os.path.join(self.out_dir, 'metrics_summary.csv')
        self.metrics_to_csv(metrics, csv_path)
    
    def metrics_to_csv(self, metrics: Dict, output_path: str):
        """將指標轉換為 CSV"""
        rows = []
        
        p90 = metrics.get('p90_by_cam', {})
        max_err = metrics.get('max_by_cam', {})
        coverage = metrics.get('coverage_by_cam', {})
        
        for cam_id in p90.keys():
            rows.append({
                'cam_id': cam_id,
                'p90': p90.get(cam_id, 0),
                'max': max_err.get(cam_id, 0),
                'coverage': coverage.get(cam_id, 0)
            })
        
        if rows:
            with open(output_path, 'w', newline='', encoding='utf-8') as f:
                writer = csv.DictWriter(f, fieldnames=['cam_id', 'p90', 'max', 'coverage'])
                writer.writeheader()
                writer.writerows(rows)
    
    def dump_links(self, links: List[Dict]):
        """輸出視角關聯"""
        json_path = os.path.join(self.out_dir, 'links.json')
        
        with open(json_path, 'w', encoding='utf-8') as f:
            json.dump(links, f, indent=2, ensure_ascii=False)
    
    def dump_suggestions(self, suggestions: List[Dict]):
        """輸出建議"""
        json_path = os.path.join(self.out_dir, 'suggestions.json')
        
        with open(json_path, 'w', encoding='utf-8') as f:
            json.dump(suggestions, f, indent=2, ensure_ascii=False)
    
    def dump_overlays(self, 
                      imgs: Dict[int, np.ndarray], 
                      heatmaps: Dict[int, np.ndarray]):
        """輸出疊加圖"""
        overlay_dir = os.path.join(self.out_dir, 'overlays')
        os.makedirs(overlay_dir, exist_ok=True)
        
        for cam_id, img in imgs.items():
            if cam_id not in heatmaps:
                continue
            
            heatmap = heatmaps[cam_id]
            overlay = self.create_overlay(img, heatmap)
            
            output_path = os.path.join(overlay_dir, f'overlay_{cam_id:04d}.png')
            cv2.imwrite(output_path, overlay)
    
    def create_overlay(self, 
                       img: np.ndarray, 
                       heatmap: np.ndarray, 
                       alpha: float = 0.5) -> np.ndarray:
        """創建疊加圖"""
        # 確保尺寸匹配
        h, w = img.shape[:2]
        
        if heatmap.shape != (h, w):
            heatmap = cv2.resize(heatmap, (w, h))
        
        # 正規化熱圖
        normalized = heatmap.copy()
        if normalized.max() > 0:
            normalized = normalized / normalized.max()
        
        normalized = (normalized * 255).astype(np.uint8)
        
        # 應用 colormap
        colored = cv2.applyColorMap(normalized, cv2.COLORMAP_JET)
        
        # 混合
        overlay = cv2.addWeighted(img, 1 - alpha, colored, alpha, 0)
        
        return overlay
    
    def dump_report(self, result: Dict):
        """輸出最終報告"""
        report_path = os.path.join(self.out_dir, 'final_report.json')
        
        report = {
            'timestamp': datetime.now().isoformat(),
            'result': result,
            'config': self.cfg
        }
        
        with open(report_path, 'w', encoding='utf-8') as f:
            json.dump(report, f, indent=2, ensure_ascii=False)
