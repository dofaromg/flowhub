# -*- coding: utf-8 -*-
"""
一致性與停機準則模組

公式：
- Δ* = median_i(p90_i)
- 收斂條件：|Δ*_{k+1} - Δ*_k| < ε

六律對應：
- 一致性律：Replay 閉環驗證
- 折疊律：-1+1=0 每輪中性重置
"""

import numpy as np
from typing import Dict, List


def delta_star(p90_by_cam: Dict[int, float]) -> float:
    """
    計算 Δ* 一致性指標
    
    公式：Δ* = median_i(p90_i)
    
    Args:
        p90_by_cam: {cam_id: p90_value}
    
    Returns:
        Δ* 值
    """
    arr = np.array([v for v in p90_by_cam.values()], dtype=np.float32)
    
    if arr.size == 0:
        return 0.0
    
    return float(np.median(arr))


def is_converged(history: List[float], 
                 eps: float = 1e-3,
                 min_rounds: int = 2) -> bool:
    """
    檢查是否收斂
    
    公式：|Δ*_{k+1} - Δ*_k| < ε
    
    Args:
        history: Δ* 歷史記錄
        eps: 收斂閾值
        min_rounds: 最小輪次要求
    
    Returns:
        是否收斂
    """
    if len(history) < max(min_rounds, 2):
        return False
    
    return abs(history[-1] - history[-2]) < eps


def compute_improvement(history: List[float]) -> float:
    """
    計算改善率
    
    Args:
        history: Δ* 歷史記錄
    
    Returns:
        改善率（正值表示改善）
    """
    if len(history) < 2:
        return 0.0
    
    # 降低 Δ* 表示改善
    return history[-2] - history[-1]


def should_continue(history: List[float],
                    max_rounds: int,
                    eps: float = 1e-3,
                    min_improvement: float = 1e-4) -> bool:
    """
    判斷是否應該繼續迭代
    
    考量因素：
    1. 未達最大輪次
    2. 未收斂
    3. 仍有改善空間
    
    Args:
        history: Δ* 歷史記錄
        max_rounds: 最大輪次
        eps: 收斂閾值
        min_improvement: 最小改善閾值
    
    Returns:
        是否繼續
    """
    current_round = len(history)
    
    # 達到最大輪次
    if current_round >= max_rounds:
        return False
    
    # 已收斂
    if is_converged(history, eps):
        return False
    
    # 無改善（可能陷入局部最優）
    if len(history) >= 3:
        recent_improvement = compute_improvement(history)
        if abs(recent_improvement) < min_improvement:
            return False
    
    return True


class LoopController:
    """閉環控制器"""
    
    def __init__(self, 
                 max_rounds: int = 2,
                 eps: float = 1e-3,
                 min_improvement: float = 1e-4):
        self.max_rounds = max_rounds
        self.eps = eps
        self.min_improvement = min_improvement
        
        self.history = []
        self.round = 0
    
    def reset(self):
        """
        重置狀態（折疊律：-1+1=0）
        """
        self.history = []
        self.round = 0
    
    def update(self, delta: float) -> bool:
        """
        更新狀態並返回是否繼續
        
        Args:
            delta: 當前 Δ* 值
        
        Returns:
            是否繼續迭代
        """
        self.history.append(delta)
        self.round += 1
        
        return should_continue(
            self.history,
            self.max_rounds,
            self.eps,
            self.min_improvement
        )
    
    @property
    def converged(self) -> bool:
        """是否已收斂"""
        return is_converged(self.history, self.eps)
    
    @property
    def current_delta(self) -> float:
        """當前 Δ*"""
        return self.history[-1] if self.history else 0.0
    
    @property
    def improvement(self) -> float:
        """總改善量"""
        if len(self.history) < 2:
            return 0.0
        return self.history[0] - self.history[-1]
    
    def summary(self) -> Dict:
        """生成摘要"""
        return {
            'rounds': self.round,
            'history': self.history,
            'final_delta': self.current_delta,
            'converged': self.converged,
            'total_improvement': self.improvement
        }
