# -*- coding: utf-8 -*-
"""
上下文圖模組

公式（負相關尋找互補視角）：
corr(a,b) = (h_a - h̄_a)ᵀ(h_b - h̄_b) / (||h_a - h̄_a|| · ||h_b - h̄_b||)

若 corr(a,b) < τ（τ < 0），視為「互補」並建立連結
"""

import numpy as np
from typing import Dict, List, Tuple


class ContextGraph:
    """視角上下文圖"""
    
    def __init__(self, cfg: Dict):
        self.cfg = cfg
        self.tau = cfg.get('context', {}).get('correlation_threshold', -0.2)
    
    def build(self, 
              cams: Dict, 
              heatmaps: Dict[int, np.ndarray]) -> List[Dict]:
        """
        建立視角關聯圖
        
        Args:
            cams: 相機資料
            heatmaps: {cam_id: heatmap}
        
        Returns:
            links: [{'from': a, 'to': b, 'type': 'complementary', 'corr': value}, ...]
        """
        cam_ids = list(heatmaps.keys())
        n = len(cam_ids)
        
        if n < 2:
            return []
        
        # 攤平熱圖
        vectors = {}
        for cam_id, heatmap in heatmaps.items():
            vectors[cam_id] = heatmap.ravel()
        
        # 計算相關性並找出互補對
        links = []
        
        for i in range(n):
            for j in range(i + 1, n):
                a, b = cam_ids[i], cam_ids[j]
                
                corr = self.correlation(vectors[a], vectors[b])
                
                if corr < self.tau:
                    links.append({
                        'from': a,
                        'to': b,
                        'type': 'complementary',
                        'correlation': float(corr)
                    })
                elif corr > 0.8:
                    links.append({
                        'from': a,
                        'to': b,
                        'type': 'similar',
                        'correlation': float(corr)
                    })
        
        return links
    
    @staticmethod
    def correlation(h_a: np.ndarray, h_b: np.ndarray) -> float:
        """
        計算 Pearson 相關係數
        
        corr(a,b) = (h_a - h̄_a)ᵀ(h_b - h̄_b) / (||h_a - h̄_a|| · ||h_b - h̄_b||)
        """
        a_centered = h_a - h_a.mean()
        b_centered = h_b - h_b.mean()
        
        norm_a = np.linalg.norm(a_centered)
        norm_b = np.linalg.norm(b_centered)
        
        if norm_a < 1e-8 or norm_b < 1e-8:
            return 0.0
        
        return float(np.dot(a_centered, b_centered) / (norm_a * norm_b))
    
    def find_complementary_pairs(self, links: List[Dict]) -> List[Tuple[int, int]]:
        """找出所有互補視角對"""
        return [
            (link['from'], link['to'])
            for link in links
            if link['type'] == 'complementary'
        ]
    
    def find_best_complement(self, 
                              cam_id: int, 
                              links: List[Dict]) -> int:
        """為指定相機找出最佳互補視角"""
        candidates = [
            (link['to'] if link['from'] == cam_id else link['from'], link['correlation'])
            for link in links
            if link['type'] == 'complementary' and (link['from'] == cam_id or link['to'] == cam_id)
        ]
        
        if not candidates:
            return None
        
        # 取相關性最負的（最互補）
        best = min(candidates, key=lambda x: x[1])
        return best[0]


class GapFiller:
    """缺口填補建議生成器"""
    
    def __init__(self, cfg: Dict):
        self.cfg = cfg
        self.tile_rows = cfg.get('gap', {}).get('tile_rows', 4)
        self.tile_cols = cfg.get('gap', {}).get('tile_cols', 4)
        self.top_k = cfg.get('gap', {}).get('top_k', 3)
        self.objective = cfg.get('suggestion', {}).get('objective', 'error')
    
    def propose(self, 
                heatmaps: Dict[int, np.ndarray], 
                links: List[Dict]) -> List[Dict]:
        """
        生成補拍建議
        
        Args:
            heatmaps: {cam_id: heatmap}
            links: 視角關聯
        
        Returns:
            suggestions: [{'cam_id': ..., 'tile': ..., 'priority': ...}, ...]
        """
        suggestions = []
        
        for cam_id, heatmap in heatmaps.items():
            tile_scores = self.tile_analysis(heatmap)
            
            if self.objective == 'coverage':
                # 覆蓋目標：取最低分的（缺口）
                targets = self.find_gaps(tile_scores)
            else:
                # 誤差目標：取最高分的（熱點）
                targets = self.find_hotspots(tile_scores)
            
            for row, col, score in targets:
                suggestion = {
                    'cam_id': cam_id,
                    'tile_row': row,
                    'tile_col': col,
                    'score': score,
                    'priority': len(targets) - targets.index((row, col, score)),
                    'objective': self.objective
                }
                
                # 找互補視角
                complement = self.find_complement_for_tile(cam_id, row, col, links, heatmaps)
                if complement:
                    suggestion['complement_cam'] = complement
                
                suggestions.append(suggestion)
        
        # 按優先級排序
        suggestions.sort(key=lambda x: (-x['priority'], -x['score']))
        
        return suggestions
    
    def tile_analysis(self, heatmap: np.ndarray) -> np.ndarray:
        """切塊分析"""
        h, w = heatmap.shape
        tile_h = h // self.tile_rows
        tile_w = w // self.tile_cols
        
        scores = np.zeros((self.tile_rows, self.tile_cols))
        
        for i in range(self.tile_rows):
            for j in range(self.tile_cols):
                y0, y1 = i * tile_h, (i + 1) * tile_h
                x0, x1 = j * tile_w, (j + 1) * tile_w
                
                tile = heatmap[y0:y1, x0:x1]
                scores[i, j] = tile.mean()
        
        return scores
    
    def find_hotspots(self, tile_scores: np.ndarray) -> List[Tuple[int, int, float]]:
        """找熱點（誤差目標：高分 = 問題）"""
        flat_idx = np.argsort(tile_scores.ravel())[::-1][:self.top_k]
        
        result = []
        for idx in flat_idx:
            row = idx // tile_scores.shape[1]
            col = idx % tile_scores.shape[1]
            result.append((row, col, float(tile_scores[row, col])))
        
        return result
    
    def find_gaps(self, tile_scores: np.ndarray) -> List[Tuple[int, int, float]]:
        """找缺口（覆蓋目標：低分 = 問題）"""
        flat_idx = np.argsort(tile_scores.ravel())[:self.top_k]  # 升序
        
        result = []
        for idx in flat_idx:
            row = idx // tile_scores.shape[1]
            col = idx % tile_scores.shape[1]
            result.append((row, col, float(tile_scores[row, col])))
        
        return result
    
    def find_complement_for_tile(self, 
                                  cam_id: int, 
                                  row: int, 
                                  col: int,
                                  links: List[Dict],
                                  heatmaps: Dict[int, np.ndarray]) -> int:
        """為特定 tile 找互補視角"""
        # 找所有互補相機
        complements = [
            link['to'] if link['from'] == cam_id else link['from']
            for link in links
            if link['type'] == 'complementary' and (link['from'] == cam_id or link['to'] == cam_id)
        ]
        
        if not complements:
            return None
        
        # 找在對應 tile 分數最好的
        best = None
        best_score = float('inf') if self.objective == 'coverage' else float('-inf')
        
        for comp_id in complements:
            if comp_id not in heatmaps:
                continue
            
            tile_scores = self.tile_analysis(heatmaps[comp_id])
            score = tile_scores[row, col]
            
            if self.objective == 'coverage':
                if score < best_score:
                    best_score = score
                    best = comp_id
            else:
                if score > best_score:
                    best_score = score
                    best = comp_id
        
        return best
