// Views/HeatmapView.swift
// 熱圖視覺化

import SwiftUI

struct HeatmapView: View {
    let data: [[Double]]
    var colorScheme: HeatmapColorScheme = .standard
    
    var body: some View {
        GeometryReader { geometry in
            Canvas { context, size in
                guard !data.isEmpty, !data[0].isEmpty else { return }
                
                let rows = data.count
                let cols = data[0].count
                let cellWidth = size.width / CGFloat(cols)
                let cellHeight = size.height / CGFloat(rows)
                
                for (rowIndex, row) in data.enumerated() {
                    for (colIndex, value) in row.enumerated() {
                        let rect = CGRect(
                            x: CGFloat(colIndex) * cellWidth,
                            y: CGFloat(rowIndex) * cellHeight,
                            width: cellWidth,
                            height: cellHeight
                        )
                        
                        let color = colorScheme.color(for: value)
                        context.fill(Path(rect), with: .color(color))
                    }
                }
            }
        }
    }
}

// MARK: - 色彩方案

enum HeatmapColorScheme {
    case standard      // 藍→紅
    case coverage      // 綠→紅（覆蓋率）
    case error         // 白→紅（誤差）
    case custom(low: Color, high: Color)
    
    func color(for value: Double) -> Color {
        let clampedValue = max(0, min(1, value))
        
        switch self {
        case .standard:
            // 藍 → 青 → 綠 → 黃 → 紅
            return interpolateJet(clampedValue)
        case .coverage:
            // 綠（高覆蓋）→ 黃 → 紅（低覆蓋）
            return interpolate(
                from: .green,
                to: .red,
                value: 1 - clampedValue  // 反轉：高覆蓋應該是好的
            )
        case .error:
            // 白（低誤差）→ 紅（高誤差）
            return interpolate(from: .white, to: .red, value: clampedValue)
        case .custom(let low, let high):
            return interpolate(from: low, to: high, value: clampedValue)
        }
    }
    
    private func interpolate(from: Color, to: Color, value: Double) -> Color {
        // 簡化版線性插值
        let fromComponents = UIColor(from).cgColor.components ?? [0, 0, 0, 1]
        let toComponents = UIColor(to).cgColor.components ?? [1, 0, 0, 1]
        
        let r = fromComponents[0] + (toComponents[0] - fromComponents[0]) * value
        let g = fromComponents[1] + (toComponents[1] - fromComponents[1]) * value
        let b = fromComponents[2] + (toComponents[2] - fromComponents[2]) * value
        
        return Color(red: r, green: g, blue: b)
    }
    
    private func interpolateJet(_ value: Double) -> Color {
        // Jet colormap 近似
        let r: Double
        let g: Double
        let b: Double
        
        if value < 0.25 {
            r = 0
            g = 4 * value
            b = 1
        } else if value < 0.5 {
            r = 0
            g = 1
            b = 1 - 4 * (value - 0.25)
        } else if value < 0.75 {
            r = 4 * (value - 0.5)
            g = 1
            b = 0
        } else {
            r = 1
            g = 1 - 4 * (value - 0.75)
            b = 0
        }
        
        return Color(red: r, green: g, blue: b)
    }
}

// MARK: - 互動式熱圖

struct InteractiveHeatmapView: View {
    let data: [[Double]]
    let gaps: [GapRegion]
    @State private var selectedTile: (row: Int, col: Int)?
    var onTileSelected: ((Int, Int) -> Void)?
    
    var body: some View {
        GeometryReader { geometry in
            ZStack {
                // 基礎熱圖
                HeatmapView(data: data, colorScheme: .coverage)
                
                // 缺口標記
                ForEach(gaps) { gap in
                    if gap.isGap {
                        gapOverlay(gap: gap, size: geometry.size)
                    }
                }
                
                // 網格線
                GridOverlay(rows: data.count, cols: data.first?.count ?? 0)
                
                // 選中狀態
                if let selected = selectedTile {
                    selectedOverlay(row: selected.row, col: selected.col, size: geometry.size)
                }
            }
            .gesture(
                DragGesture(minimumDistance: 0)
                    .onEnded { value in
                        let row = Int(value.location.y / (geometry.size.height / CGFloat(data.count)))
                        let col = Int(value.location.x / (geometry.size.width / CGFloat(data.first?.count ?? 1)))
                        
                        if row >= 0 && row < data.count && col >= 0 && col < (data.first?.count ?? 0) {
                            selectedTile = (row, col)
                            onTileSelected?(row, col)
                        }
                    }
            )
        }
    }
    
    private func gapOverlay(gap: GapRegion, size: CGSize) -> some View {
        let rows = data.count
        let cols = data.first?.count ?? 1
        let cellWidth = size.width / CGFloat(cols)
        let cellHeight = size.height / CGFloat(rows)
        
        return Rectangle()
            .stroke(severityColor(gap.severity), lineWidth: 3)
            .frame(width: cellWidth, height: cellHeight)
            .position(
                x: CGFloat(gap.tileCol) * cellWidth + cellWidth / 2,
                y: CGFloat(gap.tileRow) * cellHeight + cellHeight / 2
            )
    }
    
    private func selectedOverlay(row: Int, col: Int, size: CGSize) -> some View {
        let rows = data.count
        let cols = data.first?.count ?? 1
        let cellWidth = size.width / CGFloat(cols)
        let cellHeight = size.height / CGFloat(rows)
        
        return Rectangle()
            .stroke(Color.white, lineWidth: 2)
            .background(Color.white.opacity(0.2))
            .frame(width: cellWidth, height: cellHeight)
            .position(
                x: CGFloat(col) * cellWidth + cellWidth / 2,
                y: CGFloat(row) * cellHeight + cellHeight / 2
            )
    }
    
    private func severityColor(_ severity: GapSeverity) -> Color {
        switch severity {
        case .critical: return .red
        case .high: return .orange
        case .medium: return .yellow
        case .low: return .green
        }
    }
}

// MARK: - 網格覆蓋層

struct GridOverlay: View {
    let rows: Int
    let cols: Int
    
    var body: some View {
        GeometryReader { geometry in
            Path { path in
                let cellWidth = geometry.size.width / CGFloat(cols)
                let cellHeight = geometry.size.height / CGFloat(rows)
                
                // 垂直線
                for i in 1..<cols {
                    let x = CGFloat(i) * cellWidth
                    path.move(to: CGPoint(x: x, y: 0))
                    path.addLine(to: CGPoint(x: x, y: geometry.size.height))
                }
                
                // 水平線
                for i in 1..<rows {
                    let y = CGFloat(i) * cellHeight
                    path.move(to: CGPoint(x: 0, y: y))
                    path.addLine(to: CGPoint(x: geometry.size.width, y: y))
                }
            }
            .stroke(Color.white.opacity(0.3), lineWidth: 0.5)
        }
    }
}

// MARK: - 色標

struct ColorLegend: View {
    let scheme: HeatmapColorScheme
    let minLabel: String
    let maxLabel: String
    
    var body: some View {
        HStack(spacing: 8) {
            Text(minLabel)
                .font(.caption2)
            
            GeometryReader { geometry in
                LinearGradient(
                    colors: (0...10).map { scheme.color(for: Double($0) / 10.0) },
                    startPoint: .leading,
                    endPoint: .trailing
                )
            }
            .frame(height: 12)
            .cornerRadius(6)
            
            Text(maxLabel)
                .font(.caption2)
        }
    }
}

// MARK: - 預覽

#Preview {
    VStack {
        // 測試數據
        let testData: [[Double]] = [
            [0.9, 0.8, 0.7, 0.6],
            [0.8, 0.5, 0.3, 0.5],
            [0.6, 0.3, 0.1, 0.4],
            [0.7, 0.6, 0.5, 0.8]
        ]
        
        let testGaps = [
            GapRegion(id: UUID(), tileRow: 2, tileCol: 2, coverage: 0.1, anomalyScore: 0.9, centerPoint: nil)
        ]
        
        InteractiveHeatmapView(data: testData, gaps: testGaps)
            .frame(height: 200)
            .padding()
        
        ColorLegend(scheme: .coverage, minLabel: "低覆蓋", maxLabel: "高覆蓋")
            .padding()
    }
}
