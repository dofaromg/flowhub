// Views/ContentView.swift
// 主視圖

import SwiftUI

struct ContentView: View {
    @EnvironmentObject var store: ScanStore
    @State private var showLiDARScan = false
    @State private var showGapAnalysis = false
    @State private var selectedTab = 0
    
    var body: some View {
        TabView(selection: $selectedTab) {
            // 掃描列表
            NavigationView {
                ScansListView()
                    .navigationTitle("我的掃描")
                    .toolbar {
                        ToolbarItem(placement: .navigationBarTrailing) {
                            Button {
                                showLiDARScan = true
                            } label: {
                                Image(systemName: "camera.viewfinder")
                                    .font(.title2)
                            }
                        }
                    }
            }
            .tabItem {
                Image(systemName: "cube.box")
                Text("掃描")
            }
            .tag(0)
            
            // 分析
            NavigationView {
                AnalysisView()
                    .navigationTitle("品質分析")
            }
            .tabItem {
                Image(systemName: "waveform.path.ecg")
                Text("分析")
            }
            .tag(1)
            
            // 設定
            NavigationView {
                SettingsView()
                    .navigationTitle("設定")
            }
            .tabItem {
                Image(systemName: "gear")
                Text("設定")
            }
            .tag(2)
        }
        .sheet(isPresented: $showLiDARScan) {
            LiDARScanView()
        }
    }
}

// MARK: - 掃描列表

struct ScansListView: View {
    @EnvironmentObject var store: ScanStore
    
    var body: some View {
        List {
            if store.sessions.isEmpty {
                VStack(spacing: 20) {
                    Image(systemName: "cube.transparent")
                        .font(.system(size: 60))
                        .foregroundColor(.gray)
                    Text("尚無掃描")
                        .font(.headline)
                        .foregroundColor(.gray)
                    Text("點擊右上角開始您的第一次 3D 掃描")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
                .frame(maxWidth: .infinity)
                .padding(.vertical, 60)
            } else {
                ForEach(store.sessions) { session in
                    ScanSessionRow(session: session)
                }
                .onDelete(perform: deleteSession)
            }
        }
    }
    
    func deleteSession(at offsets: IndexSet) {
        store.sessions.remove(atOffsets: offsets)
    }
}

struct ScanSessionRow: View {
    let session: ScanSession
    
    var body: some View {
        HStack(spacing: 16) {
            // 縮圖
            ZStack {
                RoundedRectangle(cornerRadius: 12)
                    .fill(Color.blue.opacity(0.1))
                    .frame(width: 60, height: 60)
                Image(systemName: "cube.box.fill")
                    .font(.title)
                    .foregroundColor(.blue)
            }
            
            // 資訊
            VStack(alignment: .leading, spacing: 4) {
                Text(session.startTime, style: .date)
                    .font(.headline)
                
                HStack {
                    Label("\(session.frameCount) 幀", systemImage: "photo.stack")
                    Spacer()
                    QualityBadge(quality: session.averageQuality)
                }
                .font(.caption)
                .foregroundColor(.secondary)
            }
            
            Spacer()
            
            Image(systemName: "chevron.right")
                .foregroundColor(.secondary)
        }
        .padding(.vertical, 8)
    }
}

struct QualityBadge: View {
    let quality: Double
    
    var color: Color {
        if quality > 0.8 { return .green }
        if quality > 0.6 { return .yellow }
        return .red
    }
    
    var body: some View {
        HStack(spacing: 4) {
            Circle()
                .fill(color)
                .frame(width: 8, height: 8)
            Text("\(Int(quality * 100))%")
        }
    }
}

// MARK: - 分析視圖

struct AnalysisView: View {
    @EnvironmentObject var store: ScanStore
    
    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                // 品質總覽
                if let quality = store.quality {
                    QualityOverviewCard(metrics: quality)
                }
                
                // 熱圖
                if let heatmap = store.heatmap {
                    HeatmapCard(heatmap: heatmap)
                }
                
                // 缺口列表
                if !store.gaps.isEmpty {
                    GapsCard(gaps: store.gaps)
                }
                
                // 閉環狀態
                LoopStateCard(
                    round: store.currentRound,
                    deltaHistory: store.deltaHistory,
                    isConverged: store.isConverged
                )
                
                // 建議
                if !store.suggestions.isEmpty {
                    SuggestionsCard(suggestions: store.suggestions)
                }
            }
            .padding()
        }
    }
}

struct QualityOverviewCard: View {
    let metrics: QualityMetrics
    
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack {
                Text("品質評分")
                    .font(.headline)
                Spacer()
                Text(metrics.emoji)
                Text("\(Int(metrics.overall * 100))%")
                    .font(.title2)
                    .fontWeight(.bold)
            }
            
            VStack(spacing: 12) {
                MetricBar(label: "銳度", value: metrics.normalizedSharpness)
                MetricBar(label: "曝光", value: metrics.exposure)
                MetricBar(label: "熵", value: metrics.normalizedEntropy)
            }
        }
        .padding()
        .background(Color(.systemBackground))
        .cornerRadius(16)
        .shadow(radius: 2)
    }
}

struct MetricBar: View {
    let label: String
    let value: Double
    
    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            HStack {
                Text(label)
                    .font(.caption)
                Spacer()
                Text("\(Int(value * 100))%")
                    .font(.caption)
                    .fontWeight(.medium)
            }
            
            GeometryReader { geometry in
                ZStack(alignment: .leading) {
                    Rectangle()
                        .fill(Color.gray.opacity(0.2))
                        .frame(height: 8)
                        .cornerRadius(4)
                    
                    Rectangle()
                        .fill(barColor)
                        .frame(width: geometry.size.width * CGFloat(value), height: 8)
                        .cornerRadius(4)
                }
            }
            .frame(height: 8)
        }
    }
    
    var barColor: Color {
        if value > 0.8 { return .green }
        if value > 0.6 { return .yellow }
        return .red
    }
}

struct HeatmapCard: View {
    let heatmap: [[Double]]
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("覆蓋熱圖")
                .font(.headline)
            
            HeatmapView(data: heatmap)
                .frame(height: 200)
                .cornerRadius(12)
        }
        .padding()
        .background(Color(.systemBackground))
        .cornerRadius(16)
        .shadow(radius: 2)
    }
}

struct GapsCard: View {
    let gaps: [GapRegion]
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Text("缺口區域")
                    .font(.headline)
                Spacer()
                Text("\(gaps.filter { $0.isGap }.count) 處")
                    .foregroundColor(.red)
            }
            
            ForEach(gaps.filter { $0.isGap }.prefix(5)) { gap in
                HStack {
                    Circle()
                        .fill(severityColor(gap.severity))
                        .frame(width: 12, height: 12)
                    Text("區塊 (\(gap.tileRow), \(gap.tileCol))")
                    Spacer()
                    Text(gap.severity.rawValue)
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
            }
        }
        .padding()
        .background(Color(.systemBackground))
        .cornerRadius(16)
        .shadow(radius: 2)
    }
    
    func severityColor(_ severity: GapSeverity) -> Color {
        switch severity {
        case .critical: return .red
        case .high: return .orange
        case .medium: return .yellow
        case .low: return .green
        }
    }
}

struct LoopStateCard: View {
    let round: Int
    let deltaHistory: [Double]
    let isConverged: Bool
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Text("閉環狀態")
                    .font(.headline)
                Spacer()
                if isConverged {
                    Label("已收斂", systemImage: "checkmark.circle.fill")
                        .foregroundColor(.green)
                } else {
                    Label("進行中", systemImage: "arrow.triangle.2.circlepath")
                        .foregroundColor(.blue)
                }
            }
            
            HStack {
                VStack(alignment: .leading) {
                    Text("迭代輪次")
                        .font(.caption)
                        .foregroundColor(.secondary)
                    Text("\(round)")
                        .font(.title2)
                        .fontWeight(.bold)
                }
                
                Spacer()
                
                VStack(alignment: .trailing) {
                    Text("Δ*")
                        .font(.caption)
                        .foregroundColor(.secondary)
                    Text(deltaHistory.last.map { String(format: "%.4f", $0) } ?? "-")
                        .font(.title2)
                        .fontWeight(.bold)
                }
            }
        }
        .padding()
        .background(Color(.systemBackground))
        .cornerRadius(16)
        .shadow(radius: 2)
    }
}

struct SuggestionsCard: View {
    let suggestions: [RescanSuggestion]
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("補拍建議")
                .font(.headline)
            
            ForEach(suggestions.prefix(3)) { suggestion in
                HStack {
                    Image(systemName: "arrow.right.circle.fill")
                        .foregroundColor(.blue)
                    Text(suggestion.instruction)
                        .font(.subheadline)
                }
            }
        }
        .padding()
        .background(Color(.systemBackground))
        .cornerRadius(16)
        .shadow(radius: 2)
    }
}

// MARK: - 設定視圖

struct SettingsView: View {
    @AppStorage("cloudEndpoint") private var cloudEndpoint = "https://particle-auth-gateway.workers.dev"
    @AppStorage("maxRounds") private var maxRounds = 2
    @AppStorage("convergenceEpsilon") private var epsilon = 0.001
    
    var body: some View {
        Form {
            Section("雲端服務") {
                TextField("API 端點", text: $cloudEndpoint)
            }
            
            Section("閉環參數") {
                Stepper("最大迭代輪次: \(maxRounds)", value: $maxRounds, in: 1...10)
                
                HStack {
                    Text("收斂閾值 (ε)")
                    Spacer()
                    Text(String(format: "%.4f", epsilon))
                }
            }
            
            Section("關於") {
                HStack {
                    Text("版本")
                    Spacer()
                    Text("1.0.0")
                        .foregroundColor(.secondary)
                }
                HStack {
                    Text("Origin Signature")
                    Spacer()
                    Text("MrLiouWord")
                        .foregroundColor(.secondary)
                }
            }
        }
    }
}

#Preview {
    ContentView()
        .environmentObject(ScanStore())
        .environmentObject(OriginCollapseClient())
}
