// Views/LiDARScanView.swift
// LiDAR 掃描視圖

import SwiftUI
import ARKit
import RealityKit

struct LiDARScanView: View {
    @EnvironmentObject var store: ScanStore
    @EnvironmentObject var originCollapse: OriginCollapseClient
    @Environment(\.dismiss) var dismiss
    
    @StateObject private var scanController = LiDARScanController()
    @State private var showQualityDetail = false
    
    var body: some View {
        ZStack {
            // AR 視圖
            ARViewContainer(controller: scanController)
                .ignoresSafeArea()
            
            // 覆蓋 UI
            VStack {
                // 頂部工具列
                HStack {
                    Button {
                        dismiss()
                    } label: {
                        Image(systemName: "xmark.circle.fill")
                            .font(.title)
                            .foregroundColor(.white)
                    }
                    
                    Spacer()
                    
                    // 品質指示器
                    if let quality = scanController.currentQuality {
                        QualityIndicator(metrics: quality)
                            .onTapGesture {
                                showQualityDetail = true
                            }
                    }
                }
                .padding()
                
                Spacer()
                
                // 狀態資訊
                VStack(spacing: 8) {
                    if scanController.isScanning {
                        HStack {
                            Image(systemName: "record.circle")
                                .foregroundColor(.red)
                            Text("掃描中")
                            Text("·")
                            Text("\(scanController.frameCount) 幀")
                        }
                        .font(.caption)
                        .foregroundColor(.white)
                        .padding(.horizontal, 16)
                        .padding(.vertical, 8)
                        .background(.ultraThinMaterial)
                        .cornerRadius(20)
                        
                        // 閉環狀態
                        if scanController.currentRound > 0 {
                            HStack {
                                Text("輪次: \(scanController.currentRound)")
                                if let delta = scanController.latestDelta {
                                    Text("Δ*: \(String(format: "%.4f", delta))")
                                }
                            }
                            .font(.caption2)
                            .foregroundColor(.white.opacity(0.8))
                        }
                    }
                    
                    // 缺口提示
                    if !scanController.currentGaps.isEmpty {
                        GapAlertBanner(gapCount: scanController.currentGaps.count)
                    }
                }
                
                // 底部控制
                HStack(spacing: 40) {
                    // 切換模式
                    Button {
                        scanController.toggleMode()
                    } label: {
                        VStack {
                            Image(systemName: scanController.scanMode.icon)
                                .font(.title2)
                            Text(scanController.scanMode.rawValue)
                                .font(.caption2)
                        }
                        .foregroundColor(.white)
                    }
                    
                    // 掃描按鈕
                    Button {
                        if scanController.isScanning {
                            finishScan()
                        } else {
                            startScan()
                        }
                    } label: {
                        ZStack {
                            Circle()
                                .fill(Color.white)
                                .frame(width: 80, height: 80)
                            
                            Circle()
                                .stroke(Color.white, lineWidth: 4)
                                .frame(width: 90, height: 90)
                            
                            if scanController.isScanning {
                                RoundedRectangle(cornerRadius: 4)
                                    .fill(Color.red)
                                    .frame(width: 30, height: 30)
                            }
                        }
                    }
                    
                    // 查看分析
                    Button {
                        showQualityDetail = true
                    } label: {
                        VStack {
                            Image(systemName: "waveform.path.ecg")
                                .font(.title2)
                            Text("分析")
                                .font(.caption2)
                        }
                        .foregroundColor(.white)
                    }
                }
                .padding(.bottom, 40)
            }
        }
        .sheet(isPresented: $showQualityDetail) {
            QualityDetailSheet(controller: scanController)
        }
    }
    
    func startScan() {
        store.startNewSession()
        scanController.startScanning()
        
        // 創建觀察跳點
        Task {
            await originCollapse.createJumpPoint(
                type: .observe,
                data: ["action": "scan_start", "timestamp": Date().timeIntervalSince1970]
            )
        }
    }
    
    func finishScan() {
        scanController.stopScanning()
        store.endSession()
        
        // 執行崩塌
        Task {
            if let session = store.sessions.last {
                let result = await originCollapse.collapse(session)
                print("Collapse result: \(result?.persona.id ?? "nil")")
            }
        }
        
        dismiss()
    }
}

// MARK: - AR View Container

struct ARViewContainer: UIViewRepresentable {
    @ObservedObject var controller: LiDARScanController
    
    func makeUIView(context: Context) -> ARView {
        let arView = ARView(frame: .zero)
        controller.setupARView(arView)
        return arView
    }
    
    func updateUIView(_ uiView: ARView, context: Context) {}
}

// MARK: - LiDAR 掃描控制器

class LiDARScanController: NSObject, ObservableObject {
    @Published var isScanning = false
    @Published var frameCount = 0
    @Published var currentQuality: QualityMetrics?
    @Published var scanMode: ScanMode = .object
    @Published var currentGaps: [GapRegion] = []
    @Published var currentRound = 0
    @Published var latestDelta: Double?
    
    private var arView: ARView?
    private var session: ARSession?
    private let qualityChecker = QualityChecker()
    private let coverageAnalyzer = CoverageAnalyzer()
    
    enum ScanMode: String {
        case object = "物件"
        case space = "空間"
        case ai = "AI"
        
        var icon: String {
            switch self {
            case .object: return "cube"
            case .space: return "square.3.layers.3d"
            case .ai: return "brain"
            }
        }
    }
    
    func setupARView(_ arView: ARView) {
        self.arView = arView
        self.session = arView.session
        
        // 配置 ARSession
        let config = ARWorldTrackingConfiguration()
        config.sceneReconstruction = .meshWithClassification
        config.frameSemantics = [.sceneDepth, .smoothedSceneDepth]
        
        if ARWorldTrackingConfiguration.supportsSceneReconstruction(.meshWithClassification) {
            session?.run(config)
        }
        
        // 設置委託
        session?.delegate = self
    }
    
    func startScanning() {
        isScanning = true
        frameCount = 0
        currentRound = 0
        latestDelta = nil
    }
    
    func stopScanning() {
        isScanning = false
        
        // 執行最終分析
        runFinalAnalysis()
    }
    
    func toggleMode() {
        switch scanMode {
        case .object: scanMode = .space
        case .space: scanMode = .ai
        case .ai: scanMode = .object
        }
    }
    
    private func runFinalAnalysis() {
        // 計算覆蓋率
        // 檢測缺口
        // 生成建議
    }
}

// MARK: - ARSession Delegate

extension LiDARScanController: ARSessionDelegate {
    func session(_ session: ARSession, didUpdate frame: ARFrame) {
        guard isScanning else { return }
        
        frameCount += 1
        
        // 每 10 幀評估一次品質
        if frameCount % 10 == 0 {
            evaluateQuality(frame: frame)
        }
        
        // 每 30 幀更新覆蓋分析
        if frameCount % 30 == 0 {
            updateCoverageAnalysis(frame: frame)
        }
    }
    
    private func evaluateQuality(frame: ARFrame) {
        let pixelBuffer = frame.capturedImage
        let quality = qualityChecker.evaluate(pixelBuffer: pixelBuffer)
        
        DispatchQueue.main.async {
            self.currentQuality = quality
        }
    }
    
    private func updateCoverageAnalysis(frame: ARFrame) {
        // 更新覆蓋分析
        // 檢測新缺口
        // 更新閉環狀態
    }
}

// MARK: - 品質指示器

struct QualityIndicator: View {
    let metrics: QualityMetrics
    
    var body: some View {
        HStack(spacing: 8) {
            Text(metrics.emoji)
            Text("\(Int(metrics.overall * 100))%")
                .font(.headline)
                .fontWeight(.bold)
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 8)
        .background(.ultraThinMaterial)
        .cornerRadius(20)
    }
}

// MARK: - 缺口提示

struct GapAlertBanner: View {
    let gapCount: Int
    
    var body: some View {
        HStack {
            Image(systemName: "exclamationmark.triangle.fill")
                .foregroundColor(.yellow)
            Text("發現 \(gapCount) 處缺口")
            Image(systemName: "chevron.right")
        }
        .font(.caption)
        .foregroundColor(.white)
        .padding(.horizontal, 16)
        .padding(.vertical, 8)
        .background(Color.orange.opacity(0.8))
        .cornerRadius(20)
    }
}

// MARK: - 品質詳情

struct QualityDetailSheet: View {
    @ObservedObject var controller: LiDARScanController
    @Environment(\.dismiss) var dismiss
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 20) {
                    if let quality = controller.currentQuality {
                        QualityOverviewCard(metrics: quality)
                    }
                    
                    // 缺口列表
                    if !controller.currentGaps.isEmpty {
                        VStack(alignment: .leading, spacing: 12) {
                            Text("缺口區域")
                                .font(.headline)
                            
                            ForEach(controller.currentGaps) { gap in
                                GapRow(gap: gap)
                            }
                        }
                        .padding()
                        .background(Color(.systemBackground))
                        .cornerRadius(16)
                    }
                    
                    // 閉環狀態
                    LoopStateCard(
                        round: controller.currentRound,
                        deltaHistory: controller.latestDelta.map { [$0] } ?? [],
                        isConverged: false
                    )
                }
                .padding()
            }
            .navigationTitle("掃描分析")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("完成") {
                        dismiss()
                    }
                }
            }
        }
    }
}

struct GapRow: View {
    let gap: GapRegion
    
    var body: some View {
        HStack {
            Circle()
                .fill(severityColor)
                .frame(width: 12, height: 12)
            
            VStack(alignment: .leading) {
                Text("區塊 (\(gap.tileRow), \(gap.tileCol))")
                    .font(.subheadline)
                Text("覆蓋率: \(Int(gap.coverage * 100))%")
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
            
            Spacer()
            
            Text(gap.severity.rawValue)
                .font(.caption)
                .padding(.horizontal, 8)
                .padding(.vertical, 4)
                .background(severityColor.opacity(0.2))
                .cornerRadius(8)
        }
    }
    
    var severityColor: Color {
        switch gap.severity {
        case .critical: return .red
        case .high: return .orange
        case .medium: return .yellow
        case .low: return .green
        }
    }
}

#Preview {
    LiDARScanView()
        .environmentObject(ScanStore())
        .environmentObject(OriginCollapseClient())
}
