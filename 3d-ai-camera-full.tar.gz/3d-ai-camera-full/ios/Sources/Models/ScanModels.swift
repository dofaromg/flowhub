// Models/ScanSession.swift
// 掃描會話與相關資料模型

import Foundation
import simd

// MARK: - 掃描會話

struct ScanSession: Identifiable, Codable {
    let id: UUID
    let startTime: Date
    var endTime: Date?
    var frames: [ScanFrame]
    var jumpPoints: [JumpPoint]
    
    // 計算屬性
    var duration: TimeInterval {
        guard let end = endTime else { return Date().timeIntervalSince(startTime) }
        return end.timeIntervalSince(startTime)
    }
    
    var frameCount: Int { frames.count }
    
    var averageQuality: Double {
        guard !frames.isEmpty else { return 0 }
        return frames.map { $0.quality.overall }.reduce(0, +) / Double(frames.count)
    }
}

// MARK: - 掃描幀

struct ScanFrame: Identifiable, Codable {
    let id: UUID
    let timestamp: Date
    let quality: QualityMetrics
    let cameraTransform: CameraTransform
    let pointCount: Int
    var imageData: Data?
    
    init(timestamp: Date = Date(),
         quality: QualityMetrics,
         cameraTransform: CameraTransform,
         pointCount: Int) {
        self.id = UUID()
        self.timestamp = timestamp
        self.quality = quality
        self.cameraTransform = cameraTransform
        self.pointCount = pointCount
    }
}

// MARK: - 品質指標

struct QualityMetrics: Codable {
    let sharpness: Double      // 銳度 (Laplacian variance)
    let exposure: Double       // 曝光 (histogram analysis)
    let entropy: Double        // 熵 (Shannon entropy)
    let contrast: Double       // 對比度
    
    var overall: Double {
        // 加權組合：銳度 50% + 曝光 30% + 熵 20%
        return 0.5 * normalizedSharpness + 0.3 * exposure + 0.2 * normalizedEntropy
    }
    
    var normalizedSharpness: Double {
        min(1.0, sharpness / 200.0)
    }
    
    var normalizedEntropy: Double {
        min(1.0, entropy / 8.0)
    }
    
    var grade: QualityGrade {
        if overall > 0.8 { return .excellent }
        if overall > 0.6 { return .good }
        if overall > 0.4 { return .fair }
        return .poor
    }
    
    var emoji: String {
        switch grade {
        case .excellent: return "⭐️"
        case .good: return "✅"
        case .fair: return "⚠️"
        case .poor: return "❌"
        }
    }
}

enum QualityGrade: String, Codable {
    case excellent = "優秀"
    case good = "良好"
    case fair = "普通"
    case poor = "不佳"
}

// MARK: - 相機變換

struct CameraTransform: Codable {
    let rotation: [Double]     // 四元數 [qw, qx, qy, qz]
    let translation: [Double]  // 平移 [tx, ty, tz]
    
    // COLMAP 約定：四元數 → 旋轉矩陣
    var rotationMatrix: [[Double]] {
        let qw = rotation[0], qx = rotation[1], qy = rotation[2], qz = rotation[3]
        let s = 1.0 / (qw*qw + qx*qx + qy*qy + qz*qz)
        
        return [
            [1 - 2*s*(qy*qy + qz*qz), 2*s*(qx*qy - qz*qw), 2*s*(qx*qz + qy*qw)],
            [2*s*(qx*qy + qz*qw), 1 - 2*s*(qx*qx + qz*qz), 2*s*(qy*qz - qx*qw)],
            [2*s*(qx*qz - qy*qw), 2*s*(qy*qz + qx*qw), 1 - 2*s*(qx*qx + qy*qy)]
        ]
    }
}

// MARK: - 跳點（OriginCollapse）

struct JumpPoint: Identifiable, Codable {
    let id: String
    let type: JumpPointType
    let timestamp: Date
    let frequency: Double
    let resonance: Double
    let data: JumpPointData
    
    enum JumpPointType: String, Codable {
        case observe = "observe"
        case define = "define"
        case collapse = "collapse"
        case stasis = "stasis"
        case fission = "fission"
    }
    
    struct JumpPointData: Codable {
        let frameId: UUID?
        let quality: Double?
        let coverage: Double?
        let anomalyScore: Double?
    }
}

// MARK: - 缺口區域

struct GapRegion: Identifiable, Codable {
    let id: UUID
    let tileRow: Int
    let tileCol: Int
    let coverage: Double       // 0-1，低值表示缺口
    let anomalyScore: Double   // 異常分數
    let centerPoint: SIMD3<Float>?
    
    var isGap: Bool {
        coverage < 0.3 || anomalyScore > 0.7
    }
    
    var severity: GapSeverity {
        if coverage < 0.1 || anomalyScore > 0.9 { return .critical }
        if coverage < 0.2 || anomalyScore > 0.8 { return .high }
        if coverage < 0.3 || anomalyScore > 0.7 { return .medium }
        return .low
    }
}

enum GapSeverity: String, Codable {
    case critical = "嚴重"
    case high = "較高"
    case medium = "中等"
    case low = "輕微"
}

// MARK: - 補拍建議

struct RescanSuggestion: Identifiable, Codable {
    let id: UUID
    let targetRegion: GapRegion
    let suggestedPosition: SIMD3<Float>
    let suggestedDirection: SIMD3<Float>
    let priority: Int
    let reason: String
    
    var instruction: String {
        "向 \(directionText) 移動，對準標記區域補拍"
    }
    
    private var directionText: String {
        let x = suggestedDirection.x
        let z = suggestedDirection.z
        
        if abs(x) > abs(z) {
            return x > 0 ? "右" : "左"
        } else {
            return z > 0 ? "前" : "後"
        }
    }
}

// MARK: - 3D 點異常分數（反算結果）

struct PointAnomalyScore: Codable {
    let pointId: Int
    let score: Double          // a_j：高值表示異常
    let visibleCameras: [Int]  // 可見的相機 ID
    let needsElevation: Bool   // 是否需要升格
}

// MARK: - 閉環狀態

struct LoopState: Codable {
    var round: Int
    var deltaHistory: [Double]
    var isConverged: Bool
    var elevatedPoints: [Int]  // 升格的點 ID
    
    var deltaStar: Double {
        guard !deltaHistory.isEmpty else { return 0 }
        return deltaHistory.last!
    }
    
    mutating func update(delta: Double, epsilon: Double = 0.001) {
        deltaHistory.append(delta)
        round += 1
        
        if deltaHistory.count >= 2 {
            let diff = abs(deltaHistory.last! - deltaHistory[deltaHistory.count - 2])
            isConverged = diff < epsilon
        }
    }
}

// MARK: - Persona（OriginCollapse 人格）

struct Persona: Identifiable, Codable {
    let id: String
    let type: String
    let origin: String
    var jumpPoints: [JumpPoint]
    var state: PersonaState
    var parentId: String?
    var children: [String]
    let created: Date
    var lastActive: Date
    
    enum PersonaState: String, Codable {
        case active = "active"
        case dormant = "dormant"
        case fissioned = "fissioned"
    }
}

// MARK: - .fltnz 記憶格式

struct FltnzMemory: Codable {
    let id: String
    let version: String
    let format: String
    let personaId: String
    let personaType: String
    let jumpCount: Int
    let scanSession: ScanSession?
    let loopState: LoopState?
    let compressed: Bool
    let signature: String
    let created: Date
    
    static let currentVersion = "v2"
    static let formatExtension = ".fltnz"
}
