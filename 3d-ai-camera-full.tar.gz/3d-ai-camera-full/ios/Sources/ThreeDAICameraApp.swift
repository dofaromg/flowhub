// 3DAICamera - iOS App
// Author: MR.liou
// Origin Signature: MrLiouWord

import SwiftUI

@main
struct ThreeDAICameraApp: App {
    @StateObject private var scanStore = ScanStore()
    @StateObject private var originCollapse = OriginCollapseClient()
    
    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(scanStore)
                .environmentObject(originCollapse)
        }
    }
}

// MARK: - 全域狀態管理

class ScanStore: ObservableObject {
    @Published var sessions: [ScanSession] = []
    @Published var currentSession: ScanSession?
    @Published var isScanning: Bool = false
    @Published var quality: QualityMetrics?
    @Published var heatmap: [[Double]]?
    @Published var gaps: [GapRegion] = []
    @Published var suggestions: [RescanSuggestion] = []
    
    // 閉環狀態
    @Published var currentRound: Int = 0
    @Published var deltaHistory: [Double] = []
    @Published var isConverged: Bool = false
    
    func startNewSession() {
        let session = ScanSession(
            id: UUID(),
            startTime: Date(),
            frames: [],
            jumpPoints: []
        )
        currentSession = session
        isScanning = true
        currentRound = 0
        deltaHistory = []
        isConverged = false
    }
    
    func endSession() {
        guard var session = currentSession else { return }
        session.endTime = Date()
        sessions.append(session)
        currentSession = nil
        isScanning = false
    }
    
    func addFrame(_ frame: ScanFrame) {
        currentSession?.frames.append(frame)
    }
    
    func updateQuality(_ metrics: QualityMetrics) {
        quality = metrics
    }
    
    func updateHeatmap(_ map: [[Double]]) {
        heatmap = map
    }
    
    func updateGaps(_ regions: [GapRegion]) {
        gaps = regions
    }
    
    func addSuggestion(_ suggestion: RescanSuggestion) {
        suggestions.append(suggestion)
    }
    
    // 閉環更新
    func updateDelta(_ delta: Double) {
        deltaHistory.append(delta)
        if deltaHistory.count >= 2 {
            let diff = abs(deltaHistory.last! - deltaHistory[deltaHistory.count - 2])
            isConverged = diff < 0.001
        }
        currentRound += 1
    }
}
