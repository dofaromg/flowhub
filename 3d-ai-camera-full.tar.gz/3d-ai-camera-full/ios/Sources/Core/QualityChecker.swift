// Core/QualityChecker.swift
// 品質檢測核心模組

import UIKit
import CoreImage
import Accelerate

/// 品質檢測器
/// 實現：銳度（Laplacian variance）、曝光（histogram）、熵（Shannon entropy）
class QualityChecker {
    
    private let context = CIContext()
    
    /// 評估 CVPixelBuffer 的品質
    func evaluate(pixelBuffer: CVPixelBuffer) -> QualityMetrics {
        guard let cgImage = createCGImage(from: pixelBuffer) else {
            return QualityMetrics(sharpness: 0, exposure: 0, entropy: 0, contrast: 0)
        }
        
        return evaluate(cgImage: cgImage)
    }
    
    /// 評估 UIImage 的品質
    func evaluate(image: UIImage) -> QualityMetrics {
        guard let cgImage = image.cgImage else {
            return QualityMetrics(sharpness: 0, exposure: 0, entropy: 0, contrast: 0)
        }
        
        return evaluate(cgImage: cgImage)
    }
    
    /// 評估 CGImage 的品質
    func evaluate(cgImage: CGImage) -> QualityMetrics {
        let grayData = convertToGrayscale(cgImage: cgImage)
        
        let sharpness = calculateSharpness(grayData: grayData, width: cgImage.width, height: cgImage.height)
        let (exposure, contrast) = calculateExposure(grayData: grayData)
        let entropy = calculateEntropy(grayData: grayData)
        
        return QualityMetrics(
            sharpness: sharpness,
            exposure: exposure,
            entropy: entropy,
            contrast: contrast
        )
    }
    
    // MARK: - 銳度計算（Laplacian Variance）
    
    /// 使用 Laplacian 算子計算銳度
    /// 公式：variance(Laplacian(image))
    private func calculateSharpness(grayData: [UInt8], width: Int, height: Int) -> Double {
        guard width > 2 && height > 2 else { return 0 }
        
        // Laplacian kernel: [0, 1, 0; 1, -4, 1; 0, 1, 0]
        var laplacianValues: [Double] = []
        laplacianValues.reserveCapacity((width - 2) * (height - 2))
        
        for y in 1..<(height - 1) {
            for x in 1..<(width - 1) {
                let idx = y * width + x
                
                let center = Double(grayData[idx])
                let top = Double(grayData[(y - 1) * width + x])
                let bottom = Double(grayData[(y + 1) * width + x])
                let left = Double(grayData[y * width + (x - 1)])
                let right = Double(grayData[y * width + (x + 1)])
                
                let laplacian = top + bottom + left + right - 4 * center
                laplacianValues.append(laplacian)
            }
        }
        
        // 計算變異數
        let mean = laplacianValues.reduce(0, +) / Double(laplacianValues.count)
        let variance = laplacianValues.map { pow($0 - mean, 2) }.reduce(0, +) / Double(laplacianValues.count)
        
        return variance
    }
    
    // MARK: - 曝光計算（Histogram Analysis）
    
    /// 分析直方圖計算曝光品質
    /// 回傳：(exposure, contrast)
    /// exposure: 0-1，越接近 0.5 越好
    /// contrast: 基於直方圖的動態範圍
    private func calculateExposure(grayData: [UInt8]) -> (Double, Double) {
        // 建立直方圖
        var histogram = [Int](repeating: 0, count: 256)
        for pixel in grayData {
            histogram[Int(pixel)] += 1
        }
        
        // 計算 CDF
        var cdf = [Double](repeating: 0, count: 256)
        let total = Double(grayData.count)
        cdf[0] = Double(histogram[0]) / total
        for i in 1..<256 {
            cdf[i] = cdf[i - 1] + Double(histogram[i]) / total
        }
        
        // 找到 5% 和 95% 分位點
        var q5: Double = 0
        var q95: Double = 1
        
        for i in 0..<256 {
            if cdf[i] >= 0.05 && q5 == 0 {
                q5 = Double(i) / 255.0
            }
            if cdf[i] >= 0.95 {
                q95 = Double(i) / 255.0
                break
            }
        }
        
        // 曝光品質：理想是 q5 ≈ 0.15, q95 ≈ 0.95
        let exposureError = abs(q5 - 0.15) + abs(q95 - 0.95)
        let exposure = max(0, 1 - exposureError / 2)
        
        // 對比度：動態範圍
        let contrast = q95 - q5
        
        return (exposure, contrast)
    }
    
    // MARK: - 熵計算（Shannon Entropy）
    
    /// 計算 Shannon 熵
    /// 公式：-Σ p(x) * log2(p(x))
    private func calculateEntropy(grayData: [UInt8]) -> Double {
        // 建立直方圖
        var histogram = [Int](repeating: 0, count: 256)
        for pixel in grayData {
            histogram[Int(pixel)] += 1
        }
        
        // 計算機率並求熵
        let total = Double(grayData.count)
        var entropy: Double = 0
        
        for count in histogram {
            if count > 0 {
                let p = Double(count) / total
                entropy -= p * log2(p)
            }
        }
        
        return entropy
    }
    
    // MARK: - 輔助函數
    
    /// CVPixelBuffer 轉 CGImage
    private func createCGImage(from pixelBuffer: CVPixelBuffer) -> CGImage? {
        let ciImage = CIImage(cvPixelBuffer: pixelBuffer)
        return context.createCGImage(ciImage, from: ciImage.extent)
    }
    
    /// CGImage 轉灰度數據
    private func convertToGrayscale(cgImage: CGImage) -> [UInt8] {
        let width = cgImage.width
        let height = cgImage.height
        let bytesPerPixel = 1
        let bytesPerRow = width * bytesPerPixel
        let bitsPerComponent = 8
        
        var grayData = [UInt8](repeating: 0, count: width * height)
        
        let colorSpace = CGColorSpaceCreateDeviceGray()
        guard let context = CGContext(
            data: &grayData,
            width: width,
            height: height,
            bitsPerComponent: bitsPerComponent,
            bytesPerRow: bytesPerRow,
            space: colorSpace,
            bitmapInfo: CGImageAlphaInfo.none.rawValue
        ) else {
            return grayData
        }
        
        context.draw(cgImage, in: CGRect(x: 0, y: 0, width: width, height: height))
        
        return grayData
    }
}

// MARK: - 注意力引擎

/// 注意力權重計算
/// 實現：Simple（中心性）和 ViT 近似
class AttentionEngine {
    
    enum AttentionMode {
        case simple    // 基於中心距離
        case feature   // 基於特徵相似度（ViT 近似）
    }
    
    private var mode: AttentionMode = .simple
    
    /// 計算注意力圖
    /// 公式（Simple）：A_i(u,v) = 1 - sqrt((u-cx)^2/(W/2)^2 + (v-cy)^2/(H/2)^2)
    func computeAttentionMap(width: Int, height: Int) -> [[Double]] {
        var map = [[Double]](repeating: [Double](repeating: 0, count: width), count: height)
        
        let cx = Double(width) / 2
        let cy = Double(height) / 2
        let halfW = Double(width) / 2
        let halfH = Double(height) / 2
        
        for y in 0..<height {
            for x in 0..<width {
                let dx = (Double(x) - cx) / halfW
                let dy = (Double(y) - cy) / halfH
                let distance = sqrt(dx * dx + dy * dy)
                
                // 正規化到 [0, 1]
                map[y][x] = max(0, 1 - distance)
            }
        }
        
        // 正規化（確保最大值為 1）
        let maxVal = map.flatMap { $0 }.max() ?? 1
        if maxVal > 0 {
            for y in 0..<height {
                for x in 0..<width {
                    map[y][x] /= maxVal
                }
            }
        }
        
        return map
    }
    
    /// 計算加權誤差
    /// 公式：ē_ij = A_i(u,v) · ρ_δ(e_ij)
    func weightedError(error: Double, attention: Double, huberDelta: Double = 1.0) -> Double {
        let robustError = huberLoss(error, delta: huberDelta)
        return attention * robustError
    }
    
    /// Huber 損失函數
    /// ρ_δ(e) = 0.5 * e² (if |e| ≤ δ) else δ * (|e| - 0.5δ)
    private func huberLoss(_ e: Double, delta: Double) -> Double {
        let absE = abs(e)
        if absE <= delta {
            return 0.5 * e * e
        } else {
            return delta * (absE - 0.5 * delta)
        }
    }
}

// MARK: - 覆蓋率分析器

/// 覆蓋率分析
class CoverageAnalyzer {
    
    private let tileRows: Int
    private let tileCols: Int
    
    init(tileRows: Int = 4, tileCols: Int = 4) {
        self.tileRows = tileRows
        self.tileCols = tileCols
    }
    
    /// 計算覆蓋熱圖
    /// 公式：C_k(u,v) = Σ 1[X_w 在畫幅內]
    func computeCoverageMap(
        projectedPoints: [(x: Double, y: Double)],
        imageWidth: Int,
        imageHeight: Int
    ) -> [[Double]] {
        var map = [[Double]](repeating: [Double](repeating: 0, count: imageWidth), count: imageHeight)
        
        for point in projectedPoints {
            let x = Int(round(point.x))
            let y = Int(round(point.y))
            
            if x >= 0 && x < imageWidth && y >= 0 && y < imageHeight {
                map[y][x] += 1
            }
        }
        
        // 正規化
        let maxVal = map.flatMap { $0 }.max() ?? 1
        if maxVal > 0 {
            for y in 0..<imageHeight {
                for x in 0..<imageWidth {
                    map[y][x] /= maxVal
                }
            }
        }
        
        return map
    }
    
    /// 切塊分析
    /// 公式：S_ij = (1/|Ω_ij|) * Σ M(u,v)
    func analyzeTiles(coverageMap: [[Double]]) -> [[Double]] {
        let height = coverageMap.count
        let width = coverageMap.first?.count ?? 0
        
        guard height > 0 && width > 0 else { return [] }
        
        let tileHeight = height / tileRows
        let tileWidth = width / tileCols
        
        var tileScores = [[Double]](repeating: [Double](repeating: 0, count: tileCols), count: tileRows)
        
        for row in 0..<tileRows {
            for col in 0..<tileCols {
                let startY = row * tileHeight
                let endY = min((row + 1) * tileHeight, height)
                let startX = col * tileWidth
                let endX = min((col + 1) * tileWidth, width)
                
                var sum: Double = 0
                var count = 0
                
                for y in startY..<endY {
                    for x in startX..<endX {
                        sum += coverageMap[y][x]
                        count += 1
                    }
                }
                
                tileScores[row][col] = count > 0 ? sum / Double(count) : 0
            }
        }
        
        return tileScores
    }
    
    /// 檢測缺口區域
    /// 低覆蓋率（< threshold）的區塊
    func detectGaps(tileScores: [[Double]], threshold: Double = 0.3) -> [GapRegion] {
        var gaps: [GapRegion] = []
        
        for (row, rowScores) in tileScores.enumerated() {
            for (col, score) in rowScores.enumerated() {
                if score < threshold {
                    let gap = GapRegion(
                        id: UUID(),
                        tileRow: row,
                        tileCol: col,
                        coverage: score,
                        anomalyScore: 1 - score,  // 轉換：低覆蓋 = 高異常
                        centerPoint: nil
                    )
                    gaps.append(gap)
                }
            }
        }
        
        return gaps.sorted { $0.coverage < $1.coverage }
    }
}
