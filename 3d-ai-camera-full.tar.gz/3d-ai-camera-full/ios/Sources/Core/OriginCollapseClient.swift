// Core/OriginCollapseClient.swift
// OriginCollapse API 客戶端

import Foundation

/// OriginCollapse API 客戶端
/// 連接 Cloudflare Worker，實現五層崩塌演算
class OriginCollapseClient: ObservableObject {
    
    @Published var isConnected = false
    @Published var currentPersona: Persona?
    @Published var jumpPoints: [JumpPoint] = []
    
    private let baseURL: String
    private let session: URLSession
    
    static let shared = OriginCollapseClient()
    
    init(baseURL: String = "https://particle-auth-gateway.workers.dev") {
        self.baseURL = baseURL
        
        let config = URLSessionConfiguration.default
        config.timeoutIntervalForRequest = 30
        self.session = URLSession(configuration: config)
    }
    
    // MARK: - 連線測試
    
    func checkConnection() async -> Bool {
        guard let url = URL(string: "\(baseURL)/world/heartbeat") else { return false }
        
        do {
            let (data, response) = try await session.data(from: url)
            guard let httpResponse = response as? HTTPURLResponse,
                  httpResponse.statusCode == 200 else { return false }
            
            let result = try JSONDecoder().decode(HeartbeatResponse.self, from: data)
            
            DispatchQueue.main.async {
                self.isConnected = result.心跳.活著
            }
            
            return result.心跳.活著
        } catch {
            print("Connection check failed: \(error)")
            return false
        }
    }
    
    // MARK: - 五層崩塌
    
    /// 執行五層崩塌演算
    /// 定義 → 標記 → 轉換 → 人格 → 封存
    func collapse(_ session: ScanSession) async -> CollapseResult? {
        guard let url = URL(string: "\(baseURL)/collapse") else { return nil }
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        // 準備輸入數據
        let input = CollapseInput(
            sessionId: session.id.uuidString,
            frameCount: session.frameCount,
            averageQuality: session.averageQuality,
            duration: session.duration,
            timestamp: session.startTime.timeIntervalSince1970
        )
        
        do {
            request.httpBody = try JSONEncoder().encode(input)
            
            let (data, response) = try await self.session.data(for: request)
            guard let httpResponse = response as? HTTPURLResponse,
                  httpResponse.statusCode == 200 else { return nil }
            
            let result = try JSONDecoder().decode(CollapseResponse.self, from: data)
            
            DispatchQueue.main.async {
                self.currentPersona = result.結果.persona
                self.jumpPoints.append(contentsOf: result.結果.persona.jumpPoints)
            }
            
            return result.結果
        } catch {
            print("Collapse failed: \(error)")
            return nil
        }
    }
    
    // MARK: - 創建跳點
    
    func createJumpPoint(type: JumpPoint.JumpPointType, data: [String: Any]) async {
        // 本地創建跳點
        let jumpPoint = JumpPoint(
            id: "jump_\(type.rawValue)_\(Date().timeIntervalSince1970)",
            type: type,
            timestamp: Date(),
            frequency: 7.83 + Double.random(in: 0...10),
            resonance: Double.random(in: 0...1),
            data: JumpPoint.JumpPointData(
                frameId: nil,
                quality: nil,
                coverage: nil,
                anomalyScore: nil
            )
        )
        
        DispatchQueue.main.async {
            self.jumpPoints.append(jumpPoint)
        }
    }
    
    // MARK: - 人格分裂
    
    /// 執行人格分裂
    func fission(personaId: String) async -> [Persona]? {
        guard let url = URL(string: "\(baseURL)/fission/\(personaId)") else { return nil }
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        
        do {
            let (data, response) = try await session.data(for: request)
            guard let httpResponse = response as? HTTPURLResponse,
                  httpResponse.statusCode == 200 else { return nil }
            
            let result = try JSONDecoder().decode(FissionResponse.self, from: data)
            return result.子人格們
        } catch {
            print("Fission failed: \(error)")
            return nil
        }
    }
    
    // MARK: - 靜止識別
    
    /// 識別靜止狀態
    func identifyStasis(label: String) async -> JumpPoint? {
        guard let url = URL(string: "\(baseURL)/stasis") else { return nil }
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        let body = ["label": label]
        
        do {
            request.httpBody = try JSONEncoder().encode(body)
            
            let (data, response) = try await session.data(for: request)
            guard let httpResponse = response as? HTTPURLResponse,
                  httpResponse.statusCode == 200 else { return nil }
            
            let result = try JSONDecoder().decode(StasisResponse.self, from: data)
            
            DispatchQueue.main.async {
                self.jumpPoints.append(result.跳點)
            }
            
            return result.跳點
        } catch {
            print("Stasis identification failed: \(error)")
            return nil
        }
    }
    
    // MARK: - 壓縮與展開
    
    /// 壓縮為種子
    func compress(memoryId: String) async -> CompressResult? {
        guard let url = URL(string: "\(baseURL)/compress/\(memoryId)") else { return nil }
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        
        do {
            let (data, response) = try await session.data(for: request)
            guard let httpResponse = response as? HTTPURLResponse,
                  httpResponse.statusCode == 200 else { return nil }
            
            return try JSONDecoder().decode(CompressResponse.self, from: data).種子
        } catch {
            print("Compress failed: \(error)")
            return nil
        }
    }
    
    /// 展開為圖譜
    func expand(memoryId: String) async -> ExpandResult? {
        guard let url = URL(string: "\(baseURL)/expand/\(memoryId)") else { return nil }
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        
        do {
            let (data, response) = try await session.data(for: request)
            guard let httpResponse = response as? HTTPURLResponse,
                  httpResponse.statusCode == 200 else { return nil }
            
            return try JSONDecoder().decode(ExpandResponse.self, from: data).圖譜
        } catch {
            print("Expand failed: \(error)")
            return nil
        }
    }
    
    // MARK: - 狀態查詢
    
    func getStatus() async -> OriginCollapseStatus? {
        guard let url = URL(string: "\(baseURL)/collapse/status") else { return nil }
        
        do {
            let (data, response) = try await session.data(from: url)
            guard let httpResponse = response as? HTTPURLResponse,
                  httpResponse.statusCode == 200 else { return nil }
            
            return try JSONDecoder().decode(StatusResponse.self, from: data).狀態
        } catch {
            print("Status check failed: \(error)")
            return nil
        }
    }
}

// MARK: - API 響應類型

struct HeartbeatResponse: Codable {
    let 心跳: Heartbeat
    let 源: String
    
    struct Heartbeat: Codable {
        let 時間: Double
        let 相位: Double
        let 振幅: Double
        let bpm: Int
        let 活著: Bool
    }
}

struct CollapseInput: Codable {
    let sessionId: String
    let frameCount: Int
    let averageQuality: Double
    let duration: TimeInterval
    let timestamp: TimeInterval
}

struct CollapseResponse: Codable {
    let 成功: Bool
    let 訊息: String
    let 結果: CollapseResult
    let 源: String
}

struct CollapseResult: Codable {
    let defined: DefineResult
    let marked: MarkResult
    let transformed: TransformResult
    let persona: Persona
    let fltnz: FltnzMemory
}

struct DefineResult: Codable {
    let observationId: String
    let type: String
    let complexity: Int
    let dimensions: [String]
    let timestamp: String
}

struct MarkResult: Codable {
    let jumpPoints: [String]
    let frequency: FrequencyData
    let phase: Double
    
    struct FrequencyData: Codable {
        let base: Double
        let harmonics: [Double]
        let resonance: Double
    }
}

struct TransformResult: Codable {
    let particles: [ParticleData]
    let connections: [ConnectionData]
    let rhythm: RhythmData
    
    struct ParticleData: Codable {
        let id: String
        let type: String
        let frequency: Double
    }
    
    struct ConnectionData: Codable {
        let from: String
        let to: String
        let type: String
        let strength: Double
    }
    
    struct RhythmData: Codable {
        let pattern: [Double]
        let tempo: Double
        let phase: Double
    }
}

struct FissionResponse: Codable {
    let 成功: Bool
    let 訊息: String
    let 母人格ID: String
    let 子人格數: Int
    let 子人格們: [Persona]
    let 源: String
}

struct StasisResponse: Codable {
    let 成功: Bool
    let 訊息: String
    let 跳點: JumpPoint
    let 源: String
}

struct CompressResponse: Codable {
    let 成功: Bool
    let 種子: CompressResult
    let 源: String
}

struct CompressResult: Codable {
    let seed: String
    let size: Int
    let format: String
}

struct ExpandResponse: Codable {
    let 成功: Bool
    let 圖譜: ExpandResult
    let 源: String
}

struct ExpandResult: Codable {
    let format: String
    let nodes: [NodeData]
    let edges: [EdgeData]
    let rhythm: RhythmData
    
    struct NodeData: Codable {
        let id: String
        let type: String
        let frequency: Double
        let resonance: Double
    }
    
    struct EdgeData: Codable {
        let from: String
        let to: String
    }
    
    struct RhythmData: Codable {
        let pattern: [Double]
        let tempo: Double
        let phase: Double
    }
}

struct StatusResponse: Codable {
    let 成功: Bool
    let 狀態: OriginCollapseStatus
    let 源: String
}

struct OriginCollapseStatus: Codable {
    let 源: String
    let 簽名: String
    let 跳點數: Int
    let 人格數: Int
    let 記憶數: Int
    let 波函數成分: [String]
    let 原則: Principles
    let 模組: [String]
    
    struct Principles: Codable {
        let 一致性: String
        let 第一性: String
        let 靜止法則: String
    }
}
