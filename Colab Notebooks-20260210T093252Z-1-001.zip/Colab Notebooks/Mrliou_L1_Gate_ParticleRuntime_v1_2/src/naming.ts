export const MR_PREFIX = "Mrliou_";

export function mrliouName(name: string): string {
  const n = (name ?? "").trim();
  if (!n) throw new Error("name required");
  return n.startsWith(MR_PREFIX) ? n : `${MR_PREFIX}${n}`;
}
