export type GateResult =
  | { ok: true; subject: string; scopes: string[] }
  | { ok: false; reason: string };

/**
 * Gate v1:
 * - token required
 * - token format: "scope1,scope2|subject"
 */
export function gate(token: string | null, requiredScopes: string[] = []): GateResult {
  const t = (token ?? "").trim();
  if (!t) return { ok: false, reason: "missing_token" };

  const [scopePart, subjectPart] = t.split("|");
  const scopes = (scopePart ?? "").split(",").map(s => s.trim()).filter(Boolean);
  const subject = (subjectPart ?? "unknown").trim() || "unknown";

  for (const rs of requiredScopes) {
    if (!scopes.includes(rs)) return { ok: false, reason: `missing_scope:${rs}` };
  }
  return { ok: true, subject, scopes };
}
