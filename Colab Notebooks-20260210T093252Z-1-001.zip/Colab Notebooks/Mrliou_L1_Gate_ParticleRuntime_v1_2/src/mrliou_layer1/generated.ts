// AUTO-GENERATED placeholder. Run `npm run build` then `node dist/tools/gen_layer1.js`
export const MRLIou_L1_APIS = [];
