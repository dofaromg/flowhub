import { mrliouName } from "./naming.js";
import { sha256Hex } from "./crypto.js";
import { signV1 } from "./signer.js";

export type Trace = {
  event_id: string;
  rid: string;
  tick: number;
  persona_id?: string;
  source?: string;
  upstream?: string;
};

export type MrliouPacket<T = unknown> = {
  type: string;        // Mrliou_*
  name: string;        // Mrliou_*
  payload: T;
  trace: Trace;
  created_utc: string;
  content_sha256: string;
  merkle_root: string;
  signature: string;
};

export async function makePacket<T>(
  type: string,
  name: string,
  payload: T,
  trace: Trace,
): Promise<MrliouPacket<T>> {
  const created_utc = new Date().toISOString();
  const publicType = mrliouName(type);
  const publicName = mrliouName(name);

  const content = JSON.stringify({ publicType, publicName, payload, trace, created_utc });
  const content_sha256 = await sha256Hex(content);
  const merkle_root = content_sha256;

  const signature = await signV1({
    merkle_root,
    event_id: trace.event_id,
    rid: trace.rid,
    tick: trace.tick,
  });

  return { type: publicType, name: publicName, payload, trace, created_utc, content_sha256, merkle_root, signature };
}
