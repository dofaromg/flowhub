import { sha256Hex } from "./crypto.js";
import { MR_PREFIX } from "./naming.js";

export type SignInput = {
  merkle_root: string;
  event_id: string;
  rid: string;
  tick: number;
};

export async function signV1(input: SignInput): Promise<string> {
  const s = `${input.merkle_root}|${input.event_id}|${input.rid}|${input.tick}`;
  const h = await sha256Hex(s);
  return `${MR_PREFIX}sig_v1_${h.slice(0, 16)}`;
}
