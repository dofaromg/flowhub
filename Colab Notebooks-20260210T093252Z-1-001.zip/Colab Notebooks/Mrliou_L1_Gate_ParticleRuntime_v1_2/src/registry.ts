import { mrliouName } from "./naming.js";

export type UpstreamRef = { vendor: string; endpoint: string; method?: string; docs?: string };

export type ApiDef = {
  api: string;         // public Mrliou_* name (auto)
  impl: string;        // internal impl id (adapter id)
  upstream?: UpstreamRef;
  scopes?: string[];
};

export class Registry {
  private defs = new Map<string, ApiDef>();

  register(def: ApiDef): ApiDef {
    const api = mrliouName(def.api);
    const normalized: ApiDef = { ...def, api };
    this.defs.set(api, normalized);
    return normalized;
  }

  list(): ApiDef[] {
    return [...this.defs.values()];
  }
}
