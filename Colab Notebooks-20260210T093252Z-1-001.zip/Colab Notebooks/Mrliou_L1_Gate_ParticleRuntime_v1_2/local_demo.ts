import fs from "node:fs";
import path from "node:path";
import { Registry } from "./src/registry.js";
import { makePacket } from "./src/packet.js";

async function main() {
  const reg = new Registry();
  // Try loading generated defs if present
  const genPath = path.join(process.cwd(), "src", "mrliou_layer1", "generated.ts");
  console.log("If you ran generator, open:", genPath);

  // Minimal packet demo
  const p = await makePacket("Ping", "Ping", { ok: true }, { event_id: "evt0", rid: "rid0", tick: 0, source: "local_demo" });
  console.log(JSON.stringify(p, null, 2));
}
main().catch(e => { console.error(e); process.exit(1); });
