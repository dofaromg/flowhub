import { gate } from "../src/gate.js";
import { Registry } from "../src/registry.js";
import { makePacket } from "../src/packet.js";
import { MRLIou_L1_APIS } from "../src/mrliou_layer1/generated.js";

function json(data: any, status = 200) {
  return new Response(JSON.stringify(data, null, 2), { status, headers: { "content-type": "application/json; charset=utf-8" } });
}

export default {
  async fetch(req: Request): Promise<Response> {
    const url = new URL(req.url);
    const token = req.headers.get("authorization")?.replace(/^Bearer\s+/i, "") ?? null;

    if (url.pathname === "/ping") {
      return json({ ok: true, name: "Mrliou_L1_Gate_ParticleRuntime_v1.1" });
    }

    if (url.pathname === "/registry") {
      const g = gate(token, ["l1.read"]);
      if (!g.ok) return json({ ok: false, error: g.reason }, 401);

      const reg = new Registry();
      for (const d of MRLIou_L1_APIS) reg.register(d);
      return json({ ok: true, subject: g.subject, apis: reg.list() });
    }

    if (url.pathname === "/packet") {
      const g = gate(token, ["l1.read"]);
      if (!g.ok) return json({ ok: false, error: g.reason }, 401);

      const p = await makePacket("L1.Packet", "L1.Packet", { note: "hello" }, { event_id: "evt_cf", rid: "rid_cf", tick: 1, source: "cloudflare.worker" });
      return json(p);
    }

    return json({ ok: false, error: "not_found" }, 404);
  }
};
