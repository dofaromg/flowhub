# Mrliou L1 Gate · Particle Runtime (v1.2)
目標：**第一層入口寫規則一次**（改寫/命名/封包/授權），其後只做粒子組合（莫比斯無限）。

本包提供：
- 單一入口 Gate（授權即啟動）
- `Mrliou_` 命名規則（所有對外 API/封包/事件）
- 封包（trace + merkle_root + signature）
- L1 生成器：新增 upstream 定義 → 生成 `Mrliou_*` API 面
- Cloudflare Worker：提供 `/ping`、`/registry`、`/packet`

## 快速開始（本地）
```bash
npm i
npm run build
node dist/local_demo.js
```

## 生成 L1 API（改寫一次）
1. 編輯 `upstream_defs/upstreams.v1.json`
2. 生成：
```bash
npm run build
node dist/tools/gen_layer1.js
```

## Cloudflare Workers
```bash
npm i
npm run build:cf
cd cloudflare
npx wrangler deploy
```

## 私人使用建議
- GitHub：**Private Repo** 上傳封存
- Notion：貼 `notion/INDEX.md`
- 手機母體：把 zip 存到「檔案」App，保留原目錄即母體
